[
    {
        "name": "RRC Setup Success Rate",
        "target": 0.9
    },
    {
        "name": "Qos Flow Setup Success Rate",
        "target": 0.995
    },
    {
        "name": "Qos Flow Drop Rate",
        "target": 0.1
    },
    {
        "name": "RRC AttConnReestab Success Rate",
        "target": 0.9
    },
    {
        "name": "RRC AttConnReestab Rate",
        "target": 0.1
    },
    {
        "name": "Context Drop Rate",
        "target": 0.1
    },
    {
        "name": "Intra-gNB Handover Out Success Rate",
        "target": 0.9
    },
    {
        "name": "IntraFreq Handover Out Success Rate",
        "target": 0.9
    },
    {
        "name": "IntraFreq Handover In Success Rate",
        "target": 0.9
    }
]