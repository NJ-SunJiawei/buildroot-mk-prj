[
    {
        "name": "RRC Setup Success Rate",
        "value":[
            {
            "numerator": [{"node":"RRC.SuccConnEstab"}],
            "counter": [{"node":"RRC.AttConnEstab"}]
            }
        ]
    },
    {
        "name": "Qos Flow Setup Success Rate",
        "value":[
            {
            "numerator": [{"node":"Flow.NbrSuccEstab.5QI9"}],
            "counter": [{"node":"Flow.NbrAttEstab.5QI9"}],
            "pettify_coef": {"target":1, "100_reduce_target":0.8}
            },
            {
            "numerator": [{"node":"Flow.NbrSuccEstab.5QI5"}],
            "counter": [{"node":"Flow.NbrAttEstab.5QI5"}],
            "pettify_coef": {"target":1, "100_reduce_target":0.5}
            },
            {
            "numerator": [{"node":"Flow.NbrSuccEstab.5QI1"}],
            "counter": [{"node":"Flow.NbrAttEstab.5QI1"}],
            "pettify_coef": {"target":1}
            }
        ]
    },
    {
        "name": "Qos Flow Drop Rate",
        "less_then": 1,
        "value":[
            {
                "numerator": [
                    {"node":"Flow.NbrReqRelGnb.Normal.5QI9", "coef": -1}, 
                    {"node":"Flow.NbrReqRelGnb.5QI9", "coef": 1}
                ],
                "counter": [{"node":"Flow.NbrReqRelAMFInitNoHo.5QI9"}],
                "pettify_coef": {"target":0.4}
            },
            {
                "numerator": [
                    {"node":"Flow.NbrReqRelGnb.Normal.5QI5", "coef": -1}, 
                    {"node":"Flow.NbrReqRelGnb.5QI5", "coef": 1}
                ],
                "counter": [{"node":"Flow.NbrReqRelAMFInitNoHo.5QI5"}],
                "pettify_coef": {"target":0.6}
            },
            {
                "numerator": [
                    {"node":"Flow.NbrReqRelGnb.Normal.5QI1", "coef": -1}, 
                    {"node":"Flow.NbrReqRelGnb.5QI1", "coef": 1}
                ],
                "counter": [{"node":"Flow.NbrReqRelAMFInitNoHo.5QI1"}],
                "pettify_coef": {"target":1}
            }
        ]
    },
    {
        "name": "RRC AttConnReestab Rate",
        "type": "num_in_cun",
        "value":[
            {
            "numerator": [{"node":"RRC.AttConnReestab"}],
            "counter": [{"node":"RRC.AttConnEstab"}]
            }
        ]
    },
    {
        "name": "RRC AttConnReestab Success Rate",
        "value":[
            {
            "numerator": [{"node":"RRC.SuccConnReestab"}],
            "counter": [{"node":"RRC.AttConnReestab"}]
            }
        ]
    },
    {
        "name": "Context Drop Rate",
        "less_then": 1,
        "value":[
            {
                "numerator": [
                    {"node":"CONTEXT.AttRelgNB.Normal", "coef": -1}, 
                    {"node":"CONTEXT.AttRelgNB", "coef": 1}
                ],
                "counter": [{"node":"CONTEXT.AttRelgNB"}]
            }
        ]
    },
    {
        "name": "Intra-gNB Handover Out Success Rate",
        "value":[
            {
            "numerator": [{"node":"HO.SuccOutIntraCUInterDU"}],
            "counter": [{"node":"HO.AttPrepOutIntraCUInterDU"}],
            "pettify_coef": {"target":1, "100_reduce_target":0.8}
            },
            {
            "numerator": [{"node":"HO.SuccOutIntraDU"}],
            "counter": [{"node":"HO.AttPrepOutCUIntraDU"}],
            "pettify_coef": {"target":1, "100_reduce_target":1}
            }
        ]
    },
    {
        "name": "IntraFreq Handover Out Success Rate",
        "value":[
            {
            "numerator": [{"node":"HO.SuccOutIntraFreq"}],
            "counter": [{"node":"HO.AttOutExecIntraFreq"}]
            }
        ]
    },
    {
        "name": "IntraFreq Handover In Success Rate",
        "value":[
            {
            "numerator": [{"node":"HO.SuccExecIncIntraFreq"}],
            "counter": [{"node":"HO.AttPrepIncIntraFreq"}]
            }
        ]
    }
]