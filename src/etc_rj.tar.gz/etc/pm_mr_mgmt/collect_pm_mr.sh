#!/bin/bash

# 定义根目录
BASE_DIR="/run_isolate/oran_sftp/pm_mr_mgmt"
TAR_FILE="/run_isolate/oran_sftp/pm_mr_mgmt_tar.tar.gz"

# 定义最大文件大小（512MB）
MAX_SIZE=$((512 * 1024 * 1024))

# 初始化总大小
total_size=0

# 定义需要遍历的子目录
subdirs=("performance" "measurement")

# 收集所有日期目录
declare -A date_dirs
for subdir in "${subdirs[@]}"; do
    num_dirs=$(ls -d $BASE_DIR/$subdir/* | sort -r)
    for num_dir in $num_dirs; do
        net_types=("NR" "LTE")
        for net_type in "${net_types[@]}"; do
            for date_dir in $(ls -d $num_dir/$net_type/* 2>/dev/null); do
                date=$(basename "$date_dir")
                date_dirs["$date"]+="$date_dir "
            done
        done
    done
done

# 创建临时文件列表
tmp_file_list=$(mktemp)

# 按日期优先级收集文件
for date in $(echo "${!date_dirs[@]}" | tr ' ' '\n' | sort -r); do
    for date_dir in ${date_dirs["$date"]}; do
        files=$(ls -t "$date_dir")
        for file in $files; do
            file_path="$date_dir/$file"
            file_size=$(stat -c%s "$file_path")
            if [ $((total_size + file_size)) -le $MAX_SIZE ]; then
                echo "$file_path" >> "$tmp_file_list"
                total_size=$((total_size + file_size))
            else
                break 3
            fi
        done
    done
done

# 打包文件并去掉 /run_isolate/oran_sftp 部分路径
tar -czf "$TAR_FILE" -T "$tmp_file_list" --transform "s|^/run_isolate/oran_sftp||"

# 删除临时文件列表
rm "$tmp_file_list"

# 输出结果
echo "Files have been compressed into $TAR_FILE"
