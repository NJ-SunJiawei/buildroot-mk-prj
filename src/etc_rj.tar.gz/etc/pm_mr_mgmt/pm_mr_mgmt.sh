#!/bin/bash


/bin/rm -rf /data/.5gnr/log/zlog/pm_mr_mgmt/
/bin/mkdir -p /data/.5gnr/app_data/pm_mr_mgmt/
/bin/mkdir -p /run/.5gnr/log/zlog/pm_mr_mgmt/
/bin/mkdir -p /run_isolate/oran_sftp/pm_mr_mgmt/measurement/
/bin/mkdir -p /run_isolate/oran_sftp/pm_mr_mgmt/performance/
/bin/mkdir -p /run_isolate/public/pm_mr_mgmt/
/bin/mkdir -p /run_isolate/public/webfile/
/bin/rm -rf /run_isolate/public/webfile/mr
/bin/ln -sf /run_isolate/oran_sftp/pm_mr_mgmt/measurement /run_isolate/public/webfile/mr
/bin/rm -rf /run_isolate/public/webfile/pm
/bin/ln -sf /run_isolate/oran_sftp/pm_mr_mgmt/performance /run_isolate/public/webfile/pm
/bin/mkdir -p /sys/fs/cgroup/cpu/pm_mr_mgmt/
/bin/echo 30000 > /sys/fs/cgroup/cpu/pm_mr_mgmt/cpu.cfs_quota_us