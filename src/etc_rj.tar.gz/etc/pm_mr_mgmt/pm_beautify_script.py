# coding:utf-8
from xml.dom.minidom import parse
import xml.dom.minidom
import time
from xml.etree import ElementTree
import sys
import json
import math
import logging
from logging.handlers import RotatingFileHandler
import random
import string
import os
import traceback
import re

def get_node_value(cfg_strategy, xml_measValue, value_keyname):
    # 一个value列表中包含多个value字典. 每个字典为一组分子+分母
    cfg_value_list = cfg_strategy["value"]
    for cfg_value_dict in cfg_value_list:
        # 每个字典为一个最小KPI单位, 但每个字典中可能包含多个分子/分母, 因此这里是列表
        cfg_node_list = cfg_value_dict[value_keyname]
        for cfg_node in cfg_node_list:
            # 若该分子/分母没有配置系数, 则设置为默认值1
            if "coef" not in cfg_node:
                cfg_node["coef"] = 1
            xml_measValue_r_list = xml_measValue.getElementsByTagName("r")
            for xml_measValue_r in xml_measValue_r_list:
                if xml_measValue_r.getAttribute("p") == cfg_node["p"]:
                    cfg_node["value"] = int(xml_measValue_r.childNodes[0].data)
                    break

def set_node_value(xml_measValue, p_value, node_value):
    xml_measValue_r_list = xml_measValue.getElementsByTagName("r")
    for xml_measValue_r in xml_measValue_r_list:
        if xml_measValue_r.getAttribute("p") == p_value:
            value = '%d' %node_value
            xml_measValue_r.childNodes[0].data = value
            break

def common_check_kpi_up_to_standard(cfg_strategy):
    cfg_target = cfg_strategy["target"]
    cfg_value_list = cfg_strategy["value"]
    t_numerator = 0
    t_counter = 0
    expression_numerator = "("
    expression_conter = "("
    for cfg_value_dict in cfg_value_list:
        cfg_numerator_list = cfg_value_dict["numerator"]
        for cfg_numerator in cfg_numerator_list:
            t_numerator = t_numerator + (cfg_numerator["value"] * cfg_numerator["coef"])
            if cfg_numerator["coef"] > 0 and expression_numerator != "(":
                expression_numerator = expression_numerator + "+"
            expression_numerator = expression_numerator + str(cfg_numerator["value"] * cfg_numerator["coef"])
        cfg_conter_list = cfg_value_dict["counter"]
        for cfg_conter in cfg_conter_list:
            t_counter = t_counter + (cfg_conter["value"] * cfg_conter["coef"])
            if cfg_conter["coef"] > 0 and expression_conter != "(":
                expression_conter = expression_conter + "+"
            expression_conter = expression_conter + str(cfg_conter["value"] * cfg_conter["coef"])
    expression = expression_numerator + ")/" + expression_conter + ")"
    logger.debug("expression %s numerator %d counter %d target %f", expression, t_numerator, t_counter, cfg_target)
    if "less_then" in cfg_strategy:
        t_numerator = -t_numerator
        cfg_target = -cfg_target
    #分母为0，无法进行美化
    if t_counter == 0 :
        return True
    if t_counter != 0 and (float(t_numerator)/float(t_counter) <= 1) and (float(t_numerator)/float(t_counter) >= cfg_target):
        return True
    return False

def common_pettify_gen(cfg_strategy, xml_measValue):
    #先判断是否达标, 若达标则无需美化 
    ret = common_check_kpi_up_to_standard(cfg_strategy)
    if ret :
        return True
    # 开始美化
    cfg_target = cfg_strategy["target"]
    cfg_value_list = cfg_strategy["value"]
    for cfg_value_dict in cfg_value_list:
        #配置文件中可能没有配置美化系数, 这里先检查系数是否存在，若不存在则补上默认系数
        if "pettify_coef" not in cfg_value_dict:
            t_dict = {"target":1, "100_reduce_target":0}
            cfg_value_dict["pettify_coef"] = t_dict
        else :
            if "100_reduce_target" not in cfg_value_dict["pettify_coef"]:
                cfg_value_dict["pettify_coef"]["100_reduce_target"] = 0
        expect_target = (cfg_target * cfg_value_dict["pettify_coef"]["target"]) + \
            (1-cfg_target) * cfg_value_dict["pettify_coef"]["100_reduce_target"]
        expect_numerator = expect_target * cfg_value_dict["counter"][0]["value"]
        #最小单位中也可能存在多个分子, 其中第一个分子是待调参数, 其他分子都视为常数
        for i in range(1, len(cfg_value_dict["numerator"])):
            expect_numerator = expect_numerator - cfg_value_dict["numerator"][i]["value"]
        expect_numerator = expect_numerator * cfg_value_dict["numerator"][0]["coef"]
        #进行随机数处理, 避免每次美化的结果都一致
        lower = math.ceil(expect_numerator)
        if len(cfg_value_dict["numerator"]) > 1:
            upper = cfg_value_dict["numerator"][1]["value"]
        else :
            upper = cfg_value_dict["counter"][0]["value"]
        logger.debug("t_value %d lower %d upper %d", expect_numerator, lower, upper)
        expect_numerator = random.randint(lower, upper)
        old = cfg_value_dict["numerator"][0]["value"]
        if lower <= old and old <= upper:
            logger.debug("old %d lower %d upper %d", old, lower, upper)
        else :
            cfg_value_dict["numerator"][0]["value"] = math.ceil(expect_numerator)
            set_node_value(xml_measValue, cfg_value_dict["numerator"][0]["p"], cfg_value_dict["numerator"][0]["value"])
        #每调整一个参数就检查一次, 若达标就不用继续调整
        if common_check_kpi_up_to_standard(cfg_strategy) == True:
            break
    return True

def num_in_cun_check_kpi_up_to_standard(cfg_strategy):
    cfg_target = cfg_strategy["target"]
    t_numerator = cfg_strategy["value"][0]["numerator"][0]["value"]
    t_counter = t_numerator + cfg_strategy["value"][0]["counter"][0]["value"]
    logger.debug("numerator %d counter %d target %f", t_numerator, t_counter, cfg_target)
    #分母为0，无法进行美化
    if t_counter == 0 :
        return True
    if t_counter != 0 and (float(t_numerator)/float(t_counter) <= cfg_target):
        return True
    return False

def num_in_cun_pettify_gen(cfg_strategy, xml_measValue):
    #先判断是否达标, 若达标则无需美化
    if num_in_cun_check_kpi_up_to_standard(cfg_strategy):
        return True
    # 开始美化
    cfg_target = cfg_strategy["target"]
    t_counter = cfg_strategy["value"][0]["counter"][0]["value"]
    t_value = cfg_target * t_counter /(1 - cfg_target)
    #进行随机数处理, 避免每次美化的结果都一致
    lower = math.ceil(t_value / 2)
    upper = math.ceil(t_value)
    logger.debug("t_value %d lower %d upper %d", t_value, lower, upper)
    t_value = random.randint(lower, upper)
    set_node_value(xml_measValue, cfg_strategy["value"][0]["numerator"][0]["p"], math.ceil(t_value))
    logger.debug("numerator %d counter %d target %f", math.ceil(t_value), t_counter, cfg_target)
    return True

def reduce_counter_check_kpi_up_to_standard(cfg_strategy):
    cfg_target = cfg_strategy["target"]
    t_numerator = cfg_strategy["value"][0]["numerator"][0]["value"]
    t_counter =   cfg_strategy["value"][0]["counter"][0]["value"]
    logger.debug("numerator %d counter %d target %f", t_numerator, t_counter, cfg_target)
    #分母为0，无法进行美化
    if t_counter == 0 :
        return True
    if t_counter != 0 and (float(t_numerator)/float(t_counter) >= cfg_target):
        return True
    return False

def reduce_counter_pettify_gen(cfg_strategy, xml_measValue):
    #先判断是否达标, 若达标则无需美化
    if reduce_counter_check_kpi_up_to_standard(cfg_strategy):
        return True
    # 开始美化
    cfg_target = cfg_strategy["target"]
    t_numerator = cfg_strategy["value"][0]["numerator"][0]["value"]
    t_value = t_numerator / cfg_target
    #进行随机数处理, 避免每次美化的结果都一致
    lower = t_numerator
    upper = math.ceil(t_value)
    t_value = random.randint(lower, upper)
    set_node_value(xml_measValue, cfg_strategy["value"][0]["counter"][0]["p"], math.ceil(t_value))
    logger.debug("numerator %d counter %d target %f", t_numerator, math.ceil(t_value), cfg_target)
    return True

def deal_xml_measValue(cfg_strategy, xml_measValue):
    #如果ldn是all则需要遍历measInfo下的所有ldn都进行美化。
    get_node_value(cfg_strategy, xml_measValue, "numerator")
    get_node_value(cfg_strategy, xml_measValue, "counter")
    if "type" in cfg_strategy:
        if cfg_strategy["type"] == "num_in_cun":
            num_in_cun_pettify_gen(cfg_strategy, xml_measValue)
        elif cfg_strategy["type"] == "reduce_counter":
            reduce_counter_pettify_gen(cfg_strategy, xml_measValue)
    else :
        common_pettify_gen(cfg_strategy, xml_measValue)

def deal_xml_measInfo(cfg_strategy, xml_measInfo) :
    xml_measValue_list = xml_measInfo.getElementsByTagName("measValue")
    for xml_measValue in xml_measValue_list:
        deal_xml_measValue(cfg_strategy, xml_measValue)

def is_node_in_xml_measInfo(target_node, xml_measInfo):
    xml_measType_list = xml_measInfo.getElementsByTagName("measType")
    for xml_measType in xml_measType_list:
        if xml_measType.childNodes[0].data == target_node["node"]:
            target_node["p"] = xml_measType.getAttribute("p")
            return True
    return False

def is_strategy_for_this_xml_measInfo(cfg_strategy, xml_measInfo, value_keyname):
    # 一个value列表中包含多个value字典. 每个字典为一组分子+分母
    cfg_value_list = cfg_strategy["value"]
    cfg_strategy_name = cfg_strategy["name"]
    for cfg_value_dict in cfg_value_list:
        if value_keyname not in cfg_value_dict:
            logger.error("%s strategy lack %s", cfg_strategy_name, value_keyname)
            continue
        # 每个字典为一个最小KPI单位, 但每个字典中可能包含多个分子/分母, 因此这里是列表
        target_node_list = cfg_value_dict[value_keyname]
        for target_node in target_node_list:
            if is_node_in_xml_measInfo(target_node, xml_measInfo) != True:
                return False
    return True

def get_xml_measInfo(xml_t_measInfo, cfg_strategy):
    #找到策略对应的measinfo,并且获取美化counter在measinfo中的p值
    for xml_measInfo in xml_t_measInfo:
        if is_strategy_for_this_xml_measInfo(cfg_strategy, xml_measInfo, "numerator") and is_strategy_for_this_xml_measInfo(cfg_strategy, xml_measInfo, "counter") :
            return xml_measInfo
    return 0

def get_measValue_by_ldn(ldn, xml_measInfo):
    xml_measValue_list = xml_measInfo.getElementsByTagName("measValue")
    for xml_measValue in xml_measValue_list:
        xml_ldn = xml_measValue.getAttribute("measObjLdn")
        if xml_ldn == ldn:
            return xml_measValue
    return 0


def main(cfg_file_path, cfg_target_path, xml_file_path, xml_write_path, mode):
    # 加载配置文件
    with open(cfg_file_path, 'r') as load_f:
        cfg_pettify_list = json.load(load_f)
        if len(cfg_pettify_list) < 1:
            logger.error("cfg_file is invalide")
            return False
    with open(cfg_target_path, 'r') as load_f:
        cfg_target_list = json.load(load_f)
        if len(cfg_target_list) < 1 or len(cfg_target_list) != len(cfg_pettify_list):
            logger.error("target_file is invalide")
            return False
    #先匹配target文件和strategy文件中的name并将target值保存造strategy中
    success= True
    for i in range(0, len(cfg_target_list)):
        if "name" not in cfg_target_list[i]:
            logger.error("target No.%d lack %s", i+1, "name")
            success = False
            continue
        if "target" not in cfg_target_list[i]:
            logger.error("target name %s lack %s", cfg_target_list[i]["name"], "target")
            success = False
            continue
        # 美化目标必须在0% - 100%之间, 即[0,1]区间内的实数
        if (cfg_target_list[i]["target"] < 0.0) or (cfg_target_list[i]["target"] > 1.000):
            logger.error("No.%d target need in [0,1] but %f", i + 1, cfg_target_list[i]["target"])
            success = False
        for j in range(0, len(cfg_pettify_list)):
            if "name" not in cfg_pettify_list[j]:
                continue
            if cfg_target_list[i]["name"] == cfg_pettify_list[j]["name"]:
                cfg_pettify_list[j]["target"] = cfg_target_list[i]["target"]
                break
        if cfg_target_list[i]["name"] != cfg_pettify_list[j]["name"]:
            logger.warning("name %s not find", cfg_target_list[i]["name"])
    if mode == "check":
        return success
    # xml文件初始化并找出measInfo节点备用
    DOMTree = xml.dom.minidom.parse(xml_file_path)
    collection = DOMTree.documentElement
    xml_t_measInfo = collection.getElementsByTagName("measInfo")
    # 开始处理每条配置策略
    for i in range(0, len(cfg_pettify_list)):
        #先校验数据
        cfg_strategy = cfg_pettify_list[i]
        if "target" not in cfg_strategy:
            logger.debug("No.%d name %s cfg lack %s", i + 1, cfg_strategy["name"], "target")
            continue
        #校验通过
        if "ldn" not in cfg_strategy:
            cfg_strategy["ldn"] = "all"
        logger.debug("No.%d ldn %s target %f name %s", i + 1, cfg_strategy["ldn"], cfg_strategy["target"], cfg_strategy["name"])
        xml_measInfo = get_xml_measInfo(xml_t_measInfo, cfg_strategy)
        if xml_measInfo == 0 :
            logger.error("Fail to find xml_measInfo for %s strategy", cfg_strategy["name"])
            continue
        if cfg_strategy["ldn"] != "all" :
            xml_measValue = get_measValue_by_ldn(cfg_strategy["ldn"], xml_measInfo)
            if xml_measValue == 0 :
                continue
            #找到xml_measValue则对此ldn进行美化即可
            deal_xml_measValue(cfg_strategy, xml_measValue)
            continue
        
        deal_xml_measInfo(cfg_strategy, xml_measInfo)

    with open(xml_write_path, 'w+') as xml_w_fp:
        DOMTree.writexml(xml_w_fp,indent="",addindent="",newl='',encoding='UTF-8')
    with open(xml_write_path, "r") as file:
        content = file.read().replace("<?xml-stylesheet", "\n<?xml-stylesheet")
    new_content = content.replace("<measCollecFile", "\n<measCollecFile")
    error_str = 'dnPrefix="" fileFormatVersion'
    if error_str in new_content :
        modified_content = re.sub(r'dnPrefix="" (fileFormatVersion="[^"]+") (vendorName="[^"]+")', r'\1 \2 dnPrefix=""', new_content)
    with open(xml_write_path, "w") as file:
        file.write(modified_content)
    return success

try:
    cfg_file_path = sys.argv[1]
    cfg_target_path = sys.argv[2]
    mode = sys.argv[3]
except:
    print('usage: python {} strategy.js target.js {{mode}} (mode:common/check) *.xml'.format(__file__),)
    exit(1)
try:
    xml_file_path = sys.argv[4]
except:
    mode = "check"
    xml_file_path = ""
try:
    xml_write_path = sys.argv[5]
except:
    xml_write_path = xml_file_path

try:
    log_format = "%(asctime)s -- %(levelname)s -- %(message)s"
    formatter = logging.Formatter(log_format)
    logger = logging.getLogger(__name__) #定义一个log收集器
    logger.setLevel(level=logging.DEBUG)
    if mode == "check":
        console = logging.StreamHandler()
        console.setLevel(level=logging.WARNING)
        logger.addHandler(console)

    logger_path_debug = "/etc/pm_mr_mgmt/log.txt"
    file = open(logger_path_debug, 'w').close()
    log_file = RotatingFileHandler(logger_path_debug, encoding="utf-8", maxBytes=100*1024, backupCount=2)
    log_file.setFormatter(formatter)
    logger.addHandler(log_file)

    logger.debug("----------begin----------")
    logger.debug("strategy file:%s", cfg_file_path)
    logger.debug("target file:  %s", cfg_target_path)
    logger.debug("mode:         %s", mode)
    logger.debug("xml file:     %s", xml_file_path)
    logger.debug("xml write:    %s", xml_write_path)
    success = main(cfg_file_path, cfg_target_path, xml_file_path, xml_write_path, mode)
    logger.debug("-----------end-----------")
    if success:
        print("success")
        os._exit(0)
    else:
        print("fail")
        os._exit(255)
except Exception:
    # 异常处理代码
    error_info = traceback.format_exc()
    logger.error("%s", error_info)
    os._exit(255)
