#!/bin/sh

tftpd_start_on_midhaul_interface()
{
    local midhaul_ip=$1
    local ipaddr_str=""
    local result=""

    while true
    do
        ipaddr_str=$(ip addr)
        result=$(echo ${ipaddr_str} | grep "${midhaul_ip}")
        if [ "${result}" == "" ]; then
            sleep 1
        else
            systemctl start tftpd@${midhaul_ip}
            systemctl start tftpd_disk@${midhaul_ip}:60069
            break
        fi
    done
}

#
# Main loop of tftp server start shellscript
# If new type DU has been added, ${file} must add new line what new DU names,
# and ${start_flag} must add a '0' at array end.
#
tftpd_start_main_loop()
{
    local path="/run/.5gnr/app_data/net_mgmt/"
    local file=(
        "cu_5g_midhaul"
        "cu_4g_midhaul"
    )
    local start_flag=(0 0)
    local all_flag=0
    local midhaul_ip=""

    while true
    do
        let all_flag=0
        for i in $(seq 0 $((${#file[@]}-1)))
        do
            if [ ${start_flag[$i]} -ne 0 ]; then
                # This tftp server has started
                let all_flag+=1
                continue
            fi

            if [ ! -f "$path${file[$i]}" ]; then
                # File hasn't created
                continue
            fi

            midhaul_ip=""
            midhaul_ip=$(cat $path${file[$i]})
            if [ "${midhaul_ip}" == "" ]; then
                # File is null
                continue
            fi

            # Start tftp server on midhaul IP
            tftpd_start_on_midhaul_interface ${midhaul_ip}
            start_flag[$i]=1
            let all_flag+=1
        done
        if [ ${all_flag} -eq ${#start_flag[@]} ]; then
            break
        else
            sleep 3
        fi
    done
}

tftpd_stop_main_loop()
{
    local path="/run/.5gnr/app_data/net_mgmt/"
    local file=(
        "cu_5g_midhaul"
        "cu_4g_midhaul"
    )
    local midhaul_ip=""

    for i in $(seq 0 $((${#file[@]}-1)))
    do
        if [ ! -f "$path${file[$i]}" ]; then
            continue
        fi

        midhaul_ip=""
        midhaul_ip=$(cat $path${file[$i]})
        if [ "${midhaul_ip}" == "" ]; then
            continue
        fi

        # Stop tftp server on midhual IP
        systemctl stop tftpd@${midhaul_ip}
        systemctl stop tftpd_disk@${midhaul_ip}:60069
    done
}

# tftpd_start_main_loop &
case "${1}" in
    start)
        tftpd_start_main_loop &
        ;;

    stop)
        # Cannot run backstage
        tftpd_stop_main_loop
        ;;

    *)
        echo "No support."
        exit 1
        ;;
esac

