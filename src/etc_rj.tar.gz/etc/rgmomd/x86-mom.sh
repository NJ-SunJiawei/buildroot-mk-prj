#!/bin/sh
########################################################################
# Begin $rc_base/init.d/
#
# Description :
#
# Authors     :
#
# Version     : 00.00
#
# Notes       :
#
########################################################################

#. /etc/sysconfig/rc
#. ${rc_functions}

PROG=mom
if [ -f /lib64/libjemalloc.so ]; then
    export LD_PRELOAD="$LD_PRELOAD  /lib64/libjemalloc.so"
elif [ -f /lib/libjemalloc.so ]; then
    export LD_PRELOAD="$LD_PRELOAD  /lib/libjemalloc.so"
fi

case "${1}" in
    start)
        echo "Starting redis_host..."
        if [ ! -d "/tmp/redis/" ];then
            mkdir -p /tmp/redis
        fi
        cp -af /etc/redis/redis_host.conf /tmp/redis
        /sbin/redis-server /tmp/redis/redis_host.conf &
        /sbin/rgmomd &
        /sbin/mom_trace &
        #evaluate_retval
        #loadproc ${PROG}
        ;;

    vsd)
        echo "Starting VSD rgmomd..."
        /sbin/rgmomd &
        ;;

    stop)
        echo "Stopping mom..."
        pkill -15 rgmomd
        sleep 3
        ps -ef|grep redis-server |grep -v grep |grep redis_host.conf |awk '{print $2}' |xargs kill -15
        pkill -9 redis_
        pkill -9 mom_trace
        #killproc ${PROG}
        ;;

    reload)
        echo "Reloading ${PROG}..."
        #reloadproc ${PROG}
        ;;

    restart)
        ${0} stop
        sleep 5
        ${0} start
        ;;

    status)
        statusproc ${PROG}
        ;;

    *)
        echo "Usage: ${0} {start|stop|reload|restart|status}"
        exit 1
        ;;
esac

# End $rc_base/init.d/
