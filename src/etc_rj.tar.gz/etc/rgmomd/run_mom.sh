#!/bin/sh
rm -rf /tmp/redis/* 
case "${1}" in
        start)
                echo "Starting rgmomd redis_host"
                #ham&
                #sleep 1s
                /etc/rgmomd/x86-mom.sh start
                sleep 1s
                ;;
        restart)
                echo "restart rgmomd rgmoms.ham.."
                #pkill -9 ham
                #ham&
                /etc/rgmomd/x86-mom.sh restart
                sleep 1s
                ;;

        stop)
                echo "stop rgmomd rgmoms.ham.."
                #pkill -9 ham
                /etc/rgmomd/x86-mom.sh stop
                sleep 1s

                ;;
        *)
                echo "Usage: ${0} {start|stop|restart}"
                exit 1
                ;;
esac
