#!/bin/bash

#
# 清理ptp_mgmt服务运行环境
#
ptp_clean()
{
    echo "Clean up the running environment of PTP_MGMT service"
    /bin/rm -rf /var/log/zlog/ptp/
    /bin/rm -rf /data/.5gnr/log/zlog/ptp/
    /bin/rm -rf /run/.5gnr/app_data/ptp/
    /bin/rm -rf /run/.5gnr/log/zlog/ptp/
    /bin/rm -rf /run_isolate/log/zlog/ptp
}

#
# 初始化ptp_mgmt服务运行环境
#
ptp_init()
{
    echo "Initialize the PTP_MGMT service running environment"
    /bin/mkdir -p /run_isolate/log/zlog/ptp/ptp4l/
    /bin/mkdir -p /run/.5gnr/log/zlog/ptp/ptp_mgmt/
    /bin/mkdir -p /run_isolate/log/zlog/ptp/dpdk/
    /bin/mkdir -p /run/.5gnr/app_data/ptp/ptp4l/
    /bin/mkdir -p /run/.5gnr/app_data/ptp/ptp_mgmt/
    /bin/mkdir -p /run/.5gnr/app_data/ptp/dpdk/
    /bin/mkdir -p /run/.5gnr/app_data/bsp_pd
}

#
# 启动ptp_mgmt服务
#
ptp_start()
{
    echo "Start PTP_MGMT service"
    /sbin/ptp_mgmt &
    /sbin/ptp4l &
    echo "Start PTP_MGMT service end!"
}

#
# 停止ptp_mgmt服务
#
ptp_stop()
{
    echo "Stop PTP_MGMT service"
    kill `pidof ptp_mgmt` >/dev/null 2>&1
    kill `pidof ptp4l` >/dev/null 2>&1
    echo "Stop PTP_MGMT service end!"
}

main()
{
    case $1 in
        start)
            ptp_init;
            ptp_start;
            ;;

        stop)
            ptp_stop;
            ;;

        restart)
            ptp_stop;
            ptp_init;
            ptp_start;
            ;;

        *)
            echo "Usage: $0 {start|stop|restart}"
            exit 1
            ;;
    esac
}

main $@