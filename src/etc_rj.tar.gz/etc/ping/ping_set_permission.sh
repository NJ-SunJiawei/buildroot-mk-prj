#!/bin/sh

set_ping_permission()
{
    if [ -e /usr/bin/ping.elf ]; then
        chmod u+s /usr/bin/ping.elf
    fi
    if [ -e /usr/bin/ping6.elf ]; then
        chmod u+s /usr/bin/ping6.elf
    fi
#   set traceroute permission
    if [ -e /usr/bin/traceroute ]; then
        chmod u+s /usr/bin/traceroute
    fi
#	mkdir for eweb
	mkdir -p /run/.5gnr/app_data/ping_tracert
	chmod 777 /run/.5gnr/app_data/ping_tracert
}

set_ping_permission

