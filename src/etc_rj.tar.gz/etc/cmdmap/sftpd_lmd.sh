#!/bin/sh

# Source to import ZLOG environment variable settings
source /etc/profile

# Execute with no fork to maintain the parent-child relationship with procd
exec /usr/sbin/sftpd_lmd.elf
