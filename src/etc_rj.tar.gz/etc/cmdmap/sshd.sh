#!/bin/sh
# Donated code that was put under PD license.
#
# Stripped PRNGd out of it for the time being.

umask 022

CAT=/bin/cat
KILL=/bin/kill

sysconfdir=/etc/ssh
piddir=/var/run

SSHD=/usr/sbin/sshd
PIDFILE=$piddir/sshd.pid
PidFile=`grep "^PidFile" ${sysconfdir}/sshd_config | tr "=" " " | awk '{print $2}'`
[ X$PidFile = X ]  ||  PIDFILE=$PidFile

checkVarEmptyDir() {
    if [ ! -d /var/empty ]; then
        mkdir -p /var/empty
        chmod 755 /var/empty
        chown root:root /var/empty
    fi
}

checkVarEmptyDir

if [ -f /lib64/libjemalloc.so ]; then
    LD_PRELOAD=/lib64/libjemalloc.so exec ${SSHD} -D
elif [ -f /lib/libjemalloc.so ]; then
    LD_PRELOAD=/lib/libjemalloc.so exec ${SSHD} -D
else
    exec ${SSHD} -D
fi
