#!/bin/sh
# Donated code that was put under PD license.
#
# Stripped PRNGd out of it for the time being.

umask 022

SSHFSD=/usr/sbin/sshfsd

if [ -f /lib64/libjemalloc.so ]; then
    LD_PRELOAD=/lib64/libjemalloc.so exec ${SSHFSD} -D -f /etc/sshfs/sshfsd_config
elif [ -f /lib/libjemalloc.so ]; then
    LD_PRELOAD=/lib/libjemalloc.so exec ${SSHFSD} -D -f /etc/sshfs/sshfsd_config
else
    exec ${SSHFSD} -D -f /etc/sshfs/sshfsd_config
fi
