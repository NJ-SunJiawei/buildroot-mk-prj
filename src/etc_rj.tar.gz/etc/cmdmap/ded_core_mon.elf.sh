#!/bin/sh

. /etc/profile

PROG=ded_core_mon.elf
if [ -f /lib64/libjemalloc.so ]; then
    LD_PRELOAD=/lib64/libjemalloc.so exec /sbin/${PROG} -N "syscall,workqueue"
elif [ -f /lib/libjemalloc.so ]; then
    LD_PRELOAD=/lib/libjemalloc.so exec /sbin/${PROG} -N "syscall,workqueue"
else
    exec /sbin/${PROG} -N "syscall,workqueue"
fi

