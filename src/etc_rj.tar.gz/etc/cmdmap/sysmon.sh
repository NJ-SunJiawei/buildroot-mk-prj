#!/bin/sh

# ham重启进程脚本

. /etc/profile


if test -z "$(which systemctl)"; then
    /etc/rc.d/init.d/sysmon restart
else
    systemctl restart sysmon
fi

