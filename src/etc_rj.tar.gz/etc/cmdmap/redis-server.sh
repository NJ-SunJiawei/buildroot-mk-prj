#!/bin/sh

PROG=redis-server

if [ $1 == "/tmp/redis/redis_host.conf" ]; then

    if [ -f /lib64/libjemalloc.so ]; then
        LD_PRELOAD=/lib64/libjemalloc.so exec /sbin/${PROG} /tmp/redis/redis_host.conf &
    elif [ -f /lib/libjemalloc.so ]; then
        LD_PRELOAD=/lib/libjemalloc.so exec /sbin/${PROG} /tmp/redis/redis_host.conf &
    else
        exec /sbin/${PROG} /tmp/redis/redis_host.conf &
    fi

else
    exec /sbin/${PROG} /tmp/redis/redis_host.conf &
fi
