#!/bin/sh

mkdir -p /run/.5gnr/app_data/tsdb
mkdir -p /run_isolate/app_data/tsdb
exec /sbin/rdb-server /etc/tsdb/tsdb_0.conf &
