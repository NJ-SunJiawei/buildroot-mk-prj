#!/bin/sh

PROG=dis-inotify-server

if [ -f /lib64/libjemalloc.so ]; then
    LD_PRELOAD=/lib64/libjemalloc.so exec /sbin/${PROG}
elif [ -f /lib/libjemalloc.so ]; then
    LD_PRELOAD=/lib/libjemalloc.so exec /sbin/${PROG}
else
    exec /sbin/${PROG}
fi