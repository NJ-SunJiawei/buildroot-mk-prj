#!/bin/sh

PROG=dhcpc.elf

if [ -f /lib64/libjemalloc.so ]; then
    LD_PRELOAD=/lib64/libjemalloc.so exec /usr/sbin/${PROG} -sf /usr/sbin/dhcscript
elif [ -f /lib/libjemalloc.so ]; then
    LD_PRELOAD=/lib/libjemalloc.so exec /usr/sbin/${PROG} -sf /usr/sbin/dhcscript
else
    exec /usr/sbin/${PROG} -sf /usr/sbin/dhcscript
fi

