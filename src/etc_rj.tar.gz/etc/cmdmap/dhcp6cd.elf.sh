#!/bin/sh

PROG=dhcp6cd.elf

if [ -f /lib64/libjemalloc.so ]; then
    LD_PRELOAD=/lib64/libjemalloc.so exec /usr/sbin/${PROG}
elif [ -f /lib/libjemalloc.so ]; then
    LD_PRELOAD=/lib/libjemalloc.so exec /usr/sbin/${PROG}
else
    exec /usr/sbin/${PROG}
fi