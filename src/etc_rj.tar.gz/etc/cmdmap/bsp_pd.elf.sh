#!/bin/sh

#for ham restart bsp_pd
PROG=bsp_pd.elf
echo "" > /var/log/bsp/bsp.log
/usr/bin/stdbuf -oL /sbin/${PROG} >> /var/log/bsp/bsp.log 2>&1 &
