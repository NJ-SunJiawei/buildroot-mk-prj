#!/bin/sh

. /etc/profile

PROG=rg-fsui

if test -z "$(which systemctl)"; then
    /etc/rc.d/init.d/${PROG} restart
else
    systemctl restart ${PROG}
fi
