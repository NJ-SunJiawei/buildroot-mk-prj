#!/bin/sh

mkdir -p /etc/ipsec.d
mkdir -p /etc/ipsec.d/aacerts
mkdir -p /etc/ipsec.d/acerts
mkdir -p /etc/ipsec.d/cacerts
mkdir -p /etc/ipsec.d/certs
mkdir -p /etc/ipsec.d/crls
mkdir -p /etc/ipsec.d/ocspcerts
mkdir -p /etc/ipsec.d/private
mkdir -p /etc/ipsec.d/reqs
mkdir -p /etc/swanctl/bliss
mkdir -p /etc/swanctl/conf.d
mkdir -p /etc/swanctl/ecdsa
mkdir -p /etc/swanctl/pkcs8
mkdir -p /etc/swanctl/pkcs12
mkdir -p /etc/swanctl/private
mkdir -p /etc/swanctl/pubkey
mkdir -p /etc/swanctl/rsa
mkdir -p /etc/swanctl/x509
mkdir -p /etc/swanctl/x509aa
mkdir -p /etc/swanctl/x509ac
mkdir -p /etc/swanctl/x509ca
mkdir -p /etc/swanctl/x509crl
mkdir -p /etc/swanctl/x509ocsp

# End $rc_base/init.d/
