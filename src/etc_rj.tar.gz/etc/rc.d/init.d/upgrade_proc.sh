#!/bin/sh
########################################################################
# Begin $rc_base/init.d/
#
# Description :
#
# Authors     :
#
# Version     : 00.00
#
# Notes       :
#
########################################################################

#. /etc/sysconfig/rc
#. ${rc_functions}

PROG=upgrade_proc.elf
CLEAR_ENV_SHELL=/etc/rc.d/init.d/reset_run_linux_mark

case "${1}" in
	start)
		if [ -f /sbin/${PROG} ]; then
			echo "Starting ${PROG}..."
			if [ ! -d "/data/.5gnr/app_data/upgrade_proc/" ]; then
				mkdir -p /data/.5gnr/app_data/upgrade_proc/
			fi
			if [ ! -d "/run/.5gnr/app_data/upgrade_proc/" ]; then
				mkdir -p /run/.5gnr/app_data/upgrade_proc/
			fi
			if [ ! -d "/data/.5gnr/log/zlog/upgrade_proc/" ]; then
				mkdir -p /data/.5gnr/log/zlog/upgrade_proc/
			fi
			if [ ! -d "/run/.5gnr/log/zlog/upgrade_proc/" ]; then
				mkdir -p /run/.5gnr/log/zlog/upgrade_proc/
			fi
			/sbin/${PROG} &
		fi
		if [ -f ${CLEAR_ENV_SHELL} ]; then
			sh ${CLEAR_ENV_SHELL} &
		fi
		;;

	stop)
		echo "Stopping ${PROG}..."
		kill `pidof ${PROG}`
		;;

	restart)
		${0} stop
		sleep 1
		${0} start
		;;

	status)
		#statusproc ${PROG}
		;;

	*)
		echo "Usage: ${0} {start|stop|restart|status}"
		exit 1
		;;

esac

# End $rc_base/init.d/

