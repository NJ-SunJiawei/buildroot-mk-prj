#!/bin/sh

# ref to 
#   rtctl-1.13
#   tuned-2.9.0-1.el7_5.2
#   tuned-profiles-realtime-2.8.0-5.el7.noarch
#   etc.

OUTPUT_DIR=
# OUTPUT_DIR=">/dev/null 2>&1"

on_rt ()
{
    if [ -f /sys/kernel/realtime ]; then
        return 0
    fi
    return 1
}

service_running ()
{
    service=$1
    systemctl status $service | egrep "Active: active|; enabled\)" >/dev/null 2>&1
    return $?
}

disable_service ()
{
    service=$1
    echo "turning $service off"
    systemctl stop $service
    systemctl disable $service
}

# exit if not on a realtime kernel
if ! on_rt; then
    exit 0
fi

# if irqbalance is running and the user doesn't want it
# turn it off as it may hurt determinism in RT
if service_running irqbalance; then
    disable_service irqbalance
fi

# if cpuspeed is running and the user doesn't explicitly want it
# turn it off as it will hurt determinism
if service_running cpuspeed; then
    disable_service cpuspeed
fi

# kernel tools power
if [ -e /bin/cpupower ] ; then
    # this can not be excuted in VirtualBox
    cpupower -c all frequency-set -g performance ${OUTPUT_DIR}
fi
if [ -e /bin/x86_energy_perf_policy ] ; then
    x86_energy_perf_policy performance ${OUTPUT_DIR}
fi

if [ -e /sbin/sysctl ] ; then
    # profile latency-performance
    sysctl -w kernel.sched_min_granularity_ns=10000000 ${OUTPUT_DIR}
    sysctl -w vm.dirty_ratio=10 ${OUTPUT_DIR}
    sysctl -w vm.dirty_background_ratio=3 ${OUTPUT_DIR}
    sysctl -w vm.swappiness=10 ${OUTPUT_DIR}
    sysctl -w kernel.sched_migration_cost_ns=5000000 ${OUTPUT_DIR}
    
    # profile network-latency, kernel.numa_balancing not support
    # [vm] transparent_hugepages=never
    sysctl -w net.core.busy_read=50 ${OUTPUT_DIR}
    sysctl -w net.core.busy_poll=50 ${OUTPUT_DIR}
    sysctl -w net.ipv4.tcp_fastopen=3 ${OUTPUT_DIR}
    # sysctl -w kernel.numa_balancing=0 ${OUTPUT_DIR}
    
    # profile realtime
    sysctl -w kernel.hung_task_timeout_secs=600 ${OUTPUT_DIR}
    sysctl -w kernel.hardlockup_panic=1 ${OUTPUT_DIR}
    sysctl -w kernel.hardlockup_all_cpu_backtrace=1 ${OUTPUT_DIR}
    sysctl -w kernel.softlockup_all_cpu_backtrace=1 ${OUTPUT_DIR}
    sysctl -w kernel.softlockup_panic=1 ${OUTPUT_DIR}
    sysctl -w kernel.watchdog_cpumask=0 ${OUTPUT_DIR}
    sysctl -w kernel.sched_rt_runtime_us=-1 ${OUTPUT_DIR}
    sysctl -w vm.stat_interval=10 ${OUTPUT_DIR}
    sysctl -w kernel.timer_migration=0 ${OUTPUT_DIR}
else
    echo 10000000 > /proc/sys/kernel/sched_min_granularity_ns ${OUTPUT_DIR}
    echo 10 > /proc/sys/vm/dirty_ratio ${OUTPUT_DIR}
    echo 3 > /proc/sys/vm/dirty_background_ratio ${OUTPUT_DIR}
    echo 10 > /proc/sys/vm/swappiness ${OUTPUT_DIR}
    echo 5000000 > /proc/sys/kernel/sched_migration_cost_ns ${OUTPUT_DIR}

    echo 50 > /proc/sys/net/core/busy_read ${OUTPUT_DIR}
    echo 50 > /proc/sys/net/core/busy_poll ${OUTPUT_DIR}
    echo 3 > /proc/sys/net/ipv4/tcp_fastopen ${OUTPUT_DIR}
    # echo 0 > /proc/sys/kernel/numa_balancing ${OUTPUT_DIR}

    echo 600 > /proc/sys/kernel/hung_task_timeout_secs ${OUTPUT_DIR}
    echo 1 > /proc/sys/kernel/hardlockup_panic ${OUTPUT_DIR}
    echo 1 > /proc/sys/kernel/hardlockup_all_cpu_backtrace ${OUTPUT_DIR}
    echo 1 > /proc/sys/kernel/softlockup_all_cpu_backtrace ${OUTPUT_DIR}
    echo 1 > /proc/sys/kernel/softlockup_panic ${OUTPUT_DIR}
    echo 0 > /proc/sys/kernel/watchdog_cpumask ${OUTPUT_DIR}
    echo -1 > /proc/sys/kernel/sched_rt_runtime_us ${OUTPUT_DIR}
    echo 10 > /proc/sys/vm/stat_interval ${OUTPUT_DIR}
    echo 0 > /proc/sys/kernel/timer_migration ${OUTPUT_DIR}
fi

# profile latency-performance
# echo never > /sys/kernel/mm/transparent_hugepage/defrag
if [ -f /sys/kernel/mm/transparent_hugepage/enabled ] ; then
    echo never > /sys/kernel/mm/transparent_hugepage/enabled ${OUTPUT_DIR}
fi

if [ -f /sys/module/rcupdate/parameters/rcu_cpu_stall_suppress ]; then
    echo 1 > /sys/module/rcupdate/parameters/rcu_cpu_stall_suppress
fi

if [ -f /etc/not_isolated_cpumask ] ; then
    cpumask=`cat /etc/not_isolated_cpumask`

    # profile realtime
    if [ -f /sys/bus/workqueue/devices/writeback/cpumask ] ; then
        echo ${cpumask} > /sys/bus/workqueue/devices/writeback/cpumask ${OUTPUT_DIR}
    fi
    if [ -f /sys/devices/virtual/workqueue/cpumask ] ; then
        echo ${cpumask} > /sys/devices/virtual/workqueue/cpumask ${OUTPUT_DIR}
    fi

    for irq in `ls -d /proc/irq/*` ;
    do
        # some irq can not be set
        if [ -f ${irq}/smp_affinity ] ; then
            echo ${cpumask} > ${irq}/smp_affinity >/dev/null 2>&1
        fi
    done
fi
if [ -f /sys/devices/system/machinecheck/machinecheck0/ignore_ce ] ; then
    for ignore_ce in `ls -d /sys/devices/system/machinecheck/machinecheck*/ignore_ce` ;
    do
        echo 1 > ${ignore_ce} ${OUTPUT_DIR}
    done
fi

if [ -f /etc/not_isolated_cpulist ] ; then
    cpulist=`cat /etc/not_isolated_cpulist`
fi

# rt-setup
# turn SLUB cpu_partial logic offfor improved determinism
find /sys/kernel/slab -name 'cpu_partial' -print | \
     while read f; do echo 0 > $f ${OUTPUT_DIR}; done

exit 0
