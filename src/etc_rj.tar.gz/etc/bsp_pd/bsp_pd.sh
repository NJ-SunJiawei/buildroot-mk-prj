#!/bin/sh

. /etc/profile

PROG_NAME=bsp_pd.elf
PROG=/sbin/${PROG_NAME}

LTEU_MGMT_PROC_NAME=lteu_mgmt.elf
LTEU_MGMT_PROC=/usr/sbin/${LTEU_MGMT_PROC_NAME}

case "${1}" in
	start)
		#echo "Starting ${LTEU_MGMT_PROC_NAME}..."
		#exec ${LTEU_MGMT_PROC} &

		echo "Starting ${PROG_NAME}..."
		#if [ ! -d "/sys/bus/i2c/devices/i2c-0/0-0070/" ]; then
		#	echo pca9548 0x70 >  /sys/bus/i2c/devices/i2c-0/new_device
		#	sleep 1
		#fi
		
		#if [ ! -d "/sys/bus/i2c/devices/i2c-0/0-0077/" ]; then
		#	echo pca9548 0x77 >  /sys/bus/i2c/devices/i2c-0/new_device
		#	sleep 1
		#fi
		
		if [ ! -d "/run/.5gnr/app_data/gps/" ]; then
			mkdir -p /run/.5gnr/app_data/gps/
		fi
		
		if [ ! -f "/etc/mcu_status" ]; then
			touch /etc/mcu_status
		fi
		
		#bmc_ver=`sed -n 2p /etc/hwver/mcu`
		#hw_ver=$(rg_setmac | dos2unix | grep -w HardwareVersion | awk -F '=' '{print $2}')
		#if [ "$bmc_ver" != "1.0.0.0927" ] && [ "$hw_ver" != "1.00" ]; then
		#	bmc_upgrade /usr/sbin/mcu_mng/cu_bmc_update_0927.bin &
		#	sleep 30
		#fi

		upgrade_flag=0
		if [ ! -d "/etc/hwver/" ]; then
			mkdir /etc/hwver
			upgrade_flag=1
		fi

		if [ ! -f "/etc/hwver/mcu" ]; then
			touch /etc/hwver/mcu
		fi
		
		mkdir -p /var/log/bsp
		/usr/sbin/${PROG_NAME} >> /var/log/bsp/bsp.log 2>&1 &
        
		#chmod +x /sbin/lpc_test
		#var=`/sbin/lpc_test /dev/cpld1 0xA w | grep lpc_reg_read | awk '{print $5}'`
		#if [[ "$var" == "0x0" || $upgrade_flag -eq 1 ]]; then
		#if [ "$var" == "0x0" ]; then
		#	opt="set"	        
		#	if [ -f /sbin/fpga-upgrade.ko  ]; then
		#		insmod /sbin/fpga-upgrade.ko
		#	fi	

			#if [ ! -d "/sys/class/gpio/gpio3/" ]; then
			#	echo 3 > /sys/class/gpio/export
			#	echo out > /sys/class/gpio/gpio3/direction
			#	echo 0 > /sys/class/gpio/gpio3/value
			#	usleep 100000
			#	echo 1 > /sys/class/gpio/gpio3/value
	       		#fi
	       				
		#	sleep 25
		#	/sbin/lpc_test /dev/cpld1 0xA w 0x1
		#fi
		#echo -n "1.0.0." > /etc/hwver/fpga
		#hexdump -C /dev/port | grep 00000900 | awk '{print $5$4$3$2}' >> /etc/hwver/fpga

		cpld_ver0=`lpc_test /dev/cpld0 0`
		cpld_ver1=`lpc_test /dev/cpld0 1`
		cpld_ver2=`lpc_test /dev/cpld0 2`
		cpld_ver3=`lpc_test /dev/cpld0 3`
		cpld0_ver=${cpld_ver1:0-2}${cpld_ver2:0-2}${cpld_ver3:0-2}${cpld_ver0:0-2}
		cpld_ver0=`i2cget -y 4 0xf 0`
		cpld_ver1=`i2cget -y 4 0xf 1`
		cpld_ver2=`i2cget -y 4 0xf 2`
		cpld_ver3=`i2cget -y 4 0xf 3`
		cpld1_ver=${cpld_ver1:0-2}${cpld_ver2:0-2}${cpld_ver3:0-2}${cpld_ver0:0-2}
		echo $cpld0_ver"(0) "$cpld1_ver"(1) " > /etc/hwver/cpld

		boot_ok=`lpc_test /dev/cpld0 0x21`
		echo $boot_ok > /etc/hwver/boot_ok

		#/sbin/lpc_test /dev/fpga 0x80 w 1
		#/sbin/lpc_test /dev/cpld1 0x61 w 0x05

		#/sbin/mcu_mng/mcu_ver.sh
		#evaluate_retval
		;;

	stop)
		echo "Stopping ${PROG_NAME}..."
		kill -15 `pidof ${PROG}`

		#echo "Stopping ${LTEU_MGMT_PROC_NAME}..."
		#kill -15 `pidof ${LTEU_MGMT_PROC}`
		;;

	restart)
		echo "Restarting ${PROG_NAME}..."
		${0} stop
		sleep 1
		${0} start
		;;

	status)
		#statusproc ${PROG}
		ps -ef -o `pidof ${PROG}`
		#ps -ef -o `pidof ${LTEU_MGMT_PROC}`
		;;

	*)
		echo "Usage: ${0} {start|stop|restart|status}"
		exit 1
		;;
esac

# End $rc_base/init.d/

