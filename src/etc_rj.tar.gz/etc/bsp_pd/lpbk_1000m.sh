#!/bin/sh
########################################################################
# Begin $rc_base/init.d/
#
# Description :
#
# Authors     :
#
# Version     : 00.00
#
# Notes       :
#
########################################################################

#. /etc/sysconfig/rc
#. ${rc_functions}

PROG=lpbk_1000m.ko

case "${1}" in
	start)
		echo "Starting ${PROG}..."
        
        if [ -f /sbin/${PROG}  ]; then
            insmod /sbin/${PROG}
        fi 
		#evaluate_retval
		;;

	stop)
		echo "Stopping ${PROG}..."
		rmmod ${PROG}
		;;

	reload)
		echo "Reloading ${PROG}..."
		#reloadproc ${PROG}
		;;

	restart)
		${0} stop
		sleep 1
		${0} start
		;;

	status)
		#statusproc ${PROG}
		;;

	*)
		echo "Usage: ${0} {start|stop|reload|restart|status}"
		exit 1
		;;
esac

# End $rc_base/init.d/

