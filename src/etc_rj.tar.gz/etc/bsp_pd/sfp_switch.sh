#!/bin/sh

. /etc/profile

#PROG_NAME=
#PROG=/sbin/${PROG_NAME}

case "${1}" in
	start)
		echo "wait for NG/SFP+ creat..."
#		while [ ! -f "/run/.5gnr/ifcfg-prdpdk"  ]
#    	do
#      		sleep 1
#    	done
    	
		echo "Sfp on..."
		/sbin/lpc_test /dev/cpld1 0x51 w 0x3
		#evaluate_retval
		;;

	stop)
		echo "Sfp off..."
		/sbin/lpc_test /dev/cpld1 0x51 w 0x0
		;;

	reload)
		echo "Reloading ${PROG}..."
		#reloadproc ${PROG}
		;;

	restart)
		${0} stop
		sleep 1
		${0} start
		;;

	status)
		#statusproc ${PROG}
		;;

	*)
		echo "Usage: ${0} {start|stop|reload|restart|status}"
		exit 1
		;;
esac

# End $rc_base/init.d/

