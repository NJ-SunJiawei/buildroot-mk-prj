#!/bin/bash

pkg_type=${1}
dst_ver_key="HardwareVersion"
dst_ver_val="1.00"
dst_dev_id_key="projectid"
dst_dev_id_val="bbu_mc_x86_64"
dst_dev_id_val1="bbu_bb_x86_64"
rg_setmac > file.txt

judge_ver_is_skip()
{
	#5-->bios
	if [[ ($pkg_type == 5) && ($version == $dst_ver_val) ]]
	then
            if [[ ($dst_dev_id_val == $dev_id) || ($dst_dev_id_val1 == $dev_id) ]]
            then
          	rm -rf file.txt
        	echo "find the dst dev!"
        	return 0
            fi
	fi
	
	rm -rf file.txt
	return 1
}

for str in $(cat file.txt)
do
	if [[ $str =~ $dst_ver_key ]]
	then
    		echo "find str:${dst_ver_key}"
		version=`echo ${str#*=}`
		echo "version:${version}"
	fi
	if [[ $str =~ $dst_dev_id_key ]]
	then
		echo "find str:${dst_dev_id_key}"
		dev_id=`echo ${str#*=}`
		echo "dev_id:${dev_id}"
	fi
done

judge_ver_is_skip
