#!/bin/sh

DIR_FUNC=/etc/shell_lib
mount_table_file_external=/etc/upgrade/mount_table_main_upgrade
[ $FUNC_BOOTFLAG  ] || . ${DIR_FUNC}/func_bootflag
[ $FUNC_CHECKFILE ] || . ${DIR_FUNC}/func_checkfile
[ $FUNC_ENV       ] || . ${DIR_FUNC}/func_env
[ $FUNC_INSTALL   ] || . ${DIR_FUNC}/func_install
[ $FUNC_MKFS      ] || . ${DIR_FUNC}/func_mkfs
[ $FUNC_STORAGE   ] || . ${DIR_FUNC}/func_storage
[ $FUNC_UPGRADE   ] || . ${DIR_FUNC}/func_upgrade
[ $FUNC_WRAPPER   ] || . ${DIR_FUNC}/func_wrapper

bios_pre_at_rgos()   { return 0;}
bios_post_at_rgos()  { return 0;}
uboot_pre_at_rgos()  { return 0;}
uboot_post_at_rgos() { return 0;}
rboot_pre_at_rgos()  { return 0;}
rboot_post_at_rgos() { return 0;}
rootfs_pre_at_rgos() { return 0;}
rootfs_post_at_rgos(){ return 0;}
main_pre_at_rgos()   { return 0;}
main_post_at_rgos()  { return 0;}

set_rootfs_part(){
	local set_type=$1
	local bootflag=""
	local ret=0
	get_bootflag_running bootflag || {
		echo "    Get bootflag failed."
		return 5
	}
	echo "    Running rootfs: ${bootflag}"
	[ "${set_type}" = "change" ] && {
		case "${bootflag}" in
			"rootfs1") bootflag=rootfs2 ;;
			"rootfs2") bootflag=rootfs1 ;;
			*)
			echo "    Unknown rootfs ${bootflag}"
			return 5
		esac
	}

	fs_vaild_check_and_repair upgrade upgrade_bak || {
		echo "    Filesystem repair failed."
		ret=5
		false
	} && {
		echo "    Set rootfs to: ${bootflag}"
		set_bootflag_main ${bootflag} || {
			echo "    Set bootflag to ${bootflag} failed."
			ret=5
		}
	}
	echo "    recheck rootfs_part:"
	echo "    dump upgrade info:"
	dir=/run/.5gnr/app_data/shell_lib/upgrade_mnt
	ls -al ${dir}/upgrade
	cat ${dir}/upgrade/.rootfs_part
	md5sum ${dir}/upgrade/.rootfs_part
	cat ${dir}/upgrade/.rootfs_part.md5
	echo "    dump upgrade_bak info:"
	ls -al ${dir}/upgrade_bak
	cat ${dir}/upgrade_bak/.rootfs_part
	md5sum ${dir}/upgrade_bak/.rootfs_part
	cat ${dir}/upgrade_bak/.rootfs_part.md5
	sync

	umount_byname upgrade     || ret=5
	umount_byname upgrade_bak || ret=5
	echo "    before set_rootfs_part: ret=${ret}"
	df -h

	return ${ret}
}

mount_upgrade_rootfs(){
	local retn_name=$1
	local bootflag=""
	[ -n "${retn_name}" ] || return 4
	get_bootflag_running bootflag || {
		echo "    Get bootflag failed."
		return 4
	}
	echo "    Running rootfs: ${bootflag}"
	case "${bootflag}" in
		"rootfs1") bootflag=rootfs2 ;;
		"rootfs2") bootflag=rootfs1 ;;
		*)
			echo "    Unknown rootfs ${bootflag}"
			return 4
	esac
	echo "    Upgrade rootfs: ${bootflag}"
	mkfs_byname ${bootflag}
	fs_vaild_check_and_repair ${bootflag} || {
		echo "    Filesystem repair failed."
		return 4
	}
	eval ${retn_name}=\${bootflag}
}

rootfs_pre_at_rgos(){
	set_rootfs_part running || {
		echo "    Set default rootfs config failed."
		return 5
	}
	mount_upgrade_rootfs u_name || {
		echo "    Mount the rootfs device failed."
		return 4
	}
}

rootfs_post_at_rgos(){
	umount_byname ${u_name} || {
		echo "    Umount ${u_name} fail."
		return 1
	}
}

## only for double rootfs
upgrade_rootfs_at_rgos(){
	local mainfile=$1
	local target_x=$2
	local ret_var
	local u_name=""
	local u_mountpoint=""
	local tmp_dir_sqsh=/run/.5gnr/app_data/shell_lib/upgrade_mnt/sqsh
	ret_var=0
	echo "    Upgrade double rootfs."

	rootfs_pre_at_rgos || return

	while true
	do
		eval u_mountpoint=\${${u_name}_mountpoint}
		[ -n "${u_mountpoint}" ] && [ "${u_mountpoint}" != 'NA' ] || {
			echo "    Unknown mountpoint: ${u_mountpoint}"
			ret_var=4
			break
		}
		mkdir -p "${tmp_dir_sqsh}"
		umount "${tmp_dir_sqsh}" 2>/dev/null
		mount "${mainfile}" "${tmp_dir_sqsh}" || {
			echo "    Mount rootfs file failed."
			ret_var=6
			break
		}
		echo "    mainfile:${mainfile}"
		echo "    rootfs.sqsh version is:"
		cat ${tmp_dir_sqsh}/etc/build_version
		echo "    old rootfs version is "
		cat ${u_mountpoint}/etc/build_version
		[ -f /data/.5gnr/log/upgrade_sh/.upgrade.debug ] && {
			echo "    rootfs.sqsh etc/issue is:"
			cat ${tmp_dir_sqsh}/etc/issue
			echo "    old rootfs etc/issue is:"
			cat ${u_mountpoint}/etc/issue
		}
		rm -rf ${u_mountpoint}/* && cp -rpf ${tmp_dir_sqsh}/* ${u_mountpoint}/ || {
			echo "    Copy file to rootfs failed."
			ret_var=7
			umount "${tmp_dir_sqsh}"
			break
		}
		umount "${tmp_dir_sqsh}"
		echo "    after upgrade, new partition version:"
		cat ${u_mountpoint}/etc/build_version
		sync
		sync
		set_rootfs_part change || {
			echo "    Change rootfs config failed."
			ret_var=5
			break
		}
		ret_var=0
		break
	done

	rootfs_post_at_rgos || return
	return ${ret_var}
}

main_pre_at_rgos(){
	return 5
}

main_post_at_rgos(){
	return 5
}

upgrade_fpga_at_rgos(){
	local mainfile=$1
	local target_x=$2
	local install_target
	local cpld_slot
	local cpld_type
	local cpld_crc32
	local data_crc32
	local data_offset

	echo "    Upgrade fpga."

	{	checkfile_get_value_from_cpld_header "${mainfile}" TYPE cpld_type &&
		checkfile_get_value_from_cpld_header "${mainfile}" SLOT cpld_slot &&
		checkfile_get_value_from_cpld_header "${mainfile}" CRC cpld_crc32 &&
		checkfile_get_cpld_data_info "${mainfile}" data_offset &&
		crc32_rboot "${mainfile}" data_crc32 "${data_offset}"
	} || {
		echo "    Can't get fpga basic info."
		return 1
	}

	[ "${cpld_type}" = "fpga" ] || {
		echo "    The TYPE do not match  ..."
		return 1
	}
	[ -n "${cpld_crc32}" ] && [ -n "${data_crc32}" ] && echo ${cpld_crc32} | grep -wiq ${data_crc32} || {
		echo "    The CRC do not match  ..."
		return 1
	}

	install_target="${cpld_type}$((cpld_slot - 1))"
	echo "    Upgrade fpga target: ${install_target}"

	install_fpga "${mainfile}" "${install_target}" || return 1
	echo "    Upgrade fpga success."
	return 0
}

upgrade_fpga_from_dir(){
	local mainfile=$1
	local target_x=$2
	local fpga_file
	local retv

	if [ ! -d ${mainfile} ]; then
		echo "Fpga 1st param must be directory."
		return 1
	fi

	echo "Upgrade fpga in "${mainfile}""
	ls -al ${mainfile}

	for element in `ls ${mainfile}`
	do
		fpga_file=${mainfile}"/"${element}
		echo "test file "${fpga_file}""
		[ -f "${fpga_file}" ] && {
			echo "Start upgrade fpga ${fpga_file}"
			upgrade_fpga_at_rgos "${fpga_file}" ${target_x} || {
				retv=$?
				echo "Upgrade ${fpga_file} fail, exit"
				return ${retv}
			}
		}
	done

	return 0
}

## only for single rootfs
upgrade_main_at_rgos(){
	return 1
}

upgrade_uboot_at_rgos(){
        local mainfile=$1
        local target_x=$2
        local ret=0
        echo "    Upgrade uboot: ${target_x}"
        [ $((target_x & 1)) -eq 0 ] || install_uboot "${mainfile}" master_bootloader       || ret=1
        [ $((target_x & 1)) -eq 0 ] || install_uboot "${mainfile}" master_bootloader_other
#        [ $((target_x & 2)) -eq 0 ] || install_uboot "${mainfile}"  slave_bootloader       || ret=1
#       [ $((target_x & 4)) -eq 0 ] || install_uboot "${mainfile}" master_bootloader_other || ret=1
#       [ $((target_x & 8)) -eq 0 ] || install_uboot "${mainfile}"  slave_bootloader_other || ret=1
        return ${ret}
}

fix_flash_function(){
	rmmod intel_spi_pci
	rmmod intel_spi_platform 2>/dev/null
	rmmod intel_spi
	insmod /sbin/intel-spi.ko
	insmod /sbin/intel-spi-pci.ko
}

upgrade_bios_at_rgos(){
	local mainfile=$1
	local target_x=$2
	local ret=0
	local i=0
	echo "    Upgrade bios: ${target_x}"
	bios_pre_at_rgos || return

	until ((i>2))
	do
		ret=0
		[ $((target_x & 1)) -eq 0 ] || install_bios ${mainfile} BIOS_0_0 || ret=1
		[ $((target_x & 4)) -eq 0 ] || install_bios ${mainfile} BIOS_1_0 || ret=1
		[ ${ret} -eq 0 ] && break
		fix_flash_function
		let i++
	done

	bios_post_at_rgos || return
	return ${ret}
}

rboot_pre_at_rgos(){
	mount_byname rboot && return
	umount_byname rboot
	echo "    Mount rboot fail."
	return 5
}

rboot_post_at_rgos(){
	umount_byname rboot && return
	echo "    Umount rboot fail."
	return 5
}

upgrade_rboot_at_rgos(){
	local mainfile=$1
	local target_x=$2
	local ret=0
	echo "    Upgrade rboot: ${target_x}"
#	rboot_pre_at_rgos || return

	[ $((target_x & 1)) -eq 0 ] || install_rboot "${mainfile}" rboot       || ret=1
	[ $((target_x & 1)) -eq 0 ] || install_rboot "${mainfile}" rboot_other
#	[ $((target_x & 4)) -eq 0 ] || install_rboot "${mainfile}" rboot_other || ret=1

#        rboot_post_at_rgos || return
        return ${ret}
}

do_upgrade(){
	local upgrade_type=$1
	local mainfile=$2
	local target_x=$3
	local debug_x=$4

	echo "Upgrade Type: ${upgrade_type}"
	echo "Upgrade File: ${mainfile}"
	echo "Target      : ${target_x}"
	echo "Debug       : ${debug_x}"

	[ "${debug_x}" = "debug_on" ] && {
		echo "    Debug open."
		set -x
	}

	[ "${upgrade_type}" != "cpld-fpga" ] && [ ! -f "${mainfile}" ] && {
			echo "    File is not exist: ${mainfile}"
			return 2
	}

	case ${upgrade_type} in
	"uboot")  upgrade_uboot_at_rgos  "${mainfile}" ${target_x} ;;
	#"bios")   upgrade_bios_at_rgos   "${mainfile}" ${target_x} ;;
	"rboot")  upgrade_rboot_at_rgos  "${mainfile}" ${target_x} ;;
	"rootfs") upgrade_rootfs_at_rgos "${mainfile}" ${target_x} ;;
	#"main")   upgrade_main_at_rgos   "${mainfile}" ${target_x} ;;
	#"cpld-fpga") upgrade_fpga_from_dir "${mainfile}" ${target_x} ;;
	*)
		echo "    Unknown upgrade type."
		return 3
	esac
}

do_upgrade_loggee(){
	local do_upgrade_ret=1

	echo "========== Upgrade Start =========="

	do_upgrade "$@"
	do_upgrade_ret=$?

	echo "Upgrade retvar:${do_upgrade_ret}"
	echo "========== Upgrade   End =========="
	return ${do_upgrade_ret}
}

do_upgrade_logger(){
	local do_line
	local log_file=/data/.5gnr/log/upgrade_sh/.debug_upgrade_sh.log
	local bak_file=/data/.5gnr/log/upgrade_sh/.debug_upgrade_sh.log.bak
	mkdir -p /data/.5gnr/log/upgrade_sh/
	[ -f "${log_file}" ] && [ $(stat -c '%s' ${log_file}) -ge 524288 ] && {
		mv -f ${log_file} ${bak_file}
	}
	while read do_line || [ -n "${do_line}" ]
	do
		echo $(date "+%Y-%m-%d %H:%M:%S") "${do_line}" >> ${log_file}
	done
	return 0
}

set -o pipefail
do_upgrade_loggee "$@" 2>&1 | do_upgrade_logger
upgrade_result=$?
set +o pipefail

exit ${upgrade_result}
