#!/bin/sh

DIR_FUNC=/etc/shell_lib
[ -e "${DIR_FUNC}.bak" ] && [ -d "${DIR_FUNC}_bak" ] && DIR_FUNC="${DIR_FUNC}_bak"
mount_table_file_external=/etc/upgrade/mount_table_main_upgrade
[ $FUNC_BOOTFLAG  ] || . ${DIR_FUNC}/func_bootflag
[ $FUNC_MKFS      ] || . ${DIR_FUNC}/func_mkfs
[ $FUNC_STORAGE   ] || . ${DIR_FUNC}/func_storage

container_mount_pre_in_main(){
	fs_vaild_check_and_repair "$@" || {
		echo "    Filesystem repair failed."
		return 5
	}
}

container_mount_post_in_main(){
	local ret=0
	local mount_name
	for mount_name in $@
	do umount_byname ${mount_name} || ret=5
	done
	return ${ret}
}

container_mount_upgrade_in_main(){
	local ret=0
	local post_ret=0
	container_mount_pre_in_main  upgrade upgrade_bak || return
	"$@"
	ret=$?
	container_mount_post_in_main upgrade upgrade_bak || post_ret=$?
	return $((ret ? ret : post_ret))
}

container_mount_rootfs1_in_main(){
	local ret=0
	local post_ret=0
	container_mount_pre_in_main  rootfs1 || return
	"$@"
	ret=$?
	container_mount_post_in_main rootfs1 || post_ret=$?
	return $((ret ? ret : post_ret))
}

container_mount_rootfs2_in_main(){
	local ret=0
	local post_ret=0
	container_mount_pre_in_main  rootfs2 || return
	"$@"
	ret=$?
	container_mount_post_in_main rootfs2 || post_ret=$?
	return $((ret ? ret : post_ret))
}

check_bootfile_kernel_in_main(){
	local bootflag=$1
	local bootfile_kernel=""
	get_bootfile_kernel "${bootflag}" bootfile_kernel
	[ -f "${bootfile_kernel}" ]
}

set_rootfs_part(){
	local set_type=$1
	local bootflag=""
	local ret=0
	
	get_bootflag_running bootflag || {
		echo "    Get bootflag failed."
		return 5
	}
	echo "    Running rootfs: ${bootflag}"
	[ "${set_type}" = "unused" ] && {
		case "${bootflag}" in
			"rootfs1") bootflag=rootfs2 ;;
			"rootfs2") bootflag=rootfs1 ;;
			*)
				echo "    Unknown rootfs ${bootflag}"
				return 5
		esac
		case "${bootflag}" in
			"rootfs1") container_mount_rootfs1_in_main check_bootfile_kernel_in_main "${bootflag}" || ret=$? ;;
			"rootfs2") container_mount_rootfs2_in_main check_bootfile_kernel_in_main "${bootflag}" || ret=$? ;;
			*) ret=5
		esac
		[ ${ret} -eq 0 ] || {
			echo "    Kernel is missing in ${bootflag}."
			return 4
		}
	}
	echo "    Set rootfs to: ${bootflag}"
	set_bootflag_main ${bootflag} || {
		echo "    Set bootflag to ${bootflag} failed."
		return 5
	}
}

check_rootfs_part_running_in_main(){
	local bootflag_r=""
	local bootflag_m=""
	get_bootflag_running bootflag_r || {
		echo "    Get running bootflag failed."
		return 5
	}
	get_bootflag_main bootflag_m || {
		echo "    Get bootflag mark failed. Copy running to mark."
		set_bootflag_main ${bootflag_r}
		bootflag_m="${bootflag_r}"
	}
	echo "    Running rootfs: ${bootflag_r}"
	echo "    Rootfs in mark: ${bootflag_m}"

	[ "${bootflag_r}" = "${bootflag_m}" ] 
}

check_rootfs_in_main(){
	local target_x=$1
	
	case "${target_x}" in
	"running") container_mount_upgrade_in_main check_rootfs_part_running_in_main ;;
	*)
		echo "    Unknown switch type."
		return 3
	esac
}

switch_rootfs_in_main(){
	local target_x=$1
	
	case "${target_x}" in
	"running") container_mount_upgrade_in_main set_rootfs_part running ;;
	"unused")  container_mount_upgrade_in_main set_rootfs_part unused  ;;
	*)
		echo "    Unknown switch type."
		return 3
	esac
}

do_switch_rootfs(){
	local type_x=$1
	local target_x=$2
	local debug_x=$3
	
	echo "Type  : ${type_x}"
	echo "Target: ${target_x}"
	echo "Debug : ${debug_x}"
	
	[ "${debug_x}" = "debug_on" ] && {
		echo "    Debug open."
		set -x
	}

	case ${type_x} in
	"switch") switch_rootfs_in_main ${target_x} ;;
	"check")  check_rootfs_in_main  ${target_x} ;;
	*)
		echo "    Unknown switch rootfs type."
		return 3
	esac
}

do_switch_rootfs_loggee(){
	local do_switch_rootfs_ret=1

	echo "========== Switch Rootfs Start =========="

	do_switch_rootfs "$@"
	do_switch_rootfs_ret=$?
	
	echo "Switch Rootfs retvar:${do_switch_rootfs_ret}"
	echo "========== Switch Rootfs   End =========="
	return ${do_switch_rootfs_ret}
}

do_switch_rootfs_logger(){
	local do_line
	local log_file=/data/upgrade/log/.debug_switch_rootfs.log
	local bak_file=/data/upgrade/log/.debug_switch_rootfs.log.bak
	mkdir -p /data/upgrade/log
	[ -f "${log_file}" ] && [ $(stat -c '%s' ${log_file}) -ge 131072 ] && {
		mv -f ${log_file} ${bak_file}
	}
	while read do_line || [ -n "${do_line}" ]
	do
		echo $(date "+%Y-%m-%d %H:%M:%S") "${do_line}" >> ${log_file}
	done
	return 0
}

set -o pipefail
do_switch_rootfs_loggee "$@" 2>&1 | do_switch_rootfs_logger
switch_rootfs_result=$?
set +o pipefail

exit ${switch_rootfs_result}
