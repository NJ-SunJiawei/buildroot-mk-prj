#!/bin/sh
input_file=${1}
if [[ $(sed -n '/"Device.Ethernet.Interface.[0-9].VlanInterface.[0-9].Id" value="0"/'p $input_file) == "" ]];then
	sed -i 's/\([0-9]\).VlanInterface.[0-9]/1.VlanInterface.\1/' ${input_file}
	sed -i 's/\([0-9]\).IPv4Address/1.VlanInterface.&/' ${input_file}
else
	if [[ $(sed -n '/"Device.Ethernet.Interface.1.VlanInterface.[0-9].Id" value="0"/'p $input_file) != "" ]];then
		sed -i '/"Device.Ethernet.Interface.1.VlanInterface.[0-9]*.Id" value="0"/'d ${input_file}
	else
		sed -i 's/1.VlanInterface.[0-9]/1.VlanInterface.1/' ${input_file}
		sed -i 's/1.IPv4Address/1.VlanInterface.&/' ${input_file}
	fi
	if [[ $(sed -n '/"Device.Ethernet.Interface.2.VlanInterface.[0-9].Id" value="0"/'p $input_file) != "" ]];then
		sed -i '/"Device.Ethernet.Interface.2.VlanInterface.[0-9]*.Id" value="0"/'d ${input_file}
	else
		sed -i 's/2.VlanInterface.[0-9]/1.VlanInterface.2/' ${input_file}
		sed -i 's/2.IPv4Address/1.VlanInterface.&/' ${input_file}
	fi
fi
