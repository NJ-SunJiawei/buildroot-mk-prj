#
cwmp_private_value=X_WWW-RUIJIE-COM-CN
uppercase_value=RUIJIE
camelcases_value=RuiJie
cwmp_private_path=/etc/vender/cwmp_private
long_uppercase_path=/etc/vender/vender_name_long_uppercase
#
cfgname=$1

result=$(cat $cwmp_private_path)

#锐捷设备则无需白牌化
if [[ "$result" == "$cwmp_private_value" ]]; then
    exit 0
fi

sed -i "s/${cwmp_private_value}/${result}/g" $cfgname

result=$(cat $long_uppercase_path)
sed -i "s/${uppercase_value}/${result}/g" $cfgname
sed -i "s/${camelcases_value}/${result}/g" $cfgname

exit 0
