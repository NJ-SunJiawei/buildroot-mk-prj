#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import sys
import os
import time

ROOT_TAG_NAME = "Config"

def pretty_xml(element, indent="  ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    node=" "
    if element != None:  # 判断element是否有子元素   
        if len(element.getchildren()) == 0:
            node += str(element.tag)
            pass 
        elif (element.text is None) or element.text.isspace():  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
        # else:
        #     element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * (level + 1)
        else:  # 此处两行如果把注释去掉，Element的text也会另起一行
            element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * level

    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def foreach_xml(element, node, node_list):
    if element != None:
        # 有子元素无属性
        if len(element.getchildren()) and len(element.attrib) == 0:
            if str(element.tag) != ROOT_TAG_NAME:
                node += element.tag + '.'
        # 有属性
        elif len(element.attrib) != 0:
            node += element.tag + '.' + element.attrib['instance_id']
            #无子元素说明结束
            if len(element.getchildren()) == 0:
                node_list.append({'path': node, 'value': None})
                pass
            else:
                node += '.'
        #无子元素
        else:
            node += element.tag
            node_list.append({'path': node, 'value': element.text})
            node = ""
            pass
    # 将element转成list
    temp = list(element)
    for subelement in temp:
        # 对子元素进行递归操作
        foreach_xml(subelement, node, node_list)

def gen_xpath(node_list, inst_list):
    i = 0
    path = ""
    for node in node_list:
        if node.isdigit():
            path += '[@instance_id="%s"]/' % inst_list[i]
            i += 1
        else:
            path += node + "/"
    return path.strip("/")


def build_new_xml(root_ele, i, new_list, inst_list, value):
    if i >= len(new_list):
        return

    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if root_ele.find(new_xp) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
        i += 2
        build_new_xml(root_ele, i, new_list, inst_list, value)
        inst_list.pop()
        i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            if len(new_list[:i]):
                ET.SubElement(cu_ele, new_list[i])
            else:
                ET.SubElement(root_ele, new_list[i])
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = value
        i += 1
        build_new_xml(root_ele, i, new_list, inst_list, value)
        i -= 1


def recur_mkele(root_ele, old_list, i, new_list, inst_list):
    if i >= len(new_list):
        return
    if i + 1 != len(new_list) and new_list[i + 1] == "{i}":
        old_xp = gen_xpath(old_list[:i + 1], inst_list)

        for ele in root_ele.findall(old_xp):
            inst_list.append(ele.attrib["instance_id"])
            new_xp = gen_xpath(new_list[:i + 2], inst_list)
            if root_ele.find(new_xp) == None:
                cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
                ET.SubElement(cu_ele, new_list[i], {"instance_id":ele.attrib["instance_id"]})
            i += 2
            recur_mkele(root_ele, old_list, i, new_list, inst_list)
            inst_list.pop()
            i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i])
        if i + 1 == len(new_list):
            old_xp = gen_xpath(old_list[:i + 1], inst_list)
            leaf_val = root_ele.find(old_xp).text

            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = leaf_val
        i += 1
        recur_mkele(root_ele, old_list, i, new_list, inst_list)
        i -= 1

LOG_PATH = "/run_isolate/local_log/enb_cu"

NODE_NOT_MATCH = 0
NODE_CHANGE = 1
NODE_NOT_CHANGE = 2
NODE_DISCARD = 3

IPV4 = 4
IPV6 = 6

MAX_UINT_VALUE = 4294967295

DUPLEX_MODE_TDD = 0
DUPLEX_MODE_FDD = 1
DUPLEX_MODE_FDD_TDD = 2

TDD_DEFAULT_FREQ_BAND = 41
TDD_DEFAULT_EARFCNDL = 40940
TDD_DEFAULT_EARFCNUL = TDD_DEFAULT_EARFCNDL
TDD_DEFAULT_BAND_WIDTH = 100
TDD_DEFAULT_SSP = 7
TDD_DEFAULT_SA = 2

FDD_DEFAULT_FREQ_BAND = 3
FDD_DEFAULT_EARFCNDL = 1300
FDD_DEFAULT_EARFCNUL = 19300
FDD_DEFAULT_BAND_WIDTH = 100

# DU实例号列表
g_du_inst_list = list()

# 运营商信息列表
g_enb_op_info_list = list()

# 小区绑定的运营商信息列表
g_ltecell_op_info_list = list()

# MME绑定的运营商实信息列表
g_mme_op_info_list = list()

# lte的linkhost res开关
g_lte_LinkHost_info = {"IpVersion":"4", "S1CLocIpAddr":None, "S1CV6LocIpAddr":None, "S1ULocIpAddr":None, "S1UV6LocIpAddr":None}
g_lte_LinkHostRes_info = {"Switch":"0", "LinkOpId":"1", "S1CLocIpAddr":None, "S1CV6LocIpAddr":None, "S1ULocIpAddr":None, "S1UV6LocIpAddr":None}

# 4G邻区主eci信息
g_4g_nbr_primary_info = list()

g_ipv4_info_list = list()

g_ipv6_info_list = list()

g_config_need_change = False

g_lte_cell_info_list = list()

g_enb_info = {"EnbId":None, "EnbName":None}

g_du_frm_info_list = list()

g_du_slot_state = [False, False, False, False, False, False]

# 当前版本支持制式
g_duplex_mode_support = DUPLEX_MODE_FDD_TDD

g_fdd_support_freq_band_list = [3]
g_tdd_support_freq_band_list = [41]


def get_duplex_mode_support():
    global g_duplex_mode_support
    g_duplex_mode_support = DUPLEX_MODE_FDD_TDD
    duplex_mode_support_file = "/sbin/enb/cfg/duplexing_mode_support.txt"
    if os.access(duplex_mode_support_file, os.F_OK):
        file = open(duplex_mode_support_file, 'r')
        content = file.read()
        file.close()
        # 后续版本如同时支持 TDD 和 FDD, 该文件要删掉
        if "tdd" in content:
            g_duplex_mode_support = DUPLEX_MODE_TDD
        elif "fdd" in content:
            g_duplex_mode_support = DUPLEX_MODE_FDD


def write_log_file(str):
    if not os.path.exists(LOG_PATH):
        os.system("mkdir -p {0}".format(LOG_PATH))
    file = open("{0}/PJ3_xml_trans_PJ3S3_LTE.log".format(LOG_PATH), 'a')
    file.write("{0} : {1}\n".format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), str))
    file.close()


def get_all_du_slot_state():
    for slot_id in range(1, len(g_du_slot_state) + 1):
        file_name = "/sys/localbus/du/slot{0}/state".format(slot_id)
        if os.access(file_name, os.F_OK):
            file = open(file_name, 'r')
            state = file.read()
            file.close()
            if "1" in state:
                g_du_slot_state[slot_id - 1] = True
            #print(g_du_slot_state)


def is_du_exist(slot_id):
    if slot_id < 1:
        return False
    return g_du_slot_state[slot_id - 1]


# 若配置匹配后还需要对/sys/localbus/du/slot*/state文件内容进行读取，为1则表示DU存在该槽位，则可以认定小区80在该slot上，否则继续遍历配置
# 若存在frm配置而无DU在槽位上，则slotid取最后一个遍历到配置
# 若不存在frm配置，则slotid默认为1
def get_du_slot_id_by_cellid(cellid):
    # 小区所在DU的槽号默认为1
    slot_id = 1
    for du_frm_info in g_du_frm_info_list:
        if cellid in du_frm_info["cellid_list"]:
            slot_id = du_frm_info["DuFrm"]
            if is_du_exist(slot_id):
                # print(slot_id)
                return du_frm_info["DuFrm"]
    # print(slot_id)
    return slot_id


def update_lte_cell_info_list(fap_inst, key, value):
    if key in ["PhyCellID", "UserLabel", "RootSequenceIndex", "TAC", "CellIdentity", "FreqBandIndicator"]:
        cell_exist = False
        if g_lte_cell_info_list:
            for lte_cell_info in g_lte_cell_info_list:
                if lte_cell_info["fap_inst"] == fap_inst:
                    cell_exist = True
                    lte_cell_info[key] = value
        if cell_exist is False:
            new_cell_info = {"fap_inst":fap_inst, "PhyCellID":None, "UserLabel":None, "RootSequenceIndex":None, "TAC":None, "CellIdentity":None, "FreqBandIndicator":None}
            new_cell_info[key] = value
            g_lte_cell_info_list.append(new_cell_info)
        #print(g_lte_cell_info_list)


def get_cur_cell_cfg(fap_inst, key):
    value = None
    if g_lte_cell_info_list:
        for lte_cell_info in g_lte_cell_info_list:
            if lte_cell_info["fap_inst"] == fap_inst:
                return lte_cell_info[key]
    return value

#fix bug 1148864
def check_trigger_configuration_conversion_patch_function(node_list):
    try:
        fap_service_data = {}

        for item in node_list:
            path_parts = item['path'].split('.')
            if "InternetGatewayDevice.Services.FAPService." in item['path']:
                fap_service_id = path_parts[path_parts.index('FAPService') + 1]
                if fap_service_id not in fap_service_data:
                    fap_service_data[fap_service_id] = {}

                if 'FreqBandIndicator' in item['path']:
                    fap_service_data[fap_service_id]['FreqBandIndicator'] = item['value']
                elif 'DLBandwidth' in item['path']:
                    fap_service_data[fap_service_id]['DLBandwidth'] = item['value']
                elif 'ULBandwidth' in item['path']:
                    fap_service_data[fap_service_id]['ULBandwidth'] = item['value']
                elif 'EARFCNDL' in item['path']:
                    fap_service_data[fap_service_id]['EARFCNDL'] = item['value']
                elif 'EARFCNUL' in item['path']:
                    fap_service_data[fap_service_id]['EARFCNUL'] = item['value']
                elif 'CellActiveState' in item['path']:
                    fap_service_data[fap_service_id]['CellActiveState'] = item['value']
                elif 'Slot' in item['path'] and 'X_WWW-RUIJIE-COM-CN' in item['path']:
                    fap_service_data[fap_service_id]['Slot'] = item['value']
                elif 'DuplexMode' in item['path'] and 'X_WWW-RUIJIE-COM-CN' in item['path']:
                    fap_service_data[fap_service_id]['DuplexMode'] = item['value']
                    
        for fap_service_id, data in fap_service_data.items():
            if 'FreqBandIndicator' in data and 'DLBandwidth' in data and 'ULBandwidth' in data and 'EARFCNDL' in data and 'EARFCNUL' in data and 'CellActiveState' in data:
                if 'Slot' in data or 'DuplexMode' in data:
                    print('false')
                    return False
                if data['FreqBandIndicator'] == '41' and data['DLBandwidth'] == '100' and data['ULBandwidth'] == '100' and data['EARFCNDL'] == '40940' and data['EARFCNUL'] == '40940' and data['CellActiveState'] == '0':
                    return True
    except Exception as e:
        print("An error occurred: {}".format(str(e)))
        return False

    return False

def get_base_info_from_node_list(node_list):
    for node_dict in node_list:
        # 获取当前基站存在的运营商实例号
        if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            if split_list[7] == "PLMNID":
                inst = int(split_list[6])
                inst_list = [x["inst"] for x in g_enb_op_info_list]
                if inst not in inst_list:
                    g_enb_op_info_list.append({"inst":inst, "plmnid":node_dict['value']})
                #print(g_enb_op_info_list)
        elif ".CellConfig.LTE.EPC.PLMNList." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            if split_list[9] == "PLMNID":
                inst = int(split_list[3])
                inst_list = [x["inst"] for x in g_ltecell_op_info_list]
                if inst not in inst_list:
                    plmn_list = list()
                    plmn_list.append(node_dict['value'])
                    g_ltecell_op_info_list.append({"inst":inst, "plmn_list":plmn_list})
                else:
                    for op_info in g_ltecell_op_info_list:
                        if op_info["inst"] == inst:
                            op_info["plmn_list"].append(node_dict['value'])
                #print(g_ltecell_op_info_list)
        elif ".CellConfig.LTE.MmePoolConfigParam." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            if "OperatorIDList" in node_dict['path']:
                mme_inst = int(split_list[7])
                g_mme_op_info_list.append({"inst":mme_inst, "op_id_list":node_dict['value'].split(",")})
                #print(g_mme_op_info_list)
        elif "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.LTE.LinkHost" in node_dict['path']:
            print('enter')
            global g_config_need_change
            g_config_need_change = True
            split_list = node_dict['path'].split(".")
            if split_list[4] == "LinkHost":
                if split_list[5] in ["IpVersion", "S1CLocIpAddr", "S1ULocIpAddr", "S1UV6LocIpAddr"]:
                    g_lte_LinkHost_info[split_list[5]] = node_dict['value']
            elif split_list[4] == "LinkHostRes":
                if split_list[5] in ["Switch", "LinkOpId", "S1CLocIpAddr", "S1ULocIpAddr", "S1UV6LocIpAddr"]:
                    g_lte_LinkHostRes_info[split_list[5]] = node_dict['value']
        elif ".CellConfig.LTE.RAN.NeighborList.LTECell." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = split_list[3]
            nbr_inst = split_list[9]
            if "X_WWW-RUIJIE-COM-CN" in node_dict['path'] and split_list[11] in ["PrimaryNbrCellID", "PrimaryEnbID"]:
                nbr_exist = False
                for nbr_info in g_4g_nbr_primary_info:
                    if nbr_info["fap_inst"] == fap_inst:
                        if nbr_info["nbr_inst"] == nbr_inst:
                            nbr_exist = True
                            nbr_info[split_list[11]]=int(node_dict['value'])
                if nbr_exist is False:
                    if split_list[11] == "PrimaryNbrCellID":
                        g_4g_nbr_primary_info.append({"fap_inst":fap_inst, "nbr_inst":nbr_inst, "PrimaryNbrCellID":int(node_dict['value']), "PrimaryEnbID":0})
                    else:
                        g_4g_nbr_primary_info.append({"fap_inst":fap_inst, "nbr_inst":nbr_inst, "PrimaryNbrCellID":0, "PrimaryEnbID":int(node_dict['value'])})
                #print(g_4g_nbr_primary_info)
        # Device.Ethernet.Interface.{i}.IPv4Address.{i}.IPAddress
        # Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.IPAddress
        elif "Device.Ethernet.Interface." in node_dict['path'] and ".IPv4Address." in node_dict['path'] and "IPAddress" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            interface_inst = int(split_list[3])
            if "VlanInterface" in node_dict['path']:
                vlan_interface_ins = int(split_list[5])
                ipv4_addr_inst = int(split_list[7])
            else:
                vlan_interface_ins = 0
                ipv4_addr_inst = int(split_list[5])
            g_ipv4_info_list.append({"Interface":interface_inst, "VlanInterface":vlan_interface_ins,"IPv4Address":ipv4_addr_inst, "IPAddress":node_dict['value'],"PortType":None})
            #print(g_ipv4_info_list)
        # Device.Ethernet.Interface.{i}.IPv6Address.{i}.IPAddress
        # Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.IPAddress
        elif "Device.Ethernet.Interface." in node_dict['path'] and ".IPv6Address." in node_dict['path'] and "IPAddress" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            interface_inst = int(split_list[3])
            if "VlanInterface" in node_dict['path']:
                vlan_interface_ins = int(split_list[5])
                ipv6_addr_inst = int(split_list[7])
            else:
                vlan_interface_ins = 0
                ipv6_addr_inst = int(split_list[5])
            g_ipv6_info_list.append({"Interface":interface_inst, "VlanInterface":vlan_interface_ins,"IPv6Address":ipv6_addr_inst, "IPAddress":node_dict['value'],"PortType":None})
            #print(g_ipv6_info_list)
        elif ".CellConfig.LTE.RAN.RF." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            if split_list[8] in ["PhyCellID", "UserLabel", "FreqBandIndicator"]:
                update_lte_cell_info_list(fap_inst, split_list[8], node_dict['value'])
        elif ".CellConfig.LTE.RAN.PHY.PRACH.RootSequenceIndex" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            update_lte_cell_info_list(fap_inst, "RootSequenceIndex", node_dict['value'])
        elif ".CellConfig.LTE.EPC.TAC" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            update_lte_cell_info_list(fap_inst, "TAC", node_dict['value'])
        elif ".CellConfig.LTE.RAN.Common.CellIdentity" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            update_lte_cell_info_list(fap_inst, "CellIdentity", node_dict['value'])
        elif "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Common." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            g_enb_info[split_list[6]] = node_dict['value']
        elif "Device.X_WWW-RUIJIE-COM-CN.DuFrm." in node_dict['path'] and ".FrmCli.LteDuCellCoverage." in node_dict['path'] and "LteDuCellId" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            du_frm_inst = int(split_list[3])
            inst_list = [x["DuFrm"] for x in g_du_frm_info_list]
            if du_frm_inst not in inst_list:
                cellid_list = list()
                cellid_list.append(int(node_dict['value']))
                g_du_frm_info_list.append({"DuFrm":du_frm_inst, "cellid_list":cellid_list})
            else:
                for du_frm_info in g_du_frm_info_list:
                    if du_frm_info["DuFrm"] == du_frm_inst and int(node_dict['value']) not in du_frm_info["cellid_list"]:
                        du_frm_info["cellid_list"].append(int(node_dict['value']))
            #print(g_du_frm_info_list)


def plmnid_to_op_inst(plmnid):
    for enb_op_info in g_enb_op_info_list:
        if enb_op_info["plmnid"] == plmnid:
            return enb_op_info["inst"]
    return 0


def op_inst_to_plmnid(inst):
    for enb_op_info in g_enb_op_info_list:
        if enb_op_info["inst"] == inst:
            return enb_op_info["plmnid"]
    return "0"


def PJ3_A1_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.ConnMode.EUTRA.A1MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        inst = int(split_list[11])
        # S3    真实例有1(异频) 4(NR异系统)
        # PJ3   真实例有1(异频) 3(异系统GERAN) 7(语音异系统NR) 9(语音异系统GERAN) 10(NR异系统)
        # PJ3的实例1对应S3的实例1(异频)
        # PJ3的实例10对应S3的实例4(NR异系统)
        if inst == 1:
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif inst == 10:
            node_dict['path'] = ''
            split_list[11] = '4'
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            #print node_dict['path']
            ret = NODE_CHANGE
    return ret

def PJ3_A2_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.ConnMode.EUTRA.A2MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        inst = int(split_list[11])
        # S3    真实例有1(异频) 4(盲重定向异系统UTRA) 5(盲重定向异系统GERAN) 6(异系统NR) 7(盲重定向异系统NR)
        # PJ3   真实例有1(异频) 3(异系统GERAN) 5(盲重定向异系统GERAN) 6(盲重定向异系统NR) 7(语音异系统NR) 9(语音异系统GERAN) 10(异系统NR)
        # PJ3的实例1对应S3的实例1(异频)
        # PJ3的实例5对应S3的实例5(盲重定向异系统GERAN)
        # PJ3的实例6对应S3的实例7(盲重定向异系统GERAN), 测量目的固定填11.
        # PJ3的实例10对应S3的实例6(异系统NR), 测量目的固定填10.
        if inst in [1, 5]:
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif inst == 6:
            if "MeasurePurpose" in node_dict['path']:
                node_dict['value'] = '11'
            node_dict['path'] = ''
            split_list[11] = '7'
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif inst == 10:
            if "MeasurePurpose" in node_dict['path']:
                node_dict['value'] = '10'
            node_dict['path'] = ''
            split_list[11] = '6'
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.{i}.X_WWW-RUIJIE-COM-CN.TriggerQuantity,PJ3 [RSRP,RSRQ,SINR] S3[0,1,2]
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.1.B1ThresholdCDMA2000
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.1.B1ThresholdGERAN
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.1.B1ThresholdUTRAEcN0
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.1.B1ThresholdUTRARSCP
def PJ3_B1_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl." in node_dict['path']:
        ret = NODE_DISCARD
        if "B1ThresholdCDMA2000" in node_dict['path'] or\
        "B1ThresholdGERAN" in node_dict['path'] or\
        "B1ThresholdUTRAEcN0" in node_dict['path'] or\
        "B1ThresholdUTRARSCP" in node_dict['path']:
            return ret
        elif "TriggerQuantity" in node_dict['path']:
            TriggerQuantity_dict = {"RSRP":"0", "RSRQ":"1" ,"SINR":"2"}
            node_dict['value'] = TriggerQuantity_dict[node_dict['value']]

        split_list = node_dict['path'].split(".")
        inst = int(split_list[11])
        # S3    真实例有4(语音异系统NR) 3(异系统NR) 5(异系统NR优选)
        # PJ3   真实例有2(异系统GERAN) 3(语音异系统GERAN) 4(语音异系统NR) 5(异系统NR) 6(异系统NR优选)
        # PJ3的实例4对应S3的实例4(语音异系统NR), 测量目的固定填11.
        # PJ3的实例5对应S3的实例3(异系统NR), 测量目的固定填10.
        # PJ3的实例6对应S3的实例5(异系统NR优选), 测量目的固定填12.
        if inst == 4:
            if "MeasurePurpose" in node_dict['path']:
                node_dict['value'] = '11'
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif inst == 5:
            if "MeasurePurpose" in node_dict['path']:
                node_dict['value'] = '10'
            node_dict['path'] = ''
            split_list[11] = '3'
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif inst == 6:
            if "MeasurePurpose" in node_dict['path']:
                node_dict['value'] = '12'
            node_dict['path'] = ''
            split_list[11] = '5'
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

#PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.X_WWW-RUIJIE-COM-CN.B2ThresholdNRSINR
#S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.X_WWW-RUIJIE-COM-CN.B2Threshold2NRSINR
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.X_WWW-RUIJIE-COM-CN.TriggerQuantity,PJ3 [RSRP,RSRQ,SINR] S3[0,1,2]
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.B2Threshold2CDMA2000
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.B2Threshold2GERAN
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.B2Threshold2UTRAEcN0
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.B2Threshold2UTRARSCP
def PJ3_B2_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl." in node_dict['path']:
        ret = NODE_DISCARD
        if "B2Threshold2CDMA2000" in node_dict['path'] or\
        "B2Threshold2GERAN" in node_dict['path'] or\
        "B2Threshold2UTRAEcN0" in node_dict['path'] or\
        "B2Threshold2UTRARSCP" in node_dict['path']:
            return ret

        split_list = node_dict['path'].split(".")
        inst = int(split_list[11])
        # S3    真实例有3(异系统NR)
        # PJ3   真实例有2(异系统GERAN) 3(语音异系统GERAN) 4(语音异系统NR) 5(异系统NR)
        # PJ3的实例5对应S3的实例3(异系统NR), 测量目的固定填10.
        if inst == 5:
            split_list[11] = '3'
            if "MeasurePurpose" in node_dict['path']:
                node_dict['value'] = '10'
            elif "B2ThresholdNRSINR" in node_dict['path']:
                split_list[-1] = "B2Threshold2NRSINR"
            elif "TriggerQuantity" in node_dict['path']:
                TriggerQuantity_dict = {"RSRP":"0", "RSRQ":"1" ,"SINR":"2"}
                node_dict['value'] = TriggerQuantity_dict[node_dict['value']]
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret


# S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.EPC.X_WWW-RUIJIE-COM-CN.OperatorPolicy.{i}.CSFBDefaultIrat
# PJ3 InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.EnodebCfgSwitch.CsfbPolicy, 映射所有小区实例下，所有运营商实例
# S3  Device.X_WWW-RUIJIE-COM-CN.GnbMgr.{i}.PHY.LteGpsTimeCfg.Value
# PJ3 InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.EnodebCfgSwitch.TddFrameOffset
# 1、基站级变成DU板级
# 2、提前量变成延迟量（即A变成负A）
# 3、若当前版本只支持FDD, 则抛弃该节点
def PJ3_EnodebCfgSwitch_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.EnodebCfgSwitch." in node_dict['path']:
        ret = NODE_DISCARD
        if "CsfbPolicy" in node_dict['path']:
            for ltecell_op_info in g_ltecell_op_info_list:
                for plmn_id in ltecell_op_info["plmn_list"]:
                    op_inst = int(plmnid_to_op_inst(plmn_id))
                    if op_inst != 0:
                        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.EPC.X_WWW-RUIJIE-COM-CN.OperatorPolicy.{1}.EnbOperatorId".format(ltecell_op_info["inst"], op_inst), 'value':str(op_inst - 1)}
                        new_node_list.append(new_node)
                        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.EPC.X_WWW-RUIJIE-COM-CN.OperatorPolicy.{1}.CSFBDefaultIrat".format(ltecell_op_info["inst"], op_inst), 'value':node_dict['value']}
                        new_node_list.append(new_node)
                    ret = NODE_CHANGE
        elif "TddFrameOffset" in node_dict['path']:
            if g_duplex_mode_support == DUPLEX_MODE_FDD:
                ret = NODE_DISCARD
            else:
                for du_frm_info in g_du_frm_info_list:
                    if is_du_exist(du_frm_info["DuFrm"]) is True:
                        new_node = {'path':"Device.X_WWW-RUIJIE-COM-CN.GnbMgr.{0}.PHY.LteGpsTimeCfg.Value".format(du_frm_info["DuFrm"]), 'value':str(-int(node_dict['value']))}
                        new_node_list.append(new_node)
                        ret = NODE_CHANGE
    return ret


# S3  新增OperatorType和EnbOperatorId节点
# 1、实例1，OperatorType固定0主，其他固定1从
# 2、EnbOperatorId等于实例号减1
# 当配置文件不存在InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Common.EnbId\EnbName配置时,添加InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{i}.EnbId\EnbName,其值分别为1993\Bingo1993
# 当配置文件不存在InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.EPC.TAC配置时,添加InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{i}.TAC,其值为12596
# 当link host的IpVersion为ipv6时,新增以下节点,其值 0表示ipv4, 1表示ipv6
#   InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{i}.S1cIpVersion
#   InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{i}.S1uIpVersion
#   InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{i}.X2cIpVersion
#   InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{i}.X2uIpVersion
def PJ3_Operator_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator." in node_dict['path']:
        split_list = node_dict['path'].split(".")
        if split_list[7] == "PLMNID":
            new_node_list.append(node_dict)
            inst = int(split_list[6])
            if inst == 1:
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.OperatorType".format(inst), 'value':'0'}
            else:
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.OperatorType".format(inst), 'value':'1'}
            new_node_list.append(new_node)
            new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.EnbOperatorId".format(inst), 'value':str(inst - 1)}
            new_node_list.append(new_node)
            if g_enb_info["EnbId"] is None:
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.EnbId".format(inst), 'value':"1993"}
                new_node_list.append(new_node)
            if g_enb_info["EnbName"] is None:
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.EnbName".format(inst), 'value':"Bingo1993"}
                new_node_list.append(new_node)
            tac_config_is_exist = False
            if g_lte_cell_info_list:
                for lte_cell_info in g_lte_cell_info_list:
                    # 小区存在tac配置
                    if lte_cell_info["TAC"]:
                        tac_config_is_exist = True
            if tac_config_is_exist is False:
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.TAC".format(inst), 'value':"12596"}
                new_node_list.append(new_node)
            if int(g_lte_LinkHost_info["IpVersion"]) != IPV4:
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.S1cIpVersion".format(inst), 'value':"1"}
                new_node_list.append(new_node)
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.S1uIpVersion".format(inst), 'value':"1"}
                new_node_list.append(new_node)
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.X2cIpVersion".format(inst), 'value':"1"}
                new_node_list.append(new_node)
                new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.X2uIpVersion".format(inst), 'value':"1"}
                new_node_list.append(new_node)
            ret = NODE_CHANGE
    return ret


# S3  InternetGatewayDevice.Services.FAPService.{i}.FAPControl.LTE.AdminState
# PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.CellActiveState
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.BusinessScene
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.X_WWW-RUIJIE-COM-CN.IMS.emcmode
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.FAPControl.LTE.OpState
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.FAPControl.LTE.RFTxStatus
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.FAPControl.LTE.SourcedSignalEnable
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.FAPControl.LTE.RUHOControlEnable
# S3新增InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.Slot
#   通过小区id查找对应的Device.X_WWW-RUIJIE-COM-CN.DuFrm.{i}.FrmCli.LteDuCellCoverage.{i}.LteDuCellId,DuFrm的实例号为Slot的值,若未找到,则Slot为1
# S3新增InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.CellIdentity,其值固定为小区id
# S3新增InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.DuplexMode,当PJ3的FreqBandIndicator值为3,则为fdd,value设为1,其余为0
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.Common.IntraFreqReselection,allow和prohibit的值相反
# 对于 UserLabel 和 RootSequenceIndex,PJ3为非必选而S3为必选,若PJ3无相关配置,则新增对应配置,RootSequenceIndex默认值为22(海能达默认值),UserLabel默认值为 ltecell
# 当配置文件不存在InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.PhyCellID配置时,添加InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.PhyCellID,其值为实例号i
# 当配置文件不存在InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Common.CellIdentity配置时,添加InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.CellIdentity,其值为实例号i
# 当前的版本只支持 TDD 时, 若小区配置的 FreqBandIndicator 为在 fdd 列表中,
#   FreqBandIndicator 的值修改为 TDD_DEFAULT_FREQ_BAND,
#   EARFCNDL 的值修改为 TDD_DEFAULT_EARFCNDL, 
#   抛弃EARFCNUL节点,
#   DLBandwidth 和 ULBandwidth 的值修改为 TDD_DEFAULT_BAND_WIDTH, 
#   SpecialSubframePatterns 的值修改为 TDD_DEFAULT_SSP, 
#   SubFrameAssignment 的值修改为 TDD_DEFAULT_SA
# 当前的版本只支持 FDD 时, 若小区配置的 FreqBandIndicator 为在 tdd 列表中,
#   FreqBandIndicator 的值修改为 FDD_DEFAULT_FREQ_BAND,
#   EARFCNDL 的值修改为 FDD_DEFAULT_EARFCNDL, 
#   EARFCNUL 的值修改为 FDD_DEFAULT_EARFCNUL,
#   抛弃 SpecialSubframePatterns 和 SubFrameAssignment 的节点
# 当前小区 FreqBandIndicator 为 41 时,
#   EARFCNDL的值只支持 40936,40937,40938,40940, 若不在范围内则修改为 TDD_DEFAULT_EARFCNDL
#   抛弃EARFCNUL节点,
#   DLBandwidth 的值只支持 100(CELL_BW_N100), 
#   SpecialSubframePatterns 的值只支持 7(SSP7_10_2_2), 
#   SubFrameAssignment 的值只支持 7(SA2_DSUDDDSUDD), 
def PJ3_CellConfig_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.CellActiveState" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])
        node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.FAPControl.LTE.AdminState".format(fap_inst)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.BusinessScene" in node_dict['path']:
        ret = NODE_DISCARD
    elif ".CellConfig.LTE.X_WWW-RUIJIE-COM-CN.IMS.emcmode" in node_dict['path']:
        ret = NODE_DISCARD
    elif ".FAPControl.LTE.OpState" in node_dict['path']:
        ret = NODE_DISCARD
    elif ".FAPControl.LTE.RFTxStatus" in node_dict['path']:
        ret = NODE_DISCARD
    elif ".FAPControl.LTE.SourcedSignalEnable" in node_dict['path']:
        ret = NODE_DISCARD
    elif ".FAPControl.LTE.RUHOControlEnable" in node_dict['path']:
        ret = NODE_DISCARD
    elif ".CellConfig.LTE.RAN.Common.CellIdentity" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])
        new_node_list.append(node_dict)
        cellid = int(node_dict['value']) & 0xff
        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.CellIdentity".format(fap_inst), 'value':str(cellid)}
        new_node_list.append(new_node)
        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.Slot".format(fap_inst), 'value':str(get_du_slot_id_by_cellid(cellid))}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.RF.FreqBandIndicator" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])
        if g_duplex_mode_support == DUPLEX_MODE_TDD:
            duplex_mode = str(DUPLEX_MODE_TDD)
            if int(node_dict['value']) not in g_tdd_support_freq_band_list:
                node_dict['value'] = str(TDD_DEFAULT_FREQ_BAND)
        elif g_duplex_mode_support == DUPLEX_MODE_FDD:
            duplex_mode = str(DUPLEX_MODE_FDD)
            if int(node_dict['value']) not in g_fdd_support_freq_band_list:
                node_dict['value'] = str(FDD_DEFAULT_FREQ_BAND)
        else:
            if int(node_dict['value']) not in g_tdd_support_freq_band_list:
                duplex_mode = str(DUPLEX_MODE_FDD)
            else:
                duplex_mode = str(DUPLEX_MODE_TDD)
        new_node_list.append(node_dict)
        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.DuplexMode".format(fap_inst), 'value':duplex_mode}
        new_node_list.append(new_node)
        if g_lte_cell_info_list:
            for lte_cell_info in g_lte_cell_info_list:
                if lte_cell_info["fap_inst"] == fap_inst:
                    if lte_cell_info["RootSequenceIndex"] is None:
                        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.PHY.PRACH.RootSequenceIndex".format(fap_inst), 'value':str((int(fap_inst) - 1) * 120 + 22)}
                        new_node_list.append(new_node)
                    if lte_cell_info["UserLabel"] is None:
                        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.RF.UserLabel".format(fap_inst), 'value':"ltecell"}
                        new_node_list.append(new_node)
                    if lte_cell_info["PhyCellID"] is None:
                        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.RF.PhyCellID".format(fap_inst), 'value':str(fap_inst)}
                        new_node_list.append(new_node)
                    if lte_cell_info["CellIdentity"] is None:
                        cellid = int(fap_inst)
                        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.CellIdentity".format(fap_inst), 'value':str(cellid)}
                        new_node_list.append(new_node)
                        new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.Slot".format(fap_inst), 'value':str(get_du_slot_id_by_cellid(cellid))}
                        new_node_list.append(new_node)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.RF.EARFCNDL" in node_dict['path'] or ".CellConfig.LTE.RAN.RF.EARFCNUL" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])

        cur_cell_freq_band = get_cur_cell_cfg(fap_inst, "FreqBandIndicator")
        if cur_cell_freq_band is None:
            return ret
        
        if g_duplex_mode_support == DUPLEX_MODE_TDD and int(cur_cell_freq_band) not in g_tdd_support_freq_band_list:
            if split_list[8] == "EARFCNDL":
                node_dict['value'] = str(TDD_DEFAULT_EARFCNDL)
            else:
                return NODE_DISCARD
        elif g_duplex_mode_support == DUPLEX_MODE_FDD and int(cur_cell_freq_band) not in g_fdd_support_freq_band_list:
            if split_list[8] == "EARFCNDL":
                node_dict['value'] = str(FDD_DEFAULT_EARFCNDL)
            else:
                node_dict['value'] = str(FDD_DEFAULT_EARFCNUL)
        else:
            if int(cur_cell_freq_band) == 41:
                if split_list[8] == "EARFCNDL":
                    if int(node_dict['value']) not in [40936, 40937, 40938, 40940]:
                        node_dict['value'] = str(TDD_DEFAULT_EARFCNDL)
                else:
                    return NODE_DISCARD
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.RF.DLBandwidth" in node_dict['path'] or ".CellConfig.LTE.RAN.RF.ULBandwidth" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])

        cur_cell_freq_band = get_cur_cell_cfg(fap_inst, "FreqBandIndicator")
        if cur_cell_freq_band is None:
            return ret
        
        if g_duplex_mode_support == DUPLEX_MODE_TDD and int(cur_cell_freq_band) not in g_tdd_support_freq_band_list:
            node_dict['value'] = str(TDD_DEFAULT_BAND_WIDTH)
        else:
            if int(cur_cell_freq_band) == 41:
                node_dict['value'] = str(TDD_DEFAULT_BAND_WIDTH)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.PHY.TDDFrame.SpecialSubframePatterns" in node_dict['path'] or\
            ".CellConfig.LTE.RAN.PHY.TDDFrame.SubFrameAssignment" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])

        cur_cell_freq_band = get_cur_cell_cfg(fap_inst, "FreqBandIndicator")
        if cur_cell_freq_band is None:
            return ret
                
        if g_duplex_mode_support == DUPLEX_MODE_TDD and int(cur_cell_freq_band) not in g_tdd_support_freq_band_list:
            if split_list[9] == "SpecialSubframePatterns":
                node_dict['value'] = str(TDD_DEFAULT_SSP)
            else:
                node_dict['value'] = str(TDD_DEFAULT_SA)
        elif g_duplex_mode_support == DUPLEX_MODE_FDD and int(cur_cell_freq_band) not in g_fdd_support_freq_band_list:
            return NODE_DISCARD
        else:
            if int(cur_cell_freq_band) == 41:
                if split_list[9] == "SpecialSubframePatterns":
                    node_dict['value'] = str(TDD_DEFAULT_SSP)
                else:
                    node_dict['value'] = str(TDD_DEFAULT_SA)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.Mobility.IdleMode.Common.IntraFreqReselection" in node_dict['path']:
        node_dict['value'] = str(1 - int(node_dict['value']))
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.EPC.EAID
# PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.EPC.PLMNList.{i}.PLMNID
# S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.EPC.X_WWW-RUIJIE-COM-CN.OperatorList.{i}.EnbOperatorId
# PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.EPC.PLMNList.{i}.CellReservedForOperatorUse
# S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.EPC.X_WWW-RUIJIE-COM-CN.OperatorList.{i}.CellReservedForOperatorUse
def PJ3_EPC_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.EPC.TAC" in node_dict['path']:
        new_node_list.append(node_dict)
        for enb_op_info in g_enb_op_info_list:
            op_inst = enb_op_info["inst"]
            new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.TAC".format(op_inst), 'value':node_dict['value']}
            new_node_list.append(new_node)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.EPC.EAID" in node_dict['path']:
        ret = NODE_DISCARD
    elif ".CellConfig.LTE.EPC.PLMNList." in node_dict['path']:
        ret = NODE_DISCARD
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])
        plmn_inst = int(split_list[8])
        if split_list[9] == "PLMNID":
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.EPC.X_WWW-RUIJIE-COM-CN.OperatorList.{1}.EnbOperatorId".format(fap_inst, plmn_inst)
            if plmnid_to_op_inst(node_dict['value']) != 0:
                node_dict['value'] = str(plmnid_to_op_inst(node_dict['value']) - 1)
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
        elif split_list[9] == "CellReservedForOperatorUse":
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.EPC.X_WWW-RUIJIE-COM-CN.OperatorList.{1}.CellReservedForOperatorUse".format(fap_inst, plmn_inst)
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret


# S3  InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{i}.EnbId\EnbName
# PJ3 InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Common.EnbId\EnbName
# 转换到每个运营商实例的叶子节点
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Common.EnbType
def PJ3_CommonEnb_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Common.Enb" in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        type = split_list[6]
        for enb_op_info in g_enb_op_info_list:
            op_inst = enb_op_info["inst"]
            new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.{1}".format(op_inst, type), 'value':node_dict['value']}
            new_node_list.append(new_node)
            ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.Common.EnbType" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# 1、按IpVersion提取V4或V6地址
# 2、S1C/S1U地址类型，设置到set ipv4orv6对应IP的LTE属性中
# 3、根据LinkOpId，设置到add lte-port-op对应的配置中
# 4、Switch未使能，则丢弃LinkHostRes节点
# 5、抛弃X2C相关节点
# 6、若无匹配的Device.Ethernet.Interface.{i}.IPv4Address.{i}.IPAddress(ipv4物理口)
#   或Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.IPAddress(ipv4 vlan口)
#   或Device.Ethernet.Interface.{i}.IPv6Address.{i}.IPAddress(ipv6物理口)
#   或Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.IPAddress(ipv6 vlan口)
#   则抛弃linkhost节点
def PJ3_LinkHost_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.LTE.LinkHost" in node_dict['path']:
        ret = NODE_DISCARD
        split_list = node_dict['path'].split(".")
        if int(g_lte_LinkHostRes_info["Switch"]) == 0:
            if split_list[4] == "LinkHostRes":
                return ret
        loc_ip_addr_type = split_list[5]
        if loc_ip_addr_type == "LinkOpId":
            for enb_op_info in g_enb_op_info_list:
                if int(node_dict['value']) + 1 == enb_op_info["inst"]:
                    if int(g_lte_LinkHost_info["IpVersion"]) == IPV4:
                        if g_lte_LinkHostRes_info["S1CLocIpAddr"]:
                            new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.HostIp".format(enb_op_info["inst"]), 'value':g_lte_LinkHostRes_info["S1CLocIpAddr"]}
                            new_node_list.append(new_node)
                            ret = NODE_CHANGE
                    else:
                        if g_lte_LinkHostRes_info["S1UV6LocIpAddr"]:
                            new_node = {'path':"InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.RAN.Operator.{0}.HostIpV6".format(enb_op_info["inst"]), 'value':g_lte_LinkHostRes_info["S1UV6LocIpAddr"]}
                            new_node_list.append(new_node)
                            ret = NODE_CHANGE
        if int(g_lte_LinkHost_info["IpVersion"]) == IPV4:
            if loc_ip_addr_type in ["S1CLocIpAddr", "S1ULocIpAddr"]:
                for ipv4_info in g_ipv4_info_list:
                    if node_dict['value'] == ipv4_info["IPAddress"]:
                        if loc_ip_addr_type == "S1CLocIpAddr":
                            if ipv4_info["PortType"] == "S1U":
                                PortType = "S1"
                            else:
                                PortType = "S1C"
                        else:
                            if ipv4_info["PortType"] == "S1C":
                                PortType = "S1"
                            else:
                                PortType = "S1U"
                        ipv4_info["PortType"] = PortType
                        if ipv4_info["VlanInterface"] == 0:
                            # 经庄巍确认:WANConnectionDevice实例号固定为1
                            new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.WANConnectionDevice.1.WANIPConnection.{1}.PortType".format(ipv4_info["Interface"], ipv4_info["IPv4Address"]), 'value':PortType}
                        else:
                            new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{1}.IPv4Address.{2}.PortType".format(ipv4_info["Interface"], ipv4_info["VlanInterface"], ipv4_info["IPv4Address"]), 'value':PortType}
                        new_node_list.append(new_node)
                        ret = NODE_CHANGE
                '''
                # 新增
                if ret != NODE_CHANGE:
                    if g_wan_ip_info_list:
                        wan_ip_connect_inst_list = [x["WANIPConnection"] for x in g_wan_ip_info_list]
                        wan_dev_inst = g_wan_ip_info_list[0]["WANDevice"]
                        wan_connect_dev_inst = g_wan_ip_info_list[0]["WANConnectionDevice"]
                        wan_ip_connect_inst = 1
                        for wan_ip_connect_inst in range(1, 255, 1):
                            if wan_ip_connect_inst not in wan_ip_connect_inst_list:
                                break
                    else:
                        wan_dev_inst = 1
                        wan_connect_dev_inst = 1
                        wan_ip_connect_inst = 1
                    if loc_ip_addr_type == "S1CLocIpAddr":
                        PortType = "S1C"
                    else:
                        PortType = "S1U"
                    new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.WANConnectionDevice.{1}.WANIPConnection.{2}.PortType".format(wan_dev_inst, wan_connect_dev_inst, wan_ip_connect_inst), 'value':PortType}
                    new_node_list.append(new_node)
                    new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.WANConnectionDevice.{1}.WANIPConnection.{2}.ExternalIPAddress".format(wan_dev_inst, wan_connect_dev_inst, wan_ip_connect_inst), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.WANConnectionDevice.{1}.WANIPConnection.{2}.AddressingType".format(wan_dev_inst, wan_connect_dev_inst, wan_ip_connect_inst), 'value':"Static"}
                    new_node_list.append(new_node)
                    new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.WANConnectionDevice.{1}.WANIPConnection.{2}.SubnetMask".format(wan_dev_inst, wan_connect_dev_inst, wan_ip_connect_inst), 'value':"255.255.255.0"}
                    new_node_list.append(new_node)
                    g_wan_ip_info_list.append({"WANDevice":wan_dev_inst, "WANConnectionDevice":wan_connect_dev_inst, "WANIPConnection":wan_ip_connect_inst, "ExternalIPAddress":node_dict['value'], "PortType":PortType})
                    '''
        else:
            if loc_ip_addr_type in ["S1CV6LocIpAddr", "S1UV6LocIpAddr"]:
                for ipv6_info in g_ipv6_info_list:
                    if node_dict['value'] == ipv6_info["IPAddress"]:
                        if loc_ip_addr_type == "S1CV6LocIpAddr":
                            if ipv6_info["PortType"] == "S1U":
                                PortType = "S1"
                            else:
                                PortType = "S1C"
                        else:
                            if ipv6_info["PortType"] == "S1C":
                                PortType = "S1"
                            else:
                                PortType = "S1U"
                        ipv6_info["PortType"] = PortType
                        if ipv6_info["VlanInterface"] == 0:
                            new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6Address.{1}.PortType".format(ipv6_info["Interface"], ipv6_info["IPv6Address"]), 'value':PortType}
                        else:
                            new_node = {'path':"InternetGatewayDevice.WANDevice.{0}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{1}.IPv6Address.{2}.PortType".format(ipv6_info["Interface"], ipv6_info["VlanInterface"], ipv6_info["IPv6Address"]), 'value':PortType}
                        new_node_list.append(new_node)
                        ret = NODE_CHANGE
                '''
                # 新增
                if ret != NODE_CHANGE:
                    if g_ipv6_info_list:
                        ipv6_addr_inst_list = [x["IPv6Address"] for x in g_ipv6_info_list]
                        interface_inst = g_ipv6_info_list[0]["WANDevice"]
                        ipv6_addr_inst = 1
                        for ipv6_addr_inst in range(1, 255, 1):
                            if ipv6_addr_inst not in ipv6_addr_inst_list:
                                break
                    else:
                        interface_inst = 1
                        ipv6_addr_inst = 1
                    if loc_ip_addr_type == "S1CV6LocIpAddr":
                        PortType = "S1C"
                    else:
                        PortType = "S1U"
                    new_node = {'path':"Device.Ethernet.Interface.{0}.IPv6Address.{1}.PortType".format(interface_inst, ipv6_addr_inst), 'value':PortType}
                    new_node_list.append(new_node)
                    new_node = {'path':"Device.Ethernet.Interface.{0}.IPv6Address.{1}.IPAddress".format(interface_inst, ipv6_addr_inst), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    new_node = {'path':"Device.Ethernet.Interface.{0}.IPv6Address.{1}.Origin".format(interface_inst, ipv6_addr_inst), 'value':"Static"}
                    new_node_list.append(new_node)
                    new_node = {'path':"Device.Ethernet.Interface.{0}.IPv6Address.{1}.PrefixLength".format(interface_inst, ipv6_addr_inst), 'value':"112"}
                    new_node_list.append(new_node)
                    g_ipv6_info_list.append({"Interface":interface_inst, "IPv6Address":ipv6_addr_inst, "IPAddress":node_dict['value'], "PortType":PortType})
                    '''
    return ret


# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.LTECell.{i}.X_WWW-RUIJIE-COM-CN.PrimaryPlmn
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.LTECell.{i}.X_WWW-RUIJIE-COM-CN.PrimaryNbrCellID
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.LTECell.{i}.X_WWW-RUIJIE-COM-CN.PrimaryEnbID
# 1、PrimaryPlmn 改为 PrimaryNbrPLMNID
# 2、PrimaryNbrCellID 和 PrimaryEnbID 合并成 PrimaryNbrECI
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.LTECell.{i}.RSTxPower
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.LTECell.{i}.EnbType
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.X_WWW-RUIJIE-COM-CN.NRCell.{i}.Blacklisted, PJ3:0(prohibit)\1(allow),S3:0(allow)\1(prohibit)
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.X_WWW-RUIJIE-COM-CN.NRCell.{i}.NoRemoveEnable, PJ3:prohibit~1,allow~2,S3：prohibit~1,allow~0"
def PJ3_4G_NeighborList_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.NeighborList.LTECell." in node_dict['path']:
        if "X_WWW-RUIJIE-COM-CN" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = split_list[3]
            nbr_inst = split_list[9]
            if split_list[11] == "PrimaryPlmn":
                node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.NeighborList.LTECell.{1}.X_WWW-RUIJIE-COM-CN.PrimaryNbrPLMNID".format(fap_inst, nbr_inst)
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
            elif split_list[11] in ["PrimaryNbrCellID", "PrimaryEnbID"]:
                ret = NODE_NOT_CHANGE
                for nbr_info in g_4g_nbr_primary_info:
                    if nbr_info["fap_inst"] == fap_inst:
                        if nbr_info["nbr_inst"] == nbr_inst:
                            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.NeighborList.LTECell.{1}.X_WWW-RUIJIE-COM-CN.PrimaryNbrECI".format(fap_inst, nbr_inst)
                            node_dict['value'] = str(nbr_info["PrimaryNbrCellID"] | (nbr_info["PrimaryEnbID"] << 8))
                            new_node_list.append(node_dict)
                            ret = NODE_CHANGE
            if split_list[11] == "Blacklisted":
                node_dict['value'] = str(1 - int(node_dict['value']))
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
            if split_list[11] == "NoRemoveEnable":
                if node_dict['value'] == "2":
                    node_dict['value'] = "0"
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
        elif "RSTxPower" in node_dict['path'] or\
        "EnbType" in node_dict['path']:
            ret = NODE_DISCARD
    return ret

# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.MMEGroupID
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.MMECode
#PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.X_WWW-RUIJIE-COM-CN.OperatorIDList
#S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.X_WWW-RUIJIE-COM-CN.OperatorID
# pj3支持配置列表，S3只能配置一个, 取第一个plmn所属的运营商标识
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.PLMNID,根据OperatorID找到PLMNID
# 新增InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.X_WWW-RUIJIE-COM-CN.MMEId 值为实例-0
# 当InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.MMEIp1为"0.0.0.0", "255.255.255.255"，则抛弃该节点
# 当InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.MmePoolConfigParam.{i}.MMEIp2为"0.0.0.0", "255.255.255.255"，则抛弃该节点
def PJ3_MmePoolConfigParam_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.MmePoolConfigParam." in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = split_list[3]
        mme_inst = split_list[7]
        if "MMEGroupID" in node_dict['path'] or\
        "MMECode" in node_dict['path']:
            ret = NODE_DISCARD
        elif "OperatorIDList" in node_dict['path']:
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.MmePoolConfigParam.{1}.X_WWW-RUIJIE-COM-CN.OperatorID".format(fap_inst, mme_inst)
            node_dict['value'] = str(node_dict['value'].split(",")[0])
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "PLMNID" in node_dict['path']:
            '''
            for mme_op_info in g_mme_op_info_list:
                if mme_op_info["inst"] == mme_inst:
                    node_dict['value'] = op_inst_to_plmnid(int(mme_op_info["op_id_list"][0]) + 1)
                    new_node_list.append(node_dict)
                    ret = NODE_CHANGE
            '''
            ret = NODE_DISCARD
        elif "MMEIp1" in node_dict['path']:
            if node_dict['value'] not in ["0.0.0.0", "255.255.255.255"]:
                new_node_list.append(node_dict)
                new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.MmePoolConfigParam.{1}.X_WWW-RUIJIE-COM-CN.MMEId".format(fap_inst, mme_inst), 'value':str(int(mme_inst) - 1)}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
            else:
                ret = NODE_DISCARD
        elif "MMEIp2" in node_dict['path']:
            if node_dict['value'] not in ["0.0.0.0", "255.255.255.255"]:
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
            else:
                ret = NODE_DISCARD
    return ret


#PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.ULSchedule.MaxUEs
#S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.ULSCH.MaxUePerUlSf
# 用标准节点
def PJ3_ULSchedule_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.ULSchedule.MaxUEs" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        inst = int(split_list[3])
        node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.MAC.ULSCH.MaxUePerUlSf".format(inst)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    return ret


#PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup.{i}.BandIndicator\ExtraBCCHARFCN\ConnFreqPriority
#S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup.{i}.X_WWW-RUIJIE-COM-CN.BandIndicator\ExtraBCCHARFCN\ConnFreqPriority
#S3 多了InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup.{i}.X_WWW-RUIJIE-COM-CN.BcchGroupId节点,其值是GERANFreqGroup实例号-1
def PJ3_GERANFreqGroup_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup." in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])
        geran_inst = int(split_list[12])
        if "BandIndicator" in node_dict['path']:
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup.{1}.X_WWW-RUIJIE-COM-CN.BandIndicator".format(fap_inst, geran_inst)
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "ExtraBCCHARFCN" in node_dict['path']:
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup.{1}.X_WWW-RUIJIE-COM-CN.ExtraBCCHARFCN".format(fap_inst, geran_inst)
            new_node_list.append(node_dict)
            new_node = {'path':"InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup.{1}.X_WWW-RUIJIE-COM-CN.BcchGroupId".format(fap_inst, geran_inst), 'value':str(geran_inst - 1)}
            new_node_list.append(new_node)
            ret = NODE_CHANGE
        elif "ConnFreqPriority" in node_dict['path']:
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.GERAN.GERANFreqGroup.{1}.X_WWW-RUIJIE-COM-CN.ConnFreqPriority".format(fap_inst, geran_inst)
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret


# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.X_WWW-RUIJIE-COM-CN.NR.NRFreqGroup.{i}.SSBMTCPeriod\SSBMTCDuration\SSBIndexLengthChoice\CellReselectionSubPriority
# SSBMTCPeriod PJ3(1~6,255) S3(0~5), 当PJ3的取值为255,抛弃该节点
# SSBIndexLengthChoice PJ3(1~3,255) S3(0~2), 当PJ3的取值为255,抛弃该节点
# SSBMTCDuration PJ3(0~4,255) S3(0~4), 当PJ3的取值为255,抛弃该节点
# CellReselectionSubPriority PJ3(1~4,255) S3(0~3)
def PJ3_NRFreqGroup_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.X_WWW-RUIJIE-COM-CN.NR.NRFreqGroup." in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])
        nr_freq_inst = int(split_list[13])
        if split_list[14] in ["SSBMTCPeriod", "SSBIndexLengthChoice", "CellReselectionSubPriority"]:
            ret = NODE_DISCARD
            if int(node_dict['value']) != 255:
                node_dict['value'] = str(int(node_dict['value']) - 1)
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
        elif split_list[14] in ["SSBMTCDuration"]:
            ret = NODE_DISCARD
            if int(node_dict['value']) != 255:
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.AccessMgmt.LTE.X_WWW-RUIJIE-COM-CN.UESpecification
def PJ3_AccessMgmt_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".AccessMgmt.LTE.X_WWW-RUIJIE-COM-CN.UESpecification" in node_dict['path'] or\
    ".AccessMgmt.LTE.SupportActiveRRCNumbers" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.RCTConfig.
def PJ3_RCTConfig_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.RCTConfig." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.SRS.X_WWW-RUIJIE-COM-CN.
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUCCH.X_WWW-RUIJIE-COM-CN.
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PaParam.X_WWW-RUIJIE-COM-CN.
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUSCH.X_WWW-RUIJIE-COM-CN.
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PDSCH.X_WWW-RUIJIE-COM-CN.
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.MBSFN.NeighCellConfig
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.MBSFN.SFConfigList.{i}.
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PRACH.HighSpeedFlag
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.SRS.SRSEnabled
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.SRS.SRSBandwidthConfig
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.SRS.SRSMaxUpPTS
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.SRS.AckNackSRSSimultaneousTransmission
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUCCH.NRBCQI
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUCCH.NCSAN
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUCCH.N1PUCCHAN
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUCCH.CQIPUCCHResourceIndex
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUCCH.K
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUSCH.HoppingMode
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUSCH.HoppingOffset
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PUSCH.NSB
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PRS.NumPRSResourceBlocks
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PRS.PRSConfigurationIndex
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PRS.NumConsecutivePRSSubfames
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.ULPowerControl.P0NominalPUSCHPersistent
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.ULPowerControl.DeltaMCSEnabled
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.PRACH.ConfigurationIndex
#   PJ3 0~31, S3 TDD:0~4 FDD:0~15, 若小区为FDD 则超过（大于）15丢弃, 若小区为TDD 则超过（大于）4丢弃
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.TDDFrame.SpecialSubframePatterns
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.PHY.TDDFrame.SubFrameAssignment
def PJ3_PHY_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.PHY.SRS.X_WWW-RUIJIE-COM-CN." in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUCCH.X_WWW-RUIJIE-COM-CN." in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PaParam.X_WWW-RUIJIE-COM-CN." in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUSCH.X_WWW-RUIJIE-COM-CN." in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.MBSFN.NeighCellConfig" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.MBSFN.SFConfigList." in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PRACH.HighSpeedFlag" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.SRS.SRSEnabled" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.SRS.SRSBandwidthConfig" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.SRS.SRSMaxUpPTS" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.SRS.AckNackSRSSimultaneousTransmission" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUCCH.NRBCQI" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUCCH.NCSAN" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUCCH.N1PUCCHAN" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUCCH.CQIPUCCHResourceIndex" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUCCH.K" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUSCH.HoppingMode" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUSCH.HoppingOffset" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PUSCH.NSB" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PRS.NumPRSResourceBlocks" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PRS.PRSConfigurationIndex" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PRS.NumConsecutivePRSSubfames" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.ULPowerControl.P0NominalPUSCHPersistent" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.ULPowerControl.DeltaMCSEnabled" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.TDDFrame.SpecialSubframePatterns" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.TDDFrame.SubFrameAssignment" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.PHY.PDSCH.X_WWW-RUIJIE-COM-CN." in node_dict['path']:
        ret = NODE_DISCARD
    elif ".CellConfig.LTE.RAN.PHY.PRACH.ConfigurationIndex" in node_dict['path']:
        if g_duplex_mode_support == DUPLEX_MODE_FDD:
            max_value = 15
        elif g_duplex_mode_support == DUPLEX_MODE_TDD:
            max_value = 4
        else:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            cur_cell_freq_band = get_cur_cell_cfg(fap_inst, "FreqBandIndicator")
            if cur_cell_freq_band is None:
                return ret
            
            if int(cur_cell_freq_band) in g_fdd_support_freq_band_list:
                max_value = 15
            else:
                max_value = 4
        if int(node_dict['value']) > max_value:
            ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.DrxInitialParam.{i}.X_WWW-RUIJIE-COM-CN.ShortDRXEnable
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.ULSchedule.FssEnable
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.DLSchedule.FssEnable
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.ULSchedule.FssNiFilterPeriod
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.ULSchedule.FssNiFilterTime
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.ULSchedule.FssRbNiThreshold
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.DLSchedule.FssCqiThreshold
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.RACH.X_WWW-RUIJIE-COM-CN.AutoFreqOffsetSwitch
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.DRX.DRXEnabled
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.DrxInitialParam.{i}.
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.ULSCH.RetxBSRTimer
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.ULSCH.TTIBundling
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.ULSCH.MaxUePerUlSf
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.DLSchedule.Algorithm
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.ULSchedule.Algorithm
def PJ3_MAC_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.MAC.DrxInitialParam." in node_dict['path']:
        if ".X_WWW-RUIJIE-COM-CN.ShortDRXEnable" in node_dict['path']:
            ret = NODE_DISCARD
    elif "CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN." in node_dict['path']:
        if ".Fss" in node_dict['path']:
            ret = NODE_DISCARD
        elif ".ULSchedule.Algorithm" in node_dict['path'] or\
        ".DLSchedule.Algorithm" in node_dict['path']:
            ret = NODE_DISCARD
    elif "CellConfig.LTE.RAN.MAC.RACH.X_WWW-RUIJIE-COM-CN.AutoFreqOffsetSwitch" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.MAC.DrxInitialParam." in node_dict['path'] or\
    ".CellConfig.LTE.RAN.MAC.ULSCH.MaxUePerUlSf" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.MAC.ULSCH.RetxBSRTimer" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.MAC.ULSCH.TTIBundling" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.MAC.DRX.DRXEnabled" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.InterRATCell.GSM.{i}.X_WWW-RUIJIE-COM-CN.CSPSHOIndicator
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.InterRATCell.GSM.{i}.X_WWW-RUIJIE-COM-CN.ControlMode
def PJ3_GSM_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.NeighborList.InterRATCell.GSM." in node_dict['path']:
        if ".X_WWW-RUIJIE-COM-CN.CSPSHOIndicator" in node_dict['path'] or\
        "X_WWW-RUIJIE-COM-CN.ControlMode" in node_dict['path']:
            ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.InterFreq.Carrier.{i}.X_WWW-RUIJIE-COM-CN.AsAnrMeasObject
def PJ3_InterFreq_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.IdleMode.InterFreq.Carrier." in node_dict['path']:
        if ".X_WWW-RUIJIE-COM-CN.AsAnrMeasObject" in node_dict['path']:
            ret = NODE_DISCARD
    return ret


# S3对于SONConfigParam只保留PCIOptEnable和CandidatePCIList节点，其它抛弃
def PJ3_SONConfigParam_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".FAPControl.LTE.SelfConfig.SONConfigParam." in node_dict['path']:
        ret = NODE_DISCARD
        if "PCIOptEnable" in node_dict['path'] or\
        "CandidatePCIList" in node_dict['path']:
            new_node_list.append(node_dict)
            ret = NODE_CHANGE

    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RRCTimers.X_WWW-RUIJIE-COM-CN.RRCConnectRejectWaitTime
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RRCTimers.X_WWW-RUIJIE-COM-CN.RRCReleaseRejectWaitTime
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RRCTimers.X_WWW-RUIJIE-COM-CN.HoEndMarkerTimer
def PJ3_RRCTimers_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.RRCTimers.X_WWW-RUIJIE-COM-CN.RRCConnectRejectWaitTime" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.RRCTimers.X_WWW-RUIJIE-COM-CN.RRCReleaseRejectWaitTime" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.RRCTimers.X_WWW-RUIJIE-COM-CN.HoEndMarkerTimer" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.X_WWW-RUIJIE-COM-CN.CongestionMgmt.LTE.
def PJ3_CongestionMgmt_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".X_WWW-RUIJIE-COM-CN.CongestionMgmt.LTE." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.X_WWW-RUIJIE-COM-CN.NRCell.{i}.CIO
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.X_WWW-RUIJIE-COM-CN.NRCell.{i}.Blacklisted
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.X_WWW-RUIJIE-COM-CN.NRCell.{i}.NoRemoveEnable
# PJ3:0(prohibit)\1(allow)
# S3:0(allow)\1(prohibit)"
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.X_WWW-RUIJIE-COM-CN.NRCell.{i}.SSBSubcarrierSpacing
# PJ3:kHz15~15,kHz30~30,kHz120~120,kHz240~240
# S3:kHz15~0,kHz30~1,kHz120~2,kHz240~3
def PJ3_NRCell_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.NeighborList.X_WWW-RUIJIE-COM-CN.NRCell." in node_dict['path']:
        if "CIO" in node_dict['path']:
            ret = NODE_DISCARD
        if "SSBSubcarrierSpacing" in node_dict['path']:
            SSBSubcarrierSpacing = [15, 30, 120, 240]
            if int(node_dict['value']) in SSBSubcarrierSpacing:
                node_dict['value'] = str(SSBSubcarrierSpacing.index(int(node_dict['value'])))
                new_node_list.append(node_dict)
                ret = NODE_CHANGE
        if "Blacklisted" in node_dict['path'] or\
        "NoRemoveEnable" in node_dict['path']:
            node_dict['value'] = str(1 - int(node_dict['value']))
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.X_WWW-RUIJIE-COM-CN.CpriTopo.
def PJ3_CpriTopo_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.X_WWW-RUIJIE-COM-CN.CpriTopo." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.RlcPdcpParam.{i}.RohcProfiles
# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.RlcPdcpParam.{i}.QCI, QCI实例65,66,67,69,70不支持，丢弃处理
def PJ3_RlcPdcpParam_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.RlcPdcpParam." in node_dict['path']:
        if "RohcProfiles" in node_dict['path']:
            ret = NODE_DISCARD
        elif "QCI" in node_dict['path']:
            if int(node_dict['value']) >= 65:
                ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.CellStandardQCI.{i}.LogicalChannelGroup
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.CellStandardQCI.{i}.SrProhibitTimerR9
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.CellStandardQCI.{i}.DSCP
def PJ3_CellStandardQCI_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.CellStandardQCI." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.AvoidMgmt.LTE.CwmpCtrlSwitch
def PJ3_AvoidMgmt_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.AvoidMgmt.LTE.CwmpCtrlSwitch" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.SrsPeriodicity
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.UeRatioType
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.UeRatio1
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.UeRatio2
def PJ3_AdmissionControl_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.SrsPeriodicity" in node_dict['path'] or\
    ".X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.UeRatio1" in node_dict['path'] or\
    ".X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.UeRatio2" in node_dict['path'] or\
    ".X_WWW-RUIJIE-COM-CN.AdmissionControl.LTE.UeRatioType" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.NonGbrCfg.{i}.
def PJ3_NonGbrCfg_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.NonGbrCfg." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.CQIReport.PacketScheMode
def PJ3_CQIReport_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.CQIReport.PacketScheMode" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.CQIReport.PacketScheMode
def PJ3_EnbLicense_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.ManagementServer.X_WWW-RUIJIE-COM-CN.EnbLicense." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.Capabilities.LTE.NNSFSupported
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.Capabilities.MaxTxPower
def PJ3_Capabilities_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".Capabilities.LTE.NNSFSupported" in node_dict['path'] or\
    ".Capabilities.MaxTxPower" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.FAPControl.X2IpAddrMapInfo.{i}.
def PJ3_X2IpAddrMapInfo_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".FAPControl.X2IpAddrMapInfo." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.SysInfoCtrlParam.
def PJ3_SysInfoCtrlParam_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.SysInfoCtrlParam.MultiBandInfoListSIB" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.ULBandwidth
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.PSCHPowerOffset
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.SSCHPowerOffset
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.RF.PBCHPowerOffset
def PJ3_RF_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.RF." in node_dict['path']:
        if "ULBandwidth" in node_dict['path'] or\
        "PSCHPowerOffset" in node_dict['path'] or\
        "SSCHPowerOffset" in node_dict['path'] or\
        "PBCHPowerOffset" in node_dict['path']:
            ret = NODE_DISCARD
    return ret

# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.VoLTE.PdcpInitParam.{i}.RohcEn
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.VoLTEParam.SPSSwitchQCI1Ul
def PJ3_VoLTE_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.VoLTE" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.CAParam.CASwitchUl
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.CAParam.CASwitchDl
def PJ3_CAParam_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.CAParam.CASwitch" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.Transport.SCTP.Assoc.
def PJ3_SCTP_Assoc_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".Transport.SCTP.Assoc." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.NeighborList.InterRATCell.UMTS.{i}.
def PJ3_UMTS_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.NeighborList.InterRATCell.UMTS." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.MeasQuantityUTRAFDD
# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.QoffsetUTRA
def PJ3_IRAT_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.MeasQuantityUTRAFDD" in node_dict['path'] or\
    ".CellConfig.LTE.RAN.Mobility.ConnMode.IRAT.QoffsetUTRA" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.IntraFreq.AllowedMeasBandwidth
# pj3:0/6/15/25/50/75/100
# s3:6/15/25/50/75/100
# pj3为0时，丢弃该节点
def PJ3_IntraFreq_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.IdleMode.IntraFreq.AllowedMeasBandwidth" in node_dict['path']:
        if int(node_dict['value']) == 0:
            ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.ConnMode.EUTRA.PeriodMeasCtrl.{i}.
def PJ3_PeriodMeasCtrl_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.Mobility.ConnMode.EUTRA.PeriodMeasCtrl." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.LTE.AutoLink.IpVersion
# S3抛弃InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.LTE.AutoLink.Enable
def PJ3_AutoLink_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.LTE.AutoLink." in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# S3抛弃InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.DSCPConfig.SignalDSCPPriority
def PJ3_StationMgmt_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.StationMgmt.LTE.DSCPConfig.SignalDSCPPriority" in node_dict['path']:
        ret = NODE_DISCARD
    return ret


# InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.CellRestriction.X_WWW-RUIJIE-COM-CN.BarringForEmergency,S3:1(not-barred)\0(barred),PJ3:1(barred)\0(not-barred)
def PJ3_CellRestriction_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.CellRestriction.X_WWW-RUIJIE-COM-CN.BarringForEmergency" in node_dict['path']:
        node_dict['value'] = str(1 - int(node_dict['value']))
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    return ret


# PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.MIMO.DLMIMOType
# S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.MIMO.TMMode
# PJ3:TM2~20,TM3_SFBC~30,TM3_CDD~31,TM3_ADAPTIVE~35,TM4_SFBC~40,TM4_CDD~42,TM4_ADAPTIVE~45,TM_INTER_ADAPTIVE_TM2TM3~101
# S3: TM2,TM3_SFBC,TM3_CDD,TM3_ADAPTIVE,TM4_SFBC,TM4_CDD,TM4_ADAPTIVE
def PJ3_MIMO_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.X_WWW-RUIJIE-COM-CN.MIMO.DLMIMOType" in node_dict['path']:
        ret = NODE_DISCARD
        DLMIMOType = {20:"TM2", 30:"TM3_SFBC", 31:"TM3_CDD", 35:"TM3_ADAPTIVE", 40:"TM4_SFBC", 42:"TM4_CDD", 45:"TM4_ADAPTIVE"}
        index = int(node_dict['value'])
        if index <= 45:
            split_list = node_dict['path'].split(".")
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.MAC.X_WWW-RUIJIE-COM-CN.MIMO.TMMode".format(split_list[3])
            node_dict['value'] = DLMIMOType[index]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret


# PJ3 InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.UTRA.UTRANFDDFreq.{i}.X_WWW-RUIJIE-COM-CN.QQualMin
# S3  InternetGatewayDevice.Services.FAPService.{i}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.UTRA.UTRANFDDFreq.{i}.X_WWW-RUIJIE-COM-CN.OperatorList.QQualMin
def PJ3_UTRA_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    '''
    if ".CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.UTRA.UTRANFDDFreq." in node_dict['path']:
        if "QQualMin" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            freq_inst = int(split_list[12])
            node_dict['path'] = "InternetGatewayDevice.Services.FAPService.{0}.CellConfig.LTE.RAN.Mobility.IdleMode.IRAT.UTRA.UTRANFDDFreq.{1}.X_WWW-RUIJIE-COM-CN.OperatorList.QQualMin".format(fap_inst, freq_inst)
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    '''
    return ret


#Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A1MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A1MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A1MeasureCtrl.{i}.MeasurePurpose
def PJ3_NR_change_A1_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".NR.RAN.Mobility.ConnMode.NR.A1MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        if "Device.Services.FAPService." in node_dict['path']:
            #add 10 to {i} 
            split_list[12] = str(10 + int(split_list[12]))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            split_list[13] = str(10 + int(split_list[13]))
            #add 10 to MeasurePurpose 
            if "MeasurePurpose" in node_dict['path']:
                if int(node_dict['value']) <= 10 :
                    node_dict['value'] = str(10 + int(node_dict['value']))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

#Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A2MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A2MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A2MeasureCtrl.{i}.MeasurePurpose
def PJ3_NR_change_A2_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".NR.RAN.Mobility.ConnMode.NR.A2MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        if "Device.Services.FAPService." in node_dict['path']:
            split_list[12] = str(10 + int(split_list[12]))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            split_list[13] = str(10 + int(split_list[13]))
            if "MeasurePurpose" in node_dict['path']:
                if int(node_dict['value']) <= 10 :
                    node_dict['value'] = str(10 + int(node_dict['value']))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

#Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A3MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A3MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A3MeasureCtrl.{i}.MeasurePurpose
def PJ3_NR_change_A3_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".NR.RAN.Mobility.ConnMode.NR.A3MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        if "Device.Services.FAPService." in node_dict['path']:
            split_list[12] = str(10 + int(split_list[12]))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            split_list[13] = str(10 + int(split_list[13]))
            if "MeasurePurpose" in node_dict['path']:
                if int(node_dict['value']) <= 10 :
                    node_dict['value'] = str(10 + int(node_dict['value']))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

#Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A4MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A4MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A4MeasureCtrl.{i}.MeasurePurpose
def PJ3_NR_change_A4_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".NR.RAN.Mobility.ConnMode.NR.A4MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        if "Device.Services.FAPService." in node_dict['path']:
            split_list[12] = str(10 + int(split_list[12]))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            split_list[13] = str(10 + int(split_list[13]))
            if "MeasurePurpose" in node_dict['path']:
                if int(node_dict['value']) <= 10 :
                    node_dict['value'] = str(10 + int(node_dict['value']))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

#Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A5MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A5MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.NR.A5MeasureCtrl.{i}.MeasurePurpose
def PJ3_NR_change_A5_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".NR.RAN.Mobility.ConnMode.NR.A5MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        if "Device.Services.FAPService." in node_dict['path']:
            split_list[12] = str(10 + int(split_list[12]))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            split_list[13] = str(10 + int(split_list[13]))
            if "MeasurePurpose" in node_dict['path']:
                if int(node_dict['value']) <= 10 :
                    node_dict['value'] = str(10 + int(node_dict['value']))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

#Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.{i}.
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl.{i}.MeasurePurpose    
def PJ3_NR_change_B1_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".NR.RAN.Mobility.ConnMode.IRAT.B1MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        if "Device.Services.FAPService." in node_dict['path']:
            split_list[12] = str(10 + int(split_list[12]))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            split_list[13] = str(10 + int(split_list[13]))
            if "MeasurePurpose" in node_dict['path']:
                if int(node_dict['value']) <= 10 :
                    node_dict['value'] = str(10 + int(node_dict['value']))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret

#Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl.{i}.MeasurePurpose
def PJ3_NR_change_B2_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".NR.RAN.Mobility.ConnMode.IRAT.B2MeasureCtrl." in node_dict['path']:
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        if "Device.Services.FAPService." in node_dict['path']:
            split_list[12] = str(10 + int(split_list[12]))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            split_list[13] = str(10 + int(split_list[13]))
            if "MeasurePurpose" in node_dict['path']:
                if int(node_dict['value']) <= 10 :
                    node_dict['value'] = str(10 + int(node_dict['value']))
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
    return ret
   

if __name__ == "__main__":
    
    if len(sys.argv) != 3:
        print("arg num invalid")
        for arg in sys.argv:
            print(arg)
        exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    if not os.access(input_file, os.F_OK):
        print(input_file, "not exist!")
        exit(1)

    # 假设新旧节点的层级相同，仅节点名不同
    xml_tree = ET.ElementTree(file = input_file)
    root_ele = xml_tree.getroot()

    node = str()
    node_list = list()
    foreach_xml(root_ele, node, node_list)
    new_root = ET.Element(ROOT_TAG_NAME)
    get_base_info_from_node_list(node_list)
    if g_config_need_change is False:
        g_config_need_change = check_trigger_configuration_conversion_patch_function(node_list)
        if g_config_need_change is True: 
            write_log_file('trigger patch function')
            print('trigger patch function')
    if g_config_need_change is True:
        get_duplex_mode_support()
        get_all_du_slot_state()
        for du_frm_info in g_du_frm_info_list:
            write_log_file("slot {0} state: {1}".format(du_frm_info["DuFrm"] ,is_du_exist(du_frm_info["DuFrm"])))
        write_log_file("g_du_frm_info_list : " + str(g_du_frm_info_list))
        write_log_file("g_enb_op_info_list : " + str(g_enb_op_info_list))
        write_log_file("g_ltecell_op_info_list : " + str(g_ltecell_op_info_list))
        write_log_file("g_mme_op_info_list : " + str(g_mme_op_info_list))
        write_log_file("g_lte_LinkHost_info : " + str(g_lte_LinkHost_info))
        write_log_file("g_lte_LinkHostRes_info : " + str(g_lte_LinkHostRes_info))
        write_log_file("g_ipv4_info_list : " + str(g_ipv4_info_list))
        write_log_file("g_ipv6_info_list : " + str(g_ipv6_info_list))
        write_log_file("g_lte_cell_info_list : " + str(g_lte_cell_info_list))
        write_log_file("g_enb_info : " + str(g_enb_info))
        write_log_file("g_duplex_mode_support : " + str(g_duplex_mode_support))
        # write_log_file("g_4g_nbr_primary_info : " + str(g_4g_nbr_primary_info))
        new_node_list = list()
        for node_dict in node_list:
            if PJ3_A1_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_A2_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_B1_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_B2_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_Operator_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CellConfig_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_EPC_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CommonEnb_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_LinkHost_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_4G_NeighborList_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_MmePoolConfigParam_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_ULSchedule_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_GERANFreqGroup_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NRFreqGroup_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_AccessMgmt_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_RCTConfig_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_PHY_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_MAC_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_GSM_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_InterFreq_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_SONConfigParam_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_RRCTimers_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CongestionMgmt_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NRCell_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CpriTopo_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_RlcPdcpParam_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CellStandardQCI_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_AvoidMgmt_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_AdmissionControl_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NonGbrCfg_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CQIReport_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_EnbLicense_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_Capabilities_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_X2IpAddrMapInfo_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_SysInfoCtrlParam_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_RF_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_VoLTE_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_SCTP_Assoc_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CAParam_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_UMTS_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_IRAT_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_IntraFreq_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_PeriodMeasCtrl_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_AutoLink_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_StationMgmt_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_CellRestriction_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_MIMO_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_UTRA_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NR_change_A1_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NR_change_A2_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NR_change_A3_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NR_change_A4_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NR_change_A5_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NR_change_B1_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_NR_change_B2_S3(node_dict, new_node_list) is NODE_NOT_MATCH and\
            PJ3_EnodebCfgSwitch_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH:
                new_node_list.append(node_dict)
        #new_node_list.sort()
        for node_dict in new_node_list:
            new_list = node_dict['path'].strip().strip(".").split(".")
            #print(node_dict['path'], node_dict['value'])
        
            i = 0
            inst_list = []
            build_new_xml(new_root, i, new_list, inst_list, node_dict['value'])
        
        '''
        for old, new in map_list:
            old_list = old.strip().strip(".").split(".")
            new_list = new.strip().strip(".").split(".")
            print(old_list)
            print(new_list)
            old_xp = "/".join([x for x in old_list if x != "{i}"])
            print(old_xp)

            if root_ele.find(old_xp) == None:
                continue

            i = 0
            inst_list = []
            root = ET.Element("root")
            recur_mkele(root_ele, old_list, i, new_list, inst_list)
        for old, new in map_list:
            old_list = old.strip().strip(".").strip(".{i}").split(".")
            target = old_list.pop()
            old_prt_xp = "/".join([x for x in old_list if x != "{i}"])
            for prt_ele in root_ele.findall(old_prt_xp):
                for target_ele in prt_ele.findall(target):
                    prt_ele.remove(target_ele)
        '''
        pretty_xml(new_root)
        ele_tree = ET.ElementTree(new_root)
        ele_tree.write(output_file, encoding="utf-8", xml_declaration=True)
