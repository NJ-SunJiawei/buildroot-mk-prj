#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import sys
import os
import time
import re

ROOT_TAG_NAME = "Config"
# 上一个版本号，通过版本号判断是否转换配置
PREV_VERSION = "v1.6"
LOG_PATH = "/run_isolate/local_log/du"
OPERATOR_MODE_PATH = "/data/.5gnr/app_data/oam_core/.oam_operator_mode_msg"
OPERATOR_MODE_CUCC = "CUCC"
OPERATOR_MODE_LENTH = 4


NODE_NOT_MATCH = 0
NODE_CHANGE = 1
NODE_NOT_CHANGE = 2
NODE_DISCARD = 3

# RACHConfigGeneric 信息列表
g_gnb_RACHConfigGeneric_info_list = list()
# RACHConfigCommon 信息列表
g_gnb_RACHConfigCommon_info_list = list()
# PUCCHConfigCommon 信息列表
g_gnb_PUCCHConfigCommon_info_list = list()
# PDCCHConfigCommon 信息列表
g_gnb_PDCCHConfigCommon_info_list = list()
# PUSCHConfigCommon 信息列表
g_gnb_PUSCHConfigCommon_info_list = list()
# PDCCHCommonSearchSpaceList 信息列表
g_gnb_PDCCHCommonSearchSpaceList_info_list = list()
# PUSCHTimeDomainAllocationList 信息列表
g_gnb_PUSCHTimeDomainAllocationList_info_list = list()
# PDSCHTimeDomainResourceAllocationList 信息列表
g_gnb_PDSCHTimeDomainResourceAllocationList_info_list = list()
# PDCCHCommonControlResourceSet 信息列表
g_gnb_PDCCHCommonControlResourceSet_info_list = list()
# BWPUL信息列表
g_gnb_BWPUL_info_list = list()
# BWPDL 信息列表
g_gnb_BWPDL_info_list = list()

def pretty_xml(element, indent="  ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    node=" "
    if element != None:  # 判断element是否有子元素   
        if len(element.getchildren()) == 0:
            node += str(element.tag)
            pass 
        elif (element.text is None) or element.text.isspace():  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
        # else:
        #     element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * (level + 1)
        else:  # 此处两行如果把注释去掉，Element的text也会另起一行
            element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * level

    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def foreach_xml(element, node, node_list):
    if element != None:
        # 有子元素无属性
        if len(element.getchildren()) and len(element.attrib) == 0:
            if str(element.tag) != ROOT_TAG_NAME:
                node += element.tag + '.'
        # 有属性
        elif len(element.attrib) != 0:
            node += element.tag + '.' + element.attrib['instance_id']
            #无子元素说明结束
            if len(element.getchildren()) == 0:
                node_list.append({'path': node, 'value': None})
                pass
            else:
                node += '.'
        #无子元素
        else:
            node += element.tag
            node_list.append({'path': node, 'value': element.text})
            node = ""
            pass
    # 将element转成list
    temp = list(element)
    for subelement in temp:
        # 对子元素进行递归操作
        foreach_xml(subelement, node, node_list)

def gen_xpath(node_list, inst_list):
    i = 0
    path = ""
    for node in node_list:
        if node.isdigit():
            path += '[@instance_id="%s"]/' % inst_list[i]
            i += 1
        else:
            path += node + "/"
    return path.strip("/")

def build_new_xml(root_ele, i, new_list, inst_list, value):
    if i >= len(new_list):
        return

    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if root_ele.find(new_xp) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
        i += 2
        build_new_xml(root_ele, i, new_list, inst_list, value)
        inst_list.pop()
        i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            if len(new_list[:i]):
                ET.SubElement(cu_ele, new_list[i])
            else:
                ET.SubElement(root_ele, new_list[i])
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = value
        i += 1
        build_new_xml(root_ele, i, new_list, inst_list, value)
        i -= 1

def recur_mkele(root_ele, old_list, i, new_list, inst_list):
    if i >= len(new_list):
        return
    if i + 1 != len(new_list) and new_list[i + 1] == "{i}":
        old_xp = gen_xpath(old_list[:i + 1], inst_list)

        for ele in root_ele.findall(old_xp):
            inst_list.append(ele.attrib["instance_id"])
            new_xp = gen_xpath(new_list[:i + 2], inst_list)
            if root_ele.find(new_xp) == None:
                cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
                ET.SubElement(cu_ele, new_list[i], {"instance_id":ele.attrib["instance_id"]})
            i += 2
            recur_mkele(root_ele, old_list, i, new_list, inst_list)
            inst_list.pop()
            i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i])
        if i + 1 == len(new_list):
            old_xp = gen_xpath(old_list[:i + 1], inst_list)
            leaf_val = root_ele.find(old_xp).text

            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = leaf_val
        i += 1
        recur_mkele(root_ele, old_list, i, new_list, inst_list)
        i -= 1

def write_log_file(str):
    if not os.path.exists(LOG_PATH):
        os.system("mkdir -p {0}".format(LOG_PATH))
    file = open("{0}/PJ3S501_xml_trans_PJ3S502.log".format(LOG_PATH), 'a')
    file.write("{0} : {1}\n".format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), str))
    file.close()
    
def get_base_info_from_node_list(node_list):
    for node_dict in node_list:
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.RACHConfigGeneric.{i}.BWPId
        # 缓存当前存在的 CellConfig,RACHConfigGeneric 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.RACHConfigGeneric.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            RACHConfigGeneric_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_RACHConfigGeneric_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and RACHConfigGeneric_inst == info["RACHConfigGeneric_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_RACHConfigGeneric_info_list.append({"CellConfig_inst":CellConfig_inst, "RACHConfigGeneric_inst":RACHConfigGeneric_inst, "BWPId":node_dict['value']})
            #print(g_gnb_RACHConfigGeneric_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.RACHConfigCommon.{i}.BWPId
        # 缓存当前存在的 RACHConfigCommon 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.RACHConfigCommon.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            RACHConfigCommon_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_RACHConfigCommon_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and RACHConfigCommon_inst == info["RACHConfigCommon_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_RACHConfigCommon_info_list.append({"CellConfig_inst":CellConfig_inst, "RACHConfigCommon_inst":RACHConfigCommon_inst, "BWPId":node_dict['value']})
            #print(g_gnb_RACHConfigCommon_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUCCHConfigCommon.{i}.BWPId
        # 缓存当前存在的 PUCCHConfigCommon 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PUCCHConfigCommon.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            PUCCHConfigCommon_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_PUCCHConfigCommon_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and PUCCHConfigCommon_inst == info["PUCCHConfigCommon_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_PUCCHConfigCommon_info_list.append({"CellConfig_inst":CellConfig_inst, "PUCCHConfigCommon_inst":PUCCHConfigCommon_inst, "BWPId":node_dict['value']})
            #print(g_gnb_PUCCHConfigCommon_info_list)            
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHConfigCommon.{i}.BWPId
        # 缓存当前存在的 PDCCHConfigCommon 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDCCHConfigCommon.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            PDCCHConfigCommon_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_PDCCHConfigCommon_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and PDCCHConfigCommon_inst == info["PDCCHConfigCommon_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_PDCCHConfigCommon_info_list.append({"CellConfig_inst":CellConfig_inst, "PDCCHConfigCommon_inst":PDCCHConfigCommon_inst, "BWPId":node_dict['value']})
            #print(g_gnb_PDCCHConfigCommon_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUSCHConfigCommon.{i}.BWPId
        # 缓存当前存在的 PUSCHConfigCommon 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PUSCHConfigCommon.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            PUSCHConfigCommon_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_PUSCHConfigCommon_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and PUSCHConfigCommon_inst == info["PUSCHConfigCommon_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_PUSCHConfigCommon_info_list.append({"CellConfig_inst":CellConfig_inst, "PUSCHConfigCommon_inst":PUSCHConfigCommon_inst, "BWPId":node_dict['value']})
            #print(g_gnb_PUSCHConfigCommon_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonControlResourceSet.{i}.BWPId
        # 缓存当前存在的 PDCCHCommonControlResourceSet 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDCCHCommonControlResourceSet.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            PDCCHCommonControlResourceSet_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_PDCCHCommonControlResourceSet_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and PDCCHCommonControlResourceSet_inst == info["PDCCHCommonControlResourceSet_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_PDCCHCommonControlResourceSet_info_list.append({"CellConfig_inst":CellConfig_inst, "PDCCHCommonControlResourceSet_inst":PDCCHCommonControlResourceSet_inst, "BWPId":node_dict['value']})
            #print(g_gnb_PDCCHCommonControlResourceSet_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUSCHTimeDomainAllocationList.{i}.BWPId
        # 缓存当前存在的 PUSCHTimeDomainAllocationList 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PUSCHTimeDomainAllocationList.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            PUSCHTimeDomainAllocationList_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_PUSCHTimeDomainAllocationList_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and PUSCHTimeDomainAllocationList_inst == info["PUSCHTimeDomainAllocationList_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_PUSCHTimeDomainAllocationList_info_list.append({"CellConfig_inst":CellConfig_inst, "PUSCHTimeDomainAllocationList_inst":PUSCHTimeDomainAllocationList_inst, "BWPId":node_dict['value']})
            #print(g_gnb_PUSCHTimeDomainAllocationList_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDSCHTimeDomainResourceAllocationList.{i}.BWPId
        # 缓存当前存在的 PDSCHTimeDomainResourceAllocationList 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDSCHTimeDomainResourceAllocationList.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            PDSCHTimeDomainResourceAllocationList_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_PDSCHTimeDomainResourceAllocationList_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and PDSCHTimeDomainResourceAllocationList_inst == info["PDSCHTimeDomainResourceAllocationList_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_PDSCHTimeDomainResourceAllocationList_info_list.append({"CellConfig_inst":CellConfig_inst, "PDSCHTimeDomainResourceAllocationList_inst":PDSCHTimeDomainResourceAllocationList_inst, "BWPId":node_dict['value']})
            #print(g_gnb_PDSCHTimeDomainResourceAllocationList_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonSearchSpaceList.{i}.BWPId
        # 保存当前存在的 PDCCHCommonSearchSpaceList 实例号与BWPId的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDCCHCommonSearchSpaceList.[0-9]+.BWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            PDCCHCommonSearchSpaceList_inst = int(split_list[10])
            in_list = False
            for info in g_gnb_PDCCHCommonSearchSpaceList_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and PDCCHCommonSearchSpaceList_inst == info["PDCCHCommonSearchSpaceList_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_PDCCHCommonSearchSpaceList_info_list.append({"CellConfig_inst":CellConfig_inst, "PDCCHCommonSearchSpaceList_inst":PDCCHCommonSearchSpaceList_inst, "BWPId":node_dict['value']})
            #print(g_gnb_PDCCHCommonSearchSpaceList_info_list)    
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPUL.{i}.UlBWPId
        # 保存当前存在的 BWPUL 实例号与 UlBWPId 的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.BWP.BWPUL.[0-9]+.UlBWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            BWPUL_inst = int(split_list[11])
            in_list = False
            for info in g_gnb_BWPUL_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and BWPUL_inst == info["BWPUL_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_BWPUL_info_list.append({"CellConfig_inst":CellConfig_inst, "BWPUL_inst":BWPUL_inst, "UlBWPId":node_dict['value']})
            #print(g_gnb_BWPUL_info_list)
        # V1.1.8:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.DlBWPId
        # 保存当前存在的 CellConfig、BWPDL 实例号与 DlBWPId 的映射关系
        if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.BWP.BWPDL.[0-9]+.DlBWPId", node_dict['path']):
            split_list = node_dict['path'].split(".")
            CellConfig_inst = int(split_list[5])
            BWPDL_inst = int(split_list[11])
            in_list = False
            for info in g_gnb_BWPDL_info_list:
                if CellConfig_inst == info["CellConfig_inst"] and BWPDL_inst == info["BWPDL_inst"]:
                    in_list = True
                    break
            if not(in_list):
                g_gnb_BWPDL_info_list.append({"CellConfig_inst":CellConfig_inst, "BWPDL_inst":BWPDL_inst, "DlBWPId":node_dict['value']})
            #print(g_gnb_BWPDL_info_list)

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.NGC.CellReservedForOtherUse
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.CN.CellReservedForOtherUse	
def S5_change_CellReservedForOtherUse(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.NGC.CellReservedForOtherUse", node_dict['path']):
        ret = NODE_NOT_CHANGE
        new_node = {'path':node_dict['path'].replace("NGC", "CN", 1), 'value':node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.VoNRParam.SPSSwitchQCI1Ul
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.VoNR.SPSSwitchQCI1Ul
def S5_change_SPSSwitchQCI1Ul(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.VoNRParam.SPSSwitchQCI1Ul", node_dict['path']):
        ret = NODE_NOT_CHANGE
        new_node = {'path':node_dict['path'].replace("VoNRParam", "VoNR", 1), 'value':node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.NGC.TA.{i}.TAC
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.CN.TA.{i}.TAC
def S5_change_TA(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.NGC.TA.[0-9]+.", node_dict['path']):
        ret = NODE_NOT_CHANGE
        new_node = {'path':node_dict['path'].replace(".NGC.", ".CN.", 1), 'value':node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.FrequencyInfoDLSIB.ScsSpecificCarrierList.{i}.SCSSpecificCarrier.subcarrierSpacing
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.FrequencyInfoDLSIB.ScsSpecificCarrierList.{i}.SCSSpecificCarrier.SubcarrierSpacing
def S5_change_subcarrierSpacing(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.FrequencyInfoDLSIB.ScsSpecificCarrierList.[0-9]+.SCSSpecificCarrier.subcarrierSpacing", node_dict['path']):
        ret = NODE_NOT_CHANGE
        new_node = {'path':node_dict['path'].replace(".subcarrierSpacing", ".SubcarrierSpacing", 1), 'value':node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.SSB.ssbPositionsInBurst.InOneGroup
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.SSB.SsbPositionsInBurst.InOneGroup
def S5_change_ssbPositionsInBurst(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.SSB.ssbPositionsInBurst.InOneGroup", node_dict['path']):
        ret = NODE_NOT_CHANGE
        new_node = {'path':node_dict['path'].replace(".ssbPositionsInBurst.", ".SsbPositionsInBurst.", 1), 'value':node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.UplinkConfigCommonSIB.TimeAlignmentTimerCommon
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.TimeAlignmentTimerCommon
def S5_change_TimeAlignmentTimerCommon(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.UplinkConfigCommonSIB.TimeAlignmentTimerCommon", node_dict['path']):
        ret = NODE_NOT_CHANGE
        new_node = {'path':node_dict['path'].replace("UplinkConfigCommonSIB.TimeAlignmentTimerCommon", "TimeAlignmentTimerCommon", 1), 'value':node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.RRCTimers.N310/N311 范围：unsignedInt[0:7]
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.RRCTimers.N310/N311 范围：unsignedInt[0:6]
def S5_change_N31x(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.RRCTimers.N31[01]", node_dict['path']):
        ret = NODE_NOT_CHANGE
        new_value = int(node_dict['value'])
        if new_value >= 7:
            new_value = 6
        new_node = {'path':node_dict['path'], 'value':str(new_value)}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL/BWPUL.{i}.DlBWPId/UlBWPId  范围：unsignedInt[1:5]
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL/BWPUL.{i}.DlBWPId/UlBWPId  范围：unsignedInt[0:4]
def S5_change_BWPId(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.BWP.BWP[DU]L.[0-9]+.[DU]lBWPId", node_dict['path']):
        #print(node_dict)
        ret = NODE_NOT_CHANGE
        value = int(node_dict['value'])
        if value >= 1 and value <= 5:
            new_value = value - 1
            new_node = {'path':node_dict['path'], 'value':str(new_value)}
            new_node_list.append(new_node)
            ret = NODE_CHANGE
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.RACHConfigGeneric.{i}.PrachConfigurationIndex
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPUL.{i}.RACHConfigGeneric.PrachConfigurationIndex
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.RACHConfigGeneric.{i}.BWPId
def S5_change_RACHConfigGeneric(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.RACHConfigGeneric.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        RACHConfigGeneric_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1              
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_RACHConfigGeneric_info in g_gnb_RACHConfigGeneric_info_list:
                if CellConfig_inst == gnb_RACHConfigGeneric_info["CellConfig_inst"] and \
                RACHConfigGeneric_inst == gnb_RACHConfigGeneric_info["RACHConfigGeneric_inst"]:
                    bwpid = gnb_RACHConfigGeneric_info["BWPId"]
                    bwpid_exist = True
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPUL实例号
            for gnb_BWPUL_info in g_gnb_BWPUL_info_list:
                if bwpid == gnb_BWPUL_info["UlBWPId"]  and CellConfig_inst == gnb_BWPUL_info["CellConfig_inst"]:
                    BWPUL_inst = gnb_BWPUL_info["BWPUL_inst"]
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.{1}.RACHConfigGeneric.{2}".format(int(split_list[5]), BWPUL_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPUL实例号，默认BWPUL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.1.RACHConfigGeneric.{1}".format(int(split_list[5]), leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.RACHConfigCommon.{i}.RootType
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPUL.{i}.RACHConfigCommon.RootType
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.RACHConfigCommon.{i}.BWPId
def S5_change_RACHConfigCommon(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.RACHConfigCommon.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        RACHConfigCommon_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1                 
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_RACHConfigCommon_info in g_gnb_RACHConfigCommon_info_list:
                if CellConfig_inst == gnb_RACHConfigCommon_info["CellConfig_inst"] and \
                RACHConfigCommon_inst == gnb_RACHConfigCommon_info["RACHConfigCommon_inst"]:
                    bwpid = gnb_RACHConfigCommon_info["BWPId"]
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPUL实例号
            for gnb_BWPUL_info in g_gnb_BWPUL_info_list:
                if bwpid == gnb_BWPUL_info["UlBWPId"] and CellConfig_inst == gnb_BWPUL_info["CellConfig_inst"]:
                    BWPUL_inst = gnb_BWPUL_info["BWPUL_inst"]
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.{1}.RACHConfigCommon.{2}".format(CellConfig_inst, BWPUL_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPUL实例号，默认BWPUL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.1.RACHConfigCommon.{1}".format(CellConfig_inst, leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE                    
        else:
            ret = NODE_DISCARD
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUCCHConfigCommon.{i}.PucchResourceCommon
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPUL.{i}.PUCCHConfigCommon.PucchResourceCommon
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUCCHConfigCommon.{i}.BWPId
def S5_change_PUCCHConfigCommon(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PUCCHConfigCommon.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        PUCCHConfigCommon_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1            
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_PUCCHConfigCommon_info in g_gnb_PUCCHConfigCommon_info_list:
                if CellConfig_inst == gnb_PUCCHConfigCommon_info["CellConfig_inst"] and \
                PUCCHConfigCommon_inst == gnb_PUCCHConfigCommon_info["PUCCHConfigCommon_inst"]:
                    bwpid = gnb_PUCCHConfigCommon_info["BWPId"]
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPUL实例号
            for gnb_BWPUL_info in g_gnb_BWPUL_info_list:
                if bwpid == gnb_BWPUL_info["UlBWPId"] and CellConfig_inst == gnb_BWPUL_info["CellConfig_inst"]:   
                    BWPUL_inst = gnb_BWPUL_info["BWPUL_inst"]
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.{1}.PUCCHConfigCommon.{2}".format(int(split_list[5]), BWPUL_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPUL实例号，默认BWPUL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.1.PUCCHConfigCommon.{1}".format(int(split_list[5]), leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHConfigCommon.{i}.ControlResourceSetZero
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.PDCCH.PDCCHConfigCommon.ControlResourceSetZero
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHConfigCommon.{i}.BWPId
def S5_change_PDCCHConfigCommon(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDCCHConfigCommon.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        PDCCHConfigCommon_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_PDCCHConfigCommon_info in g_gnb_PDCCHConfigCommon_info_list:
                if CellConfig_inst == gnb_PDCCHConfigCommon_info["CellConfig_inst"] and \
                PDCCHConfigCommon_inst == gnb_PDCCHConfigCommon_info["PDCCHConfigCommon_inst"]:
                    bwpid = gnb_PDCCHConfigCommon_info["BWPId"]
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPDL实例号
            for gnb_BWPDL_info in g_gnb_BWPDL_info_list:
                if bwpid == gnb_BWPDL_info["DlBWPId"] and CellConfig_inst == gnb_BWPDL_info["CellConfig_inst"]:
                    BWPDL_inst = gnb_BWPDL_info["BWPDL_inst"]
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.{1}.PDCCH.PDCCHConfigCommon.{2}".format(CellConfig_inst, BWPDL_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPDL实例号，默认BWPDL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.1.PDCCH.PDCCHConfigCommon.{1}".format(CellConfig_inst, leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUSCHConfigCommon.{i}.GroupHoppingEnabledTransformPrecoding
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPUL.{i}.PUSCHConfigCommon.GroupHoppingEnabledTransformPrecoding
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUSCHConfigCommon.{i}.BWPId
def S5_change_PUSCHConfigCommon(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PUSCHConfigCommon.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        PUSCHConfigCommon_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_PUSCHConfigCommon_info in g_gnb_PUSCHConfigCommon_info_list:
                if CellConfig_inst == gnb_PUSCHConfigCommon_info["CellConfig_inst"] and \
                PUSCHConfigCommon_inst == gnb_PUSCHConfigCommon_info["PUSCHConfigCommon_inst"]:
                    bwpid = gnb_PUSCHConfigCommon_info["BWPId"]
                    bwpid_exist = True
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPUL实例号
            for gnb_BWPUL_info in g_gnb_BWPUL_info_list:
                if bwpid == gnb_BWPUL_info["UlBWPId"] and CellConfig_inst == gnb_BWPUL_info["CellConfig_inst"]:
                    BWPUL_inst = gnb_BWPUL_info["BWPUL_inst"]
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.{1}.PUSCHConfigCommon.{2}".format(CellConfig_inst, BWPUL_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPUL实例号，默认BWPUL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.1.PUSCHConfigCommon.{1}".format(CellConfig_inst, leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret


# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonSearchSpaceList.{i}.AggregationLevel1/AggregationLevel2/AggregationLevel4/AggregationLevel8/AggregationLevel16
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.PDCCH.CommonSearchSpaceList.{i}.nrofCandidates.AggregationLevel1/AggregationLevel2/AggregationLevel4/AggregationLevel8/AggregationLevel16
# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonSearchSpaceList.{i}.SearchSpaceId
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.PDCCH.CommonSearchSpaceList.{i}.SearchSpaceId
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonSearchSpaceList.{i}.BWPId
def S5_change_PDCCHCommonSearchSpaceList(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDCCHCommonSearchSpaceList.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        PDCCHCommonSearchSpaceList_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1            
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_PDCCHCommonControlResourceSet_info in g_gnb_PDCCHCommonSearchSpaceList_info_list:
                if CellConfig_inst == gnb_PDCCHCommonControlResourceSet_info["CellConfig_inst"] and \
                PDCCHCommonSearchSpaceList_inst == gnb_PDCCHCommonControlResourceSet_info["PDCCHCommonSearchSpaceList_inst"]:
                    bwpid = gnb_PDCCHCommonControlResourceSet_info["BWPId"]
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPDL实例号
            for gnb_BWPDL_info in g_gnb_BWPDL_info_list:
                if bwpid == gnb_BWPDL_info["DlBWPId"] and CellConfig_inst == gnb_BWPDL_info["CellConfig_inst"]:               
                    BWPDL_inst = gnb_BWPDL_info["BWPDL_inst"]
                    if re.match("AggregationLevel[0-9]+", leaf_node):
                        new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.{1}.PDCCH.CommonSearchSpaceList.{2}.nrofCandidates.{3}".format(CellConfig_inst, BWPDL_inst, PDCCHCommonSearchSpaceList_inst, leaf_node), 'value':node_dict['value']}
                    else:
                        new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.{1}.PDCCH.CommonSearchSpaceList.{2}.{3}".format(CellConfig_inst, BWPDL_inst, PDCCHCommonSearchSpaceList_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPDL实例号，默认BWPDL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                if re.match("AggregationLevel[0-9]+", leaf_node):
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.1.PDCCH.CommonSearchSpaceList.{1}.nrofCandidates.{2}".format(CellConfig_inst, PDCCHCommonSearchSpaceList_inst, leaf_node), 'value':node_dict['value']}
                else:
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.1.PDCCH.CommonSearchSpaceList.{1}.{2}".format(CellConfig_inst, PDCCHCommonSearchSpaceList_inst, leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUSCHTimeDomainAllocationList.{i}.K2
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPUL.{i}.PUSCHTimeDomainAllocationList.{i}.K2
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PUSCHTimeDomainAllocationList.{i}.BWPId
def S5_change_PUSCHTimeDomainAllocationList(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PUSCHTimeDomainAllocationList.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        PUSCHTimeDomainAllocationList_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_PUSCHTimeDomainAllocationList_info in g_gnb_PUSCHTimeDomainAllocationList_info_list:
                if CellConfig_inst == gnb_PUSCHTimeDomainAllocationList_info["CellConfig_inst"] and \
                PUSCHTimeDomainAllocationList_inst == gnb_PUSCHTimeDomainAllocationList_info["PUSCHTimeDomainAllocationList_inst"]:           
                    bwpid = gnb_PUSCHTimeDomainAllocationList_info["BWPId"]
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPUL实例号
            for gnb_BWPUL_info in g_gnb_BWPUL_info_list:
                if bwpid == gnb_BWPUL_info["UlBWPId"] and CellConfig_inst == gnb_BWPUL_info["CellConfig_inst"]:                
                    BWPUL_inst = gnb_BWPUL_info["BWPUL_inst"]
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.{1}.PUSCHTimeDomainAllocationList.{2}.{3}".format(CellConfig_inst, BWPUL_inst, PUSCHTimeDomainAllocationList_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPUL实例号，默认BWPUL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPUL.1.PUSCHTimeDomainAllocationList.{1}.{2}".format(CellConfig_inst, PUSCHTimeDomainAllocationList_inst, leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDSCHTimeDomainResourceAllocationList.{i}.K0
# V1.1 1226:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.PDSCH.PDSCHTimeDomainResourceAllocationList.{i}.K0
# 抛弃：V1.1.8：:Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDSCHTimeDomainResourceAllocationList.{i}.BWPId
def S5_change_PDSCHTimeDomainResourceAllocationList(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDSCHTimeDomainResourceAllocationList.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])
        PDSCHTimeDomainResourceAllocationList_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_PDSCHTimeDomainResourceAllocationList_info in g_gnb_PDSCHTimeDomainResourceAllocationList_info_list:
                if CellConfig_inst == gnb_PDSCHTimeDomainResourceAllocationList_info["CellConfig_inst"] and \
                PDSCHTimeDomainResourceAllocationList_inst == gnb_PDSCHTimeDomainResourceAllocationList_info["PDSCHTimeDomainResourceAllocationList_inst"]:          
                    bwpid = gnb_PDSCHTimeDomainResourceAllocationList_info["BWPId"]
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPDL实例号
            for gnb_BWPDL_info in g_gnb_BWPDL_info_list:            
                if bwpid == gnb_BWPDL_info["DlBWPId"] and CellConfig_inst == gnb_BWPDL_info["CellConfig_inst"]:
                    BWPDL_inst = gnb_BWPDL_info["BWPDL_inst"]
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.{1}.PDSCH.PDSCHTimeDomainResourceAllocationList.{2}.{3}".format(CellConfig_inst, BWPDL_inst, PDSCHTimeDomainResourceAllocationList_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPDL实例号，默认BWPDL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.1.PDSCH.PDSCHTimeDomainResourceAllocationList.{1}.{2}".format(CellConfig_inst, PDSCHTimeDomainResourceAllocationList_inst, leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret

# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonControlResourceSet.{i}.CceRegMappingType
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.PDCCH.CommonControlResourceSet.CceRegMappingType.RegType
# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonControlResourceSet.{i}.RegBundleSize/InterleaverSize/ShiftIndex
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.PDCCH.CommonControlResourceSet.CceRegMappingType.RegBundleSize/InterleaverSize/ShiftIndex
# V1.1.8：   Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonControlResourceSet.{i}.ControlResourceSetId/FrequencyDomainResources/Duration/PrecoderGranularityPdcchDMRSScramblingID
# V1.1 1226: Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.BWP.BWPDL.{i}.PDCCH.CommonControlResourceSet.ControlResourceSetId/FrequencyDomainResources/Duration/PrecoderGranularityPdcchDMRSScramblingID
# 抛弃：V1.1.8：Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.PDCCHCommonControlResourceSet.{i}.BWPId
def S5_change_PDCCHCommonControlResourceSet(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if re.match("Device.Services.FAPService.[0-9]+.CellConfig.[0-9]+.NR.RAN.PHY.PDCCHCommonControlResourceSet.[0-9]+", node_dict['path']):
        ret = NODE_NOT_CHANGE
        split_list = node_dict['path'].split(".")
        CellConfig_inst = int(split_list[5])        
        PDCCHCommonControlResourceSet_inst = int(split_list[10])
        if len(split_list) >= 12:  # 检查split_list的长度是否大于等于12
            leaf_node = split_list[11]
            if leaf_node == "BWPId":
                ret = NODE_DISCARD
                return ret
            #如果未查找到对应BWPId，则默认BWPId为1
            bwpid = 1
            #遍历列表，通过实例号查找对应的BWPId
            for gnb_PDCCHCommonControlResourceSet_info in g_gnb_PDCCHCommonControlResourceSet_info_list:
                if CellConfig_inst == gnb_PDCCHCommonControlResourceSet_info["CellConfig_inst"] and \
                PDCCHCommonControlResourceSet_inst == gnb_PDCCHCommonControlResourceSet_info["PDCCHCommonControlResourceSet_inst"]:         
                    bwpid = gnb_PDCCHCommonControlResourceSet_info["BWPId"]
                    break
            #遍历列表，通过BWPId, CellConfig实例号查找对应的BWPDL实例号
            for gnb_BWPDL_info in g_gnb_BWPDL_info_list:            
                if bwpid == gnb_BWPDL_info["DlBWPId"] and CellConfig_inst == gnb_BWPDL_info["CellConfig_inst"]:
                    BWPDL_inst = gnb_BWPDL_info["BWPDL_inst"]
                    if leaf_node == "CceRegMappingType":
                        new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.{1}.PDCCH.CommonControlResourceSet.CceRegMappingType.RegType".format(CellConfig_inst, BWPDL_inst), 'value':node_dict['value']}
                    elif leaf_node == "RegBundleSize" or leaf_node == "InterleaverSize" or leaf_node == "ShiftIndex":
                        new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.{1}.PDCCH.CommonControlResourceSet.CceRegMappingType.{2}".format(CellConfig_inst, BWPDL_inst, leaf_node), 'value':node_dict['value']}
                    else:
                        new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.{1}.PDCCH.CommonControlResourceSet.{2}".format(CellConfig_inst, BWPDL_inst, leaf_node), 'value':node_dict['value']}
                    new_node_list.append(new_node)
                    ret = NODE_CHANGE
                    break
            #通过默认BWPId，未查到查找对应的BWPDL实例号，默认BWPDL实例号为1
            if ret == NODE_NOT_CHANGE and bwpid == 1:
                if leaf_node == "CceRegMappingType":
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.1.PDCCH.CommonControlResourceSet.CceRegMappingType.RegType".format(CellConfig_inst), 'value':node_dict['value']}
                elif leaf_node == "RegBundleSize" or leaf_node == "InterleaverSize" or leaf_node == "ShiftIndex":
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.1.PDCCH.CommonControlResourceSet.CceRegMappingType.{1}".format(CellConfig_inst, leaf_node), 'value':node_dict['value']}
                else:
                    new_node = {'path':"Device.Services.FAPService.1.CellConfig.{0}.NR.RAN.PHY.BWP.BWPDL.1.PDCCH.CommonControlResourceSet.{1}".format(CellConfig_inst, leaf_node), 'value':node_dict['value']}
                new_node_list.append(new_node)
                ret = NODE_CHANGE
        else:
            ret = NODE_DISCARD
    return ret

#当前有存在这个脚本的版本，都需要进行转换，只需要判断是否为CUCC即可
def check_version_need_trans(node_list):
    return True

# 通过数据模型判断是否需要转换配置，仅联通才需要进行转换
# 路径：/data/.5gnr/app_data/oam_core/.oam_operator_mode_msg
def check_operator_mode_need_trans():
    #文件不存在，无法判断运营商类型，不做转换
    if not os.path.exists(OPERATOR_MODE_PATH):
        write_log_file("not exist:" + OPERATOR_MODE_PATH)
        return False
        
    file = open(OPERATOR_MODE_PATH, 'r')
    operator_mode = file.read(OPERATOR_MODE_LENTH)
    file.close()

    #判断是否为联通数据模型
    if operator_mode == OPERATOR_MODE_CUCC:
        return True
    else:
        write_log_file(".oam_operator_mode_msg:" + operator_mode)
        return False

if __name__ == "__main__":
    
    if len(sys.argv) != 3:
        print("arg num invalid")
        for arg in sys.argv:
            print(arg)
        exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    if not os.access(input_file, os.F_OK):
        print(input_file, "not exist!")
        write_log_file("input_file: " + input_file + " is not exist!")
        exit(1)

    # 假设新旧节点的层级相同，仅节点名不同
    xml_tree = ET.ElementTree(file = input_file)
    root_ele = xml_tree.getroot()

    node = str()
    node_list = list()
    foreach_xml(root_ele, node, node_list)
    new_root = ET.Element(ROOT_TAG_NAME)
    
    #print(node_list)
    if check_version_need_trans(node_list) is True and\
    check_operator_mode_need_trans() is True:
        print("start transfer...")
        get_base_info_from_node_list(node_list)
        write_log_file("input_file: " + input_file)
        write_log_file("output_file: " + output_file)
        write_log_file("RACHConfigGeneric list: " + str(g_gnb_RACHConfigGeneric_info_list))
        write_log_file("RACHConfigCommon list: " + str(g_gnb_RACHConfigCommon_info_list))
        write_log_file("PUCCHConfigCommon list: " + str(g_gnb_PUCCHConfigCommon_info_list))
        write_log_file("PDCCHConfigCommon list: " + str(g_gnb_PDCCHConfigCommon_info_list))
        write_log_file("PUSCHConfigCommon list: " + str(g_gnb_PUSCHConfigCommon_info_list))
        write_log_file("PDCCHCommonSearchSpaceList list: " + str(g_gnb_PDCCHCommonSearchSpaceList_info_list))
        write_log_file("PUSCHTimeDomainAllocationList list: " + str(g_gnb_PUSCHTimeDomainAllocationList_info_list))
        write_log_file("PDSCHTimeDomainResourceAllocationList list: " + str(g_gnb_PDSCHTimeDomainResourceAllocationList_info_list))
        write_log_file("BWPUL list: " + str(g_gnb_BWPUL_info_list))
        write_log_file("BWPDL list: " + str(g_gnb_BWPDL_info_list))

        new_node_list = list()
        for node_dict in node_list:
            if S5_change_CellReservedForOtherUse(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_SPSSwitchQCI1Ul(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_TA(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_subcarrierSpacing(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_ssbPositionsInBurst(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_TimeAlignmentTimerCommon(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_N31x(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_BWPId(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_RACHConfigGeneric(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_RACHConfigCommon(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_PUCCHConfigCommon(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_PDCCHConfigCommon(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_PUSCHConfigCommon(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_PDCCHCommonSearchSpaceList(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_PUSCHTimeDomainAllocationList(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_PDSCHTimeDomainResourceAllocationList(node_dict, new_node_list) is NODE_NOT_MATCH and\
            S5_change_PDCCHCommonControlResourceSet(node_dict, new_node_list) is NODE_NOT_MATCH:
                new_node_list.append(node_dict)
        #print(new_node_list)
        #new_node_list.sort()
        
        for node_dict in new_node_list:
            new_list = node_dict['path'].strip().strip(".").split(".")
            #print(node_dict['path'], node_dict['value'])
        
            i = 0
            inst_list = []
            build_new_xml(new_root, i, new_list, inst_list, node_dict['value'])
        
        pretty_xml(new_root)
        ele_tree = ET.ElementTree(new_root)
        ele_tree.write(output_file, encoding="utf-8", xml_declaration=True)
    else:
        print("no need to transfer...")


