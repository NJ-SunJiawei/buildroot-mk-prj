#!/usr/bin/env python2
# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
import sys
import os

ROOT_TAG_NAME = "Config"
NODE_NOT_MATCH = 0
NODE_CHANGE = 1

OAM_OPERATOR_MODE_PATH = "/data/.5gnr/app_data/oam_core/.oam_operator_mode_msg"
OPERATOR_MODE_CMCC = "cmcc"
OPERATOR_MODE_CUCC = "cucc"
OPERATOR_MODE_CTCC = "ctcc"

def get_oam_operator_mode():
    if not os.path.exists(OAM_OPERATOR_MODE_PATH):
        return OPERATOR_MODE_CMCC
    with open(OAM_OPERATOR_MODE_PATH, 'r') as f_op_mode:
        contents = f_op_mode.read()
        contents = contents.lower()
        if OPERATOR_MODE_CUCC in contents:
            return OPERATOR_MODE_CUCC
        elif OPERATOR_MODE_CTCC in contents:
            return OPERATOR_MODE_CTCC
        else: 
            return OPERATOR_MODE_CMCC

def foreach_xml(element, node, node_list):
    if element != None:
        # 有子元素无属性
        if len(element.getchildren()) and len(element.attrib) == 0:
            if str(element.tag) != ROOT_TAG_NAME:
                node += element.tag + '.'
        # 有属性
        elif len(element.attrib) != 0:
            node += element.tag + '.' + element.attrib['instance_id']
            #无子元素说明结束
            if len(element.getchildren()) == 0:
                node_list.append({'path': node, 'value': None})
            else:
                node += '.'
        #无子元素
        else:
            node += element.tag
            node_list.append({'path': node, 'value': element.text})
    # 将element转成list
    temp = list(element)
    for subelement in temp:
        # 对子元素进行递归操作
        foreach_xml(subelement, node, node_list)

def pretty_xml(element, indent="  ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    if element != None:  # 判断element是否有子元素   
        if len(element.getchildren()) == 0:
            pass
        elif (element.text is None) or element.text.isspace():  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
        else:  # 此处两行如果把注释去掉，Element的text也会另起一行
            element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * level

    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def gen_xpath(node_list, inst_list):
    i = 0
    path = ""
    for node in node_list:
        if node.isdigit():
            path += '[@instance_id="%s"]/' % inst_list[i]
            i += 1
        else:
            path += node + "/"
    return path.strip("/")

def build_new_xml(root_ele, i, new_list, inst_list, value):
    if i >= len(new_list):
        return
    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if root_ele.find(new_xp) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
        i += 2
        build_new_xml(root_ele, i, new_list, inst_list, value)
        inst_list.pop()
        i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            if len(new_list[:i]):
                ET.SubElement(cu_ele, new_list[i])
            else:
                ET.SubElement(root_ele, new_list[i])
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = value
        i += 1
        build_new_xml(root_ele, i, new_list, inst_list, value)
        i -= 1

def build_new_xml_with_xpath_node_dict(root_ele, i, new_list, inst_list, value, xpath_dict):
    if i >= len(new_list):
        return
    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if xpath_dict.has_key(new_xp) is False:
            pre_xp = gen_xpath(new_list[:i], inst_list)
            if xpath_dict.has_key(pre_xp):
                cu_ele = xpath_dict[pre_xp]
                xml_node = ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
                xpath_dict.update({new_xp:xml_node})
        i += 2
        build_new_xml_with_xpath_node_dict(root_ele, i, new_list, inst_list, value, xpath_dict)
        inst_list.pop()
        i -= 2
    else:
        new_xp = gen_xpath(new_list[:i + 1], inst_list)
        if xpath_dict.has_key(new_xp) is False:
            if len(new_list[:i]):
                pre_xp = gen_xpath(new_list[:i], inst_list)
                if xpath_dict.has_key(pre_xp):
                    cu_ele = xpath_dict[pre_xp]
                    xml_node = ET.SubElement(cu_ele, new_list[i])
                    xpath_dict.update({new_xp:xml_node})
            else:
                xml_node = ET.SubElement(root_ele, new_list[i])
                xpath_dict.update({new_xp:xml_node})
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            if xpath_dict.has_key(new_xp) is True:
                cu_ele = xpath_dict[new_xp]
                cu_ele.text = value
            else:
                cu_ele = root_ele.find(new_xp)
                cu_ele.text = value
        i += 1
        build_new_xml_with_xpath_node_dict(root_ele, i, new_list, inst_list, value, xpath_dict)
        i -= 1

# 联通节点 AmfPoolConfigParam 变更为 AMFPoolConfigParam
# AMFPort变更为AmfPort
def pj3_amfpool_trans_s5(node_dict, new_node_list):
    if '.AmfPoolConfigParam.' in node_dict['path']:
        split_list = node_dict['path'].split(".")
        node_dict['path'] = ''
        for split in split_list[0:-1]:
            if (split == 'AmfPoolConfigParam'):
                node_dict['path'] += 'AMFPoolConfigParam' + '.'
            else:
                node_dict['path'] += split + '.'
        if (split_list[-1] == 'AMFPort'):
            node_dict['path'] += 'AmfPort'
        else:
            node_dict['path'] += split_list[-1]
        new_node_list.append(node_dict)        
        return NODE_CHANGE
    else: 
        return NODE_NOT_MATCH

# 联通节点 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.NeighborList.LTECell.{i}.QOffset
# 变更 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.NeighborList.LTECell.{i}.Qoffset 
# 联通节点 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.NeighborList.NRCell.{i}.QOffset
# 变更 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.NeighborList.NRCell.{i}.Qoffset 
def pj3_neighbor_trans_s5(node_dict, new_node_list):
    if '.NR.RAN.NeighborList.' in node_dict['path'] and '.QOffset' in node_dict['path']:
        split_list = node_dict['path'].split(".")
        node_dict['path'] = ''
        for split in split_list[0:-1]:
            node_dict['path'] += split + '.'
        node_dict['path'] += 'Qoffset'
        new_node_list.append(node_dict)        
        return NODE_CHANGE
    else: 
        return NODE_NOT_MATCH

# 联通节点 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.IdleMode.IntraFreq.QQualminoffset
# 变更 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.IdleMode.IntraFreq.Qqualminoffset
def pj3_idlemode_intrafreq_trans_s5(node_dict, new_node_list):
    if '.NR.RAN.Mobility.IdleMode.IntraFreq.' in node_dict['path'] and '.QQualminoffset' in node_dict['path']:
        split_list = node_dict['path'].split(".")
        node_dict['path'] = ''
        for split in split_list[0:-1]:
            node_dict['path'] += split + '.'
        node_dict['path'] += 'Qqualminoffset'
        new_node_list.append(node_dict)        
        return NODE_CHANGE
    else: 
        return NODE_NOT_MATCH

# 联通节点 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.IdleMode.InterFreq.Carrier.{i}.QOffsetFreq
# 变更 Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.Mobility.IdleMode.InterFreq.Carrier.{i}.QoffsetFreq
def pj3_idlemode_interfreq_trans_s5(node_dict, new_node_list):
    if '.NR.RAN.Mobility.IdleMode.InterFreq.Carrier.' in node_dict['path'] and '.QOffsetFreq' in node_dict['path']:
        split_list = node_dict['path'].split(".")
        node_dict['path'] = ''
        for split in split_list[0:-1]:
            node_dict['path'] += split + '.'
        node_dict['path'] += 'QoffsetFreq'
        new_node_list.append(node_dict)        
        return NODE_CHANGE
    else: 
        return NODE_NOT_MATCH

# 私有节点 Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.%d.CellConfig.%d.NR.Capabilities.maxuenum
# 变更规范节点 Device.Services.FAPService.%d.CellConfig.%d.NR.Capabilities.MaxUEsServed
def pj3_maxuenum_trans(node_dict, new_node_list):
    if '.X_WWW-RUIJIE-COM-CN.' in node_dict['path'] and '.maxuenum' in node_dict['path']:
        node_dict['path'] = node_dict['path'].replace('.X_WWW-RUIJIE-COM-CN.', '.').replace('.maxuenum', '.MaxUEsServed')
        new_node_list.append(node_dict)
        return NODE_CHANGE
    else: 
        return NODE_NOT_MATCH        

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("arg num invalid")
        for arg in sys.argv:
            print(arg)
        exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    if not os.access(input_file, os.F_OK):
        print(input_file, "not exist!")
        exit(1)

    xml_tree = ET.ElementTree(file = input_file)
    root_ele = xml_tree.getroot()

    node = str()
    node_list = list()
    foreach_xml(root_ele, node, node_list)
    node_need_trans = False
    oam_operator_mode = get_oam_operator_mode()
    new_node_list = list()
    for node_dict in node_list:
        if oam_operator_mode == OPERATOR_MODE_CUCC:
            if pj3_amfpool_trans_s5(node_dict, new_node_list) == NODE_NOT_MATCH and \
            pj3_neighbor_trans_s5(node_dict, new_node_list) == NODE_NOT_MATCH and \
            pj3_idlemode_intrafreq_trans_s5(node_dict, new_node_list) == NODE_NOT_MATCH and \
            pj3_idlemode_interfreq_trans_s5(node_dict, new_node_list) == NODE_NOT_MATCH and \
            pj3_maxuenum_trans(node_dict, new_node_list) == NODE_NOT_MATCH:
                new_node_list.append(node_dict)
            else:
                node_need_trans = True
        else:
            if pj3_maxuenum_trans(node_dict, new_node_list) == NODE_NOT_MATCH:
                new_node_list.append(node_dict)
            else:
                node_need_trans = True            

    if node_need_trans == True:
        new_root = ET.Element(ROOT_TAG_NAME)
        xpath_dict = {}
        for node_dict in new_node_list:
            new_list = node_dict['path'].strip().strip(".").split(".")
            i = 0
            inst_list = []
            # build_new_xml(new_root, i, new_list, inst_list, node_dict['value'])
            build_new_xml_with_xpath_node_dict(new_root, i, new_list, inst_list, node_dict['value'], xpath_dict)

        pretty_xml(new_root)
        ele_tree = ET.ElementTree(new_root)
        ele_tree.write(output_file, encoding="utf-8", xml_declaration=True)

