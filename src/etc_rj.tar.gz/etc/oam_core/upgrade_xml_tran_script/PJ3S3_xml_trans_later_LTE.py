#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import sys
import os
import time

ROOT_TAG_NAME = "Config"

def pretty_xml(element, indent="  ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    node=" "
    if element != None:  # 判断element是否有子元素   
        if len(element.getchildren()) == 0:
            node += str(element.tag)
            pass 
        elif (element.text is None) or element.text.isspace():  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
        # else:
        #     element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * (level + 1)
        else:  # 此处两行如果把注释去掉，Element的text也会另起一行
            element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * level

    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def foreach_xml(element, node, node_list):
    if element != None:
        # 有子元素无属性
        if len(element.getchildren()) and len(element.attrib) == 0:
            if str(element.tag) != ROOT_TAG_NAME:
                node += element.tag + '.'
        # 有属性
        elif len(element.attrib) != 0:
            node += element.tag + '.' + element.attrib['instance_id']
            #无子元素说明结束
            if len(element.getchildren()) == 0:
                node_list.append({'path': node, 'value': None})
                pass
            else:
                node += '.'
        #无子元素
        else:
            node += element.tag
            node_list.append({'path': node, 'value': element.text})
            node = ""
            pass
    # 将element转成list
    temp = list(element)
    for subelement in temp:
        # 对子元素进行递归操作
        foreach_xml(subelement, node, node_list)

def gen_xpath(node_list, inst_list):
    i = 0
    path = ""
    for node in node_list:
        if node.isdigit():
            path += '[@instance_id="%s"]/' % inst_list[i]
            i += 1
        else:
            path += node + "/"
    return path.strip("/")


def build_new_xml(root_ele, i, new_list, inst_list, value):
    if i >= len(new_list):
        return

    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if root_ele.find(new_xp) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
        i += 2
        build_new_xml(root_ele, i, new_list, inst_list, value)
        inst_list.pop()
        i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            if len(new_list[:i]):
                ET.SubElement(cu_ele, new_list[i])
            else:
                ET.SubElement(root_ele, new_list[i])
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = value
        i += 1
        build_new_xml(root_ele, i, new_list, inst_list, value)
        i -= 1


def recur_mkele(root_ele, old_list, i, new_list, inst_list):
    if i >= len(new_list):
        return
    if i + 1 != len(new_list) and new_list[i + 1] == "{i}":
        old_xp = gen_xpath(old_list[:i + 1], inst_list)

        for ele in root_ele.findall(old_xp):
            inst_list.append(ele.attrib["instance_id"])
            new_xp = gen_xpath(new_list[:i + 2], inst_list)
            if root_ele.find(new_xp) == None:
                cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
                ET.SubElement(cu_ele, new_list[i], {"instance_id":ele.attrib["instance_id"]})
            i += 2
            recur_mkele(root_ele, old_list, i, new_list, inst_list)
            inst_list.pop()
            i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i])
        if i + 1 == len(new_list):
            old_xp = gen_xpath(old_list[:i + 1], inst_list)
            leaf_val = root_ele.find(old_xp).text

            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = leaf_val
        i += 1
        recur_mkele(root_ele, old_list, i, new_list, inst_list)
        i -= 1

LOG_PATH = "/run_isolate/local_log/enb_cu"

NODE_NOT_MATCH = 0
NODE_CHANGE = 1
NODE_NOT_CHANGE = 2
NODE_DISCARD = 3

IPV4 = 4
IPV6 = 6

MAX_UINT_VALUE = 4294967295

DUPLEX_MODE_TDD = 0
DUPLEX_MODE_FDD = 1
DUPLEX_MODE_FDD_TDD = 2

TDD_DEFAULT_FREQ_BAND = 41
TDD_DEFAULT_EARFCNDL = 40940
TDD_DEFAULT_EARFCNUL = TDD_DEFAULT_EARFCNDL
TDD_DEFAULT_BAND_WIDTH = 100
TDD_DEFAULT_SSP = 7
TDD_DEFAULT_SA = 2

FDD_DEFAULT_FREQ_BAND = 3
FDD_DEFAULT_EARFCNDL = 1300
FDD_DEFAULT_EARFCNUL = 19300
FDD_DEFAULT_BAND_WIDTH = 100

g_config_need_change = True

g_lte_cell_info_list = list()

# 当前版本支持制式
g_duplex_mode_support = DUPLEX_MODE_FDD_TDD

g_fdd_support_freq_band_list = [3]
g_tdd_support_freq_band_list = [41]


def get_duplex_mode_support():
    global g_duplex_mode_support
    g_duplex_mode_support = DUPLEX_MODE_FDD_TDD
    duplex_mode_support_file = "/sbin/enb/cfg/duplexing_mode_support.txt"
    if os.access(duplex_mode_support_file, os.F_OK):
        file = open(duplex_mode_support_file, 'r')
        content = file.read()
        file.close()
        # 后续版本如同时支持 TDD 和 FDD, 该文件要删掉
        if "tdd" in content:
            g_duplex_mode_support = DUPLEX_MODE_TDD
        elif "fdd" in content:
            g_duplex_mode_support = DUPLEX_MODE_FDD


def write_log_file(str):
    if not os.path.exists(LOG_PATH):
        os.system("mkdir -p {0}".format(LOG_PATH))
    file = open("{0}/PJ3S3_xml_trans_later_LTE.log".format(LOG_PATH), 'a')
    file.write("{0} : {1}\n".format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), str))
    file.close()


def update_lte_cell_info_list(fap_inst, key, value):
    if key in ["PhyCellID", "UserLabel", "RootSequenceIndex", "TAC", "CellIdentity", "FreqBandIndicator"]:
        cell_exist = False
        if g_lte_cell_info_list:
            for lte_cell_info in g_lte_cell_info_list:
                if lte_cell_info["fap_inst"] == fap_inst:
                    cell_exist = True
                    lte_cell_info[key] = value
        if cell_exist is False:
            new_cell_info = {"fap_inst":fap_inst, "PhyCellID":None, "UserLabel":None, "RootSequenceIndex":None, "TAC":None, "CellIdentity":None, "FreqBandIndicator":None}
            new_cell_info[key] = value
            g_lte_cell_info_list.append(new_cell_info)
        #print(g_lte_cell_info_list)


def get_cur_cell_cfg(fap_inst, key):
    value = None
    if g_lte_cell_info_list:
        for lte_cell_info in g_lte_cell_info_list:
            if lte_cell_info["fap_inst"] == fap_inst:
                return lte_cell_info[key]
    return value


def get_base_info_from_node_list(node_list):
    for node_dict in node_list:
        if ".CellConfig.LTE.RAN.RF." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            if split_list[8] in ["PhyCellID", "UserLabel", "FreqBandIndicator"]:
                update_lte_cell_info_list(fap_inst, split_list[8], node_dict['value'])
        elif ".CellConfig.LTE.RAN.PHY.PRACH.RootSequenceIndex" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            update_lte_cell_info_list(fap_inst, "RootSequenceIndex", node_dict['value'])
        elif ".CellConfig.LTE.EPC.TAC" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            update_lte_cell_info_list(fap_inst, "TAC", node_dict['value'])
        elif ".CellConfig.LTE.RAN.Common.CellIdentity" in node_dict['path']:
            split_list = node_dict['path'].split(".")
            fap_inst = int(split_list[3])
            update_lte_cell_info_list(fap_inst, "CellIdentity", node_dict['value'])
        elif "InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.LTE.LinkHost" in node_dict['path']:
            global g_config_need_change
            g_config_need_change = False


# 当前的版本只支持 TDD 时, 若小区配置的 FreqBandIndicator 为在 fdd 列表中,
#   FreqBandIndicator 的值修改为 TDD_DEFAULT_FREQ_BAND,
#   DuplexMode 的值修改为 DUPLEX_MODE_TDD,
#   EARFCNDL 的值修改为 TDD_DEFAULT_EARFCNDL, 
#   EARFCNUL 的值修改为 TDD_DEFAULT_EARFCNUL,
#   DLBandwidth 和 ULBandwidth 的值修改为 TDD_DEFAULT_BAND_WIDTH, 
#   SpecialSubframePatterns 的值修改为 TDD_DEFAULT_SSP, 
#   SubFrameAssignment 的值修改为 TDD_DEFAULT_SA,
#   ConfigurationIndex 的值范围为0~4, 超出该范围则抛弃
# 当前的版本只支持 FDD 时, 若小区配置的 FreqBandIndicator 为在 tdd 列表中,
#   FreqBandIndicator 的值修改为 FDD_DEFAULT_FREQ_BAND,
#   DuplexMode 的值修改为 DUPLEX_MODE_FDD,
#   EARFCNDL 的值修改为 FDD_DEFAULT_EARFCNDL, 
#   EARFCNUL 的值修改为 FDD_DEFAULT_EARFCNUL,
#   抛弃 SpecialSubframePatterns 和 SubFrameAssignment 的节点
# 当前小区 FreqBandIndicator 为 41 时,
#   EARFCNDL 和 EARFCNUL 的值只支持 40936,40937,40938,40940, 
#   DLBandwidth 的值只支持 100(CELL_BW_N100), 
#   SpecialSubframePatterns 的值只支持 7(SSP7_10_2_2), 
#   SubFrameAssignment 的值只支持 7(SA2_DSUDDDSUDD), 
def PJ3_CellConfig_change_S3(node_dict, new_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig.LTE.RAN.RF.FreqBandIndicator" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])
        if g_duplex_mode_support == DUPLEX_MODE_TDD:
            if int(node_dict['value']) not in g_tdd_support_freq_band_list:
                node_dict['value'] = str(TDD_DEFAULT_FREQ_BAND)
        elif g_duplex_mode_support == DUPLEX_MODE_FDD:
            if int(node_dict['value']) not in g_fdd_support_freq_band_list:
                node_dict['value'] = str(FDD_DEFAULT_FREQ_BAND)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.RF.X_WWW-RUIJIE-COM-CN.DuplexMode" in node_dict['path']:
        if g_duplex_mode_support == DUPLEX_MODE_TDD:
            node_dict['value'] = str(DUPLEX_MODE_TDD)
        elif g_duplex_mode_support == DUPLEX_MODE_FDD:
            node_dict['value'] = str(DUPLEX_MODE_FDD)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.RF.EARFCNDL" in node_dict['path'] or ".CellConfig.LTE.RAN.RF.EARFCNUL" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])

        cur_cell_freq_band = get_cur_cell_cfg(fap_inst, "FreqBandIndicator")
        if cur_cell_freq_band is None:
            return ret
        
        if g_duplex_mode_support == DUPLEX_MODE_TDD and int(cur_cell_freq_band) not in g_tdd_support_freq_band_list:
            if split_list[8] == "EARFCNDL":
                node_dict['value'] = str(TDD_DEFAULT_EARFCNDL)
            else:
                node_dict['value'] = str(TDD_DEFAULT_EARFCNUL)
        elif g_duplex_mode_support == DUPLEX_MODE_FDD and int(cur_cell_freq_band) not in g_fdd_support_freq_band_list:
            if split_list[8] == "EARFCNDL":
                node_dict['value'] = str(FDD_DEFAULT_EARFCNDL)
            else:
                node_dict['value'] = str(FDD_DEFAULT_EARFCNUL)
        else:
            if int(cur_cell_freq_band) == 41 and int(node_dict['value']) not in [40936, 40937, 40938, 40940]:
                node_dict['value'] = str(TDD_DEFAULT_EARFCNDL)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.RF.DLBandwidth" in node_dict['path'] or ".CellConfig.LTE.RAN.RF.ULBandwidth" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])

        cur_cell_freq_band = get_cur_cell_cfg(fap_inst, "FreqBandIndicator")
        if cur_cell_freq_band is None:
            return ret
        
        if g_duplex_mode_support == DUPLEX_MODE_TDD and int(cur_cell_freq_band) not in g_tdd_support_freq_band_list:
            node_dict['value'] = str(TDD_DEFAULT_BAND_WIDTH)
        else:
            if int(cur_cell_freq_band) == 41:
                node_dict['value'] = str(TDD_DEFAULT_BAND_WIDTH)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.PHY.TDDFrame.SpecialSubframePatterns" in node_dict['path'] or\
            ".CellConfig.LTE.RAN.PHY.TDDFrame.SubFrameAssignment" in node_dict['path']:
        split_list = node_dict['path'].split(".")
        fap_inst = int(split_list[3])

        cur_cell_freq_band = get_cur_cell_cfg(fap_inst, "FreqBandIndicator")
        if cur_cell_freq_band is None:
            return ret
                
        if g_duplex_mode_support == DUPLEX_MODE_TDD and int(cur_cell_freq_band) not in g_tdd_support_freq_band_list:
            if split_list[9] == "SpecialSubframePatterns":
                node_dict['value'] = str(TDD_DEFAULT_SSP)
            else:
                node_dict['value'] = str(TDD_DEFAULT_SA)
        elif g_duplex_mode_support == DUPLEX_MODE_FDD and int(cur_cell_freq_band) not in g_fdd_support_freq_band_list:
            return NODE_DISCARD
        else:
            if int(cur_cell_freq_band) == 41:
                if split_list[9] == "SpecialSubframePatterns":
                    node_dict['value'] = str(TDD_DEFAULT_SSP)
                else:
                    node_dict['value'] = str(TDD_DEFAULT_SA)
        new_node_list.append(node_dict)
        ret = NODE_CHANGE
    elif ".CellConfig.LTE.RAN.PHY.PRACH.ConfigurationIndex" in node_dict['path']:
        if g_duplex_mode_support == DUPLEX_MODE_TDD:
            if int(node_dict['value']) > 4:
                ret = NODE_DISCARD
    return ret


if __name__ == "__main__":
    
    if len(sys.argv) != 3:
        print("arg num invalid")
        for arg in sys.argv:
            print(arg)
        exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    if not os.access(input_file, os.F_OK):
        print(input_file, "not exist!")
        exit(1)

    # 假设新旧节点的层级相同，仅节点名不同
    xml_tree = ET.ElementTree(file = input_file)
    root_ele = xml_tree.getroot()

    node = str()
    node_list = list()
    foreach_xml(root_ele, node, node_list)
    new_root = ET.Element(ROOT_TAG_NAME)
    get_base_info_from_node_list(node_list)
    if g_config_need_change is True:
        get_duplex_mode_support()
        write_log_file("g_lte_cell_info_list : " + str(g_lte_cell_info_list))
        write_log_file("g_duplex_mode_support : " + str(g_duplex_mode_support))
        new_node_list = list()
        for node_dict in node_list:
            if PJ3_CellConfig_change_S3(node_dict, new_node_list) is NODE_NOT_MATCH:
                new_node_list.append(node_dict)
        #new_node_list.sort()
        for node_dict in new_node_list:
            new_list = node_dict['path'].strip().strip(".").split(".")
            #print(node_dict['path'], node_dict['value'])
            i = 0
            inst_list = []
            build_new_xml(new_root, i, new_list, inst_list, node_dict['value'])
        pretty_xml(new_root)
        ele_tree = ET.ElementTree(new_root)
        ele_tree.write(output_file, encoding="utf-8", xml_declaration=True)