#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import xml.etree.cElementTree as ET
import sys
import os
import time

ROOT_TAG_NAME = "Config"

def pretty_xml(element, indent="  ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    node=" "
    if element != None:  # 判断element是否有子元素   
        if len(element.getchildren()) == 0:
            node += str(element.tag)
            pass 
        elif (element.text is None) or element.text.isspace():  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
        # else:
        #     element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * (level + 1)
        else:  # 此处两行如果把注释去掉，Element的text也会另起一行
            element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * level

    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def foreach_xml(element, node, node_list):
    if element != None:
        # 有子元素无属性
        if len(element.getchildren()) and len(element.attrib) == 0:
            if str(element.tag) != ROOT_TAG_NAME:
                node += element.tag + '.'
        # 有属性
        elif len(element.attrib) != 0:
            node += element.tag + '.' + element.attrib['instance_id']
            #无子元素说明结束
            if len(element.getchildren()) == 0:
                node_list.append({'path': node, 'value': None, 'valid': True})
                pass
            else:
                node += '.'
        #无子元素
        else:
            node += element.tag
            node_list.append({'path': node, 'value': element.text, 'valid': True})
            node = ""
            pass
    # 将element转成list
    temp = list(element)
    for subelement in temp:
        # 对子元素进行递归操作
        foreach_xml(subelement, node, node_list)

def gen_xpath(node_list, inst_list):
    i = 0
    path = ""
    for node in node_list:
        if node.isdigit():
            path += '[@instance_id="%s"]/' % inst_list[i]
            i += 1
        else:
            path += node + "/"
    return path.strip("/")


def build_new_xml(root_ele, i, new_list, inst_list, value):
    if i >= len(new_list):
        return

    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if root_ele.find(new_xp) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
        i += 2
        build_new_xml(root_ele, i, new_list, inst_list, value)
        inst_list.pop()
        i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            if len(new_list[:i]):
                ET.SubElement(cu_ele, new_list[i])
            else:
                ET.SubElement(root_ele, new_list[i])
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = value
        i += 1
        build_new_xml(root_ele, i, new_list, inst_list, value)
        i -= 1


def build_new_xml_with_xpath_dict(root_ele, i, new_list, inst_list, value, xpath_dict):
    if i >= len(new_list):
        return

    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if xpath_dict.has_key(new_xp) is False:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
            xpath_dict.update({new_xp:True})
        i += 2
        build_new_xml_with_xpath_dict(root_ele, i, new_list, inst_list, value, xpath_dict)
        inst_list.pop()
        i -= 2
    else:
        new_xp = gen_xpath(new_list[:i + 1], inst_list)
        if xpath_dict.has_key(new_xp) is False:
            if len(new_list[:i]):
                cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
                ET.SubElement(cu_ele, new_list[i])
                xpath_dict.update({new_xp:True})
            else:
                ET.SubElement(root_ele, new_list[i])
                xpath_dict.update({new_xp:True})
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = value
        i += 1
        build_new_xml_with_xpath_dict(root_ele, i, new_list, inst_list, value, xpath_dict)
        i -= 1


def build_new_xml_with_xpath_node_dict(root_ele, i, new_list, inst_list, value, xpath_dict):
    if i >= len(new_list):
        return

    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if xpath_dict.has_key(new_xp) is False:
            pre_xp = gen_xpath(new_list[:i], inst_list)
            if xpath_dict.has_key(pre_xp):
                cu_ele = xpath_dict[pre_xp]
                xml_node = ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
                xpath_dict.update({new_xp:xml_node})
        i += 2
        build_new_xml_with_xpath_node_dict(root_ele, i, new_list, inst_list, value, xpath_dict)
        inst_list.pop()
        i -= 2
    else:
        new_xp = gen_xpath(new_list[:i + 1], inst_list)
        if xpath_dict.has_key(new_xp) is False:
            if len(new_list[:i]):
                pre_xp = gen_xpath(new_list[:i], inst_list)
                if xpath_dict.has_key(pre_xp):
                    cu_ele = xpath_dict[pre_xp]
                    xml_node = ET.SubElement(cu_ele, new_list[i])
                    xpath_dict.update({new_xp:xml_node})
            else:
                xml_node = ET.SubElement(root_ele, new_list[i])
                xpath_dict.update({new_xp:xml_node})
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            if xpath_dict.has_key(new_xp) is True:
                cu_ele = xpath_dict[new_xp]
                cu_ele.text = value
            else:
                cu_ele = root_ele.find(new_xp)
                cu_ele.text = value
        i += 1
        build_new_xml_with_xpath_node_dict(root_ele, i, new_list, inst_list, value, xpath_dict)
        i -= 1


def recur_mkele(root_ele, old_list, i, new_list, inst_list):
    if i >= len(new_list):
        return
    if i + 1 != len(new_list) and new_list[i + 1] == "{i}":
        old_xp = gen_xpath(old_list[:i + 1], inst_list)

        for ele in root_ele.findall(old_xp):
            inst_list.append(ele.attrib["instance_id"])
            new_xp = gen_xpath(new_list[:i + 2], inst_list)
            if root_ele.find(new_xp) == None:
                cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
                ET.SubElement(cu_ele, new_list[i], {"instance_id":ele.attrib["instance_id"]})
            i += 2
            recur_mkele(root_ele, old_list, i, new_list, inst_list)
            inst_list.pop()
            i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i])
        if i + 1 == len(new_list):
            old_xp = gen_xpath(old_list[:i + 1], inst_list)
            leaf_val = root_ele.find(old_xp).text

            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = leaf_val
        i += 1
        recur_mkele(root_ele, old_list, i, new_list, inst_list)
        i -= 1

LOG_PATH = "/run_isolate/local_log/cu"
#测试log路径
#LOG_PATH = "./log"

NODE_NOT_MATCH = 0
NODE_CHANGE = 1
NODE_NOT_CHANGE = 2
NODE_DISCARD = 3

IPV4 = 4
IPV6 = 6

MAX_UINT_VALUE = 4294967295

# DU实例号列表
g_du_inst_list = list()

# CU运营商信息列表
g_gnbcu_op_info_list = list()

# DU运营商信息字典
g_gnbdu_op_info_dict = dict()

# 小区绑定的运营商信息列表
g_nrcell_op_info_list = list()

g_ipv4_info_list = list()

g_ipv6_info_list = list()

g_config_need_change = False

g_cudu_cell_map_list = list()

g_cell_merge_dict = dict()

g_cu_cell_merge_inst_list = list()

g_conflict_cu_cell_inst = list()

g_cu_cell_list = list()

g_du_cell_list = list()

g_gnbcu_primary_operator = {"GnbId":None, "GnbIdLen":None}

g_du_frm_info_list = list()

g_du_slot_state = [False, False, False, False, False, False]


def write_log_file(str):
    if not os.path.exists(LOG_PATH):
        os.system("mkdir -p {0}".format(LOG_PATH))
    file = open("{0}/Cellconfig_trans_NR.py.log".format(LOG_PATH), 'a')
    file.write("{0} : {1}\n".format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), str))
    file.close()


def get_all_du_slot_state():
    for slot_id in range(1, len(g_du_slot_state) + 1):
        file_name = "/sys/localbus/du/slot{0}/state".format(slot_id)
        if os.access(file_name, os.F_OK):
            file = open(file_name, 'r')
            state = file.read()
            file.close()
            if "1" in state:
                g_du_slot_state[slot_id - 1] = True
            #print(g_du_slot_state)


def is_du_exist(slot_id):
    if slot_id < 1:
        return False
    return g_du_slot_state[slot_id - 1]


# 若配置匹配后还需要对/sys/localbus/du/slot*/state文件内容进行读取，为1则表示DU存在该槽位，则可以认定小区80在该slot上，否则继续遍历配置
# 若存在frm配置而无DU在槽位上，则slotid取最后一个遍历到配置
# 若不存在frm配置，则slotid默认为1
def get_du_slot_id_by_cellid(cellid):
    # 小区所在DU的槽号默认为1
    slot_id = 1
    for du_frm_info in g_du_frm_info_list:
        if cellid in du_frm_info["cellid_list"]:
            slot_id = du_frm_info["DuFrm"]
            if is_du_exist(slot_id):
                # print(slot_id)
                return du_frm_info["DuFrm"]
    # print(slot_id)
    return slot_id

def get_cu_op_cfg_with_opid(opid):
    value = None
    if g_gnbcu_op_info_list:
        for cu_op_info in g_gnbcu_op_info_list:
            if cu_op_info["op_inst"] == (opid + 1):
                return cu_op_info
    return value


def get_du_op_cfg_with_slot_and_opid(slot, opid):
    value = None
    if g_gnbdu_op_info_dict.has_key(slot):
        for du_op_info in g_gnbdu_op_info_dict[slot]:
            if du_op_info["op_inst"] == (opid + 1):
                return du_op_info
    return value


#Device.X_WWW-RUIJIE-COM-CN.NR.Logic.{i}.OperatorType
#Device.X_WWW-RUIJIE-COM-CN.NR.Logic.{i}.PlmnId
#Device.X_WWW-RUIJIE-COM-CN.NR.Logic.{i}.GnbId
#Device.X_WWW-RUIJIE-COM-CN.NR.Logic.{i}.GnbIdLen
#Device.X_WWW-RUIJIE-COM-CN.NR.Logic.{i}.GnbType
def update_gnbcu_op_info_list(logic_inst, key, value):
    if key in ["OperatorType", "PlmnId", "GnbId", "GnbIdLen"]:
        op_exist = False
        if g_gnbcu_op_info_list:
            for gnbcu_op_info in g_gnbcu_op_info_list:
                if gnbcu_op_info["op_inst"] == logic_inst:
                    op_exist = True
                    gnbcu_op_info[key] = value
        if op_exist is False:
            new_op_info = {"op_inst":logic_inst, "OperatorType":None, "PlmnId":None, "GnbId":None, "GnbIdLen":None}
            new_op_info[key] = value
            g_gnbcu_op_info_list.append(new_op_info)

def tran_cu_cell_inst(cu_cell_inst):
    if cu_cell_inst >= 5 and cu_cell_inst <= 8:
        return (cu_cell_inst + 12)
    return cu_cell_inst

#Device.Services.FAPService.{i}.CUCellConfig.{i}.OperatorBinding
#Device.Services.FAPService.{i}.CUCellConfig.{i}.CellId
def update_cu_cell_list(cu_cell_inst, key, value):
    new_cu_cell_inst = tran_cu_cell_inst(cu_cell_inst)
    if key in ["CellId", "OperatorBinding"]:
        cell_exist = False
        if g_cu_cell_list:
            for cu_cell_info in g_cu_cell_list:
                if cu_cell_info["cu_cell_inst"] == new_cu_cell_inst:
                    cell_exist = True
                    cu_cell_info[key] = value
        if cell_exist is False:
            new_cu_cell_info = {"cu_cell_inst":new_cu_cell_inst, "OperatorBinding":None, "CellId":None, "NCI":list()}
            new_cu_cell_info[key] = value
            g_cu_cell_list.append(new_cu_cell_info)


#Device.X_WWW-RUIJIE-COM-CN.GnbMgr.{i}.DuOperator.{i}.DuPlmnlist
#Device.X_WWW-RUIJIE-COM-CN.GnbMgr.{i}.DuOperator.{i}.GnbId
def update_gnbdu_op_dict(slot, op_inst, key ,value):
    if key in ["DuPlmnlist", "GnbId"]:
        if g_gnbdu_op_info_dict.has_key(slot):
            op_exist = False
            du_op_list = g_gnbdu_op_info_dict[slot]
            for du_op_info in du_op_list:
                if du_op_info["op_inst"] == op_inst:
                    op_exist = True
                    du_op_info[key] = value
            if op_exist is False:
                new_du_op_info = {"op_inst":op_inst, "DuPlmnlist":None, "GnbId":None}
                new_du_op_info[key] = value
                du_op_list.append(new_du_op_info)
        else:
            new_du_op_list = list()
            new_du_op_info = {"op_inst":op_inst, "DuPlmnlist":None, "GnbId":None}
            new_du_op_info[key] = value
            new_du_op_list.append(new_du_op_info)
            g_gnbdu_op_info_dict.update({slot:new_du_op_list})


#Device.Services.FAPService.{i}.CellConfig.{i}
#Device.Services.FAPService.{i}.CellConfig.{i}.NR.CN.TA.{i}.NrcellIdentity(CMCC)
#Device.Services.FAPService.{i}.CellConfig.{i}.NR.NGC.TA.{i}.NrcellIdentity(CUCC)
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.NGC.TA.{i}.BindGnbOpid
def update_du_cell_ta_list(ta_inst, ta_list, key, value):
    if key in ["NrcellIdentity", "BindGnbOpid"]:
        ta_exist = False
        if ta_list:
            for du_nci_info in ta_list:
                if du_nci_info["ta_inst"] == ta_inst:
                    ta_exist = True
                    du_nci_info[key] = value
        if ta_exist is False:
            new_du_nci_info = {"ta_inst":ta_inst, "NrcellIdentity":None, "BindGnbOpid":None, "plmnid":None}
            new_du_nci_info[key] = value
            ta_list.append(new_du_nci_info)


def update_du_cell_list(du_cell_inst, ta_inst, key, value):
    if key in ["NrcellIdentity", "BindGnbOpid"]:
        cell_exist = False
        if g_du_cell_list:
            for du_cell_info in g_du_cell_list:
                if du_cell_info["du_cell_inst"] == du_cell_inst:
                    cell_exist = True
                    update_du_cell_ta_list(ta_inst, du_cell_info["NCI"], key, value)
        if cell_exist is False:
            new_du_cell_info = {"du_cell_inst":du_cell_inst, "NCI":list()}
            update_du_cell_ta_list(ta_inst, new_du_cell_info["NCI"], key, value)
            g_du_cell_list.append(new_du_cell_info)


#判断CU实例号是否多余
def is_cu_inst_superfluous(cu_inst):
    if len(g_cudu_cell_map_list) > 0:
        for cudu_map_info in g_cudu_cell_map_list:
            if cudu_map_info["cu_inst"] == cu_inst:
                return False
    else:
        return False

    return True


#判断CU多余小区是否会与转换后的冲突
def is_inst_conflict_with_need_tran_list(cu_inst):
    if len(g_cudu_cell_map_list) > 0:
        for cudu_map_info in g_cudu_cell_map_list:
            if (cudu_map_info["du_inst"] == cu_inst) and cudu_map_info["need_tran"] is True:
                return True
    else:
        return False

    return False


#获取多余的CU小区
def get_surplus_cu_cell_list(node_list):
    for node_dict in node_list:
        if ".CUCellConfig." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            cu_inst = tran_cu_cell_inst(int(split_list[5]))
            if is_cu_inst_superfluous(cu_inst) is True and is_inst_conflict_with_need_tran_list(cu_inst) is True:
                if cu_inst not in g_conflict_cu_cell_inst:
                    g_conflict_cu_cell_inst.append(cu_inst)


def get_base_info_from_node_list(node_list):
    #遍历节点，读取CU运营商信息，CU小区信息，DU小区信息
    for node_dict in node_list:
        if "Device.X_WWW-RUIJIE-COM-CN.NR.Logic." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            logic_inst = int(split_list[4])
            if split_list[5] in ["OperatorType", "PlmnId", "GnbId", "GnbIdLen"]:
                update_gnbcu_op_info_list(logic_inst, split_list[5], node_dict['value'])
        elif ".CUCellConfig." in node_dict['path']:
            split_list = node_dict['path'].split(".")
            cu_cell_inst = int(split_list[5])
            if cu_cell_inst <= 12 and split_list[6] in ["CellId", "OperatorBinding"]:
                update_cu_cell_list(cu_cell_inst, split_list[6], node_dict['value'])
        elif "Device.Services.FAPService." in node_dict['path'] and ".CellConfig." in node_dict['path'] and "InternetGateway" not in node_dict['path']:
            split_list = node_dict['path'].split(".")
            du_cell_inst = int(split_list[5])
            ta_inst = int(0)
            if ".NR.CN.TA." in node_dict['path'] and ".NrcellIdentity" in node_dict['path']:
                ta_inst = int(split_list[9])
                update_du_cell_list(du_cell_inst, ta_inst, "NrcellIdentity", node_dict['value'])
            elif ".NR.NGC.TA." in node_dict['path'] and ".NrcellIdentity" in node_dict['path']:
                ta_inst = int(split_list[9])
                update_du_cell_list(du_cell_inst, ta_inst, "NrcellIdentity", node_dict['value'])
        elif "Device.X_WWW-RUIJIE-COM-CN." in node_dict['path']:
            if  ".CellConfig." in node_dict['path'] and ".NR.NGC.TA." in node_dict['path'] and ".BindGnbOpid" in node_dict['path']:
                split_list = node_dict['path'].split(".")
                du_cell_inst = int(split_list[6])
                ta_inst = int(split_list[10])
                update_du_cell_list(du_cell_inst, ta_inst, "BindGnbOpid", node_dict['value'])
            elif ".GnbMgr." in node_dict['path'] and ".DuOperator." in node_dict['path']:
                if ".DuPlmnlist" in node_dict['path'] or ".GnbId" in node_dict['path']:
                    split_list = node_dict['path'].split(".")
                    slot_id = int(split_list[3])
                    op_id = int(split_list[5])
                    update_gnbdu_op_dict(slot_id, op_id, split_list[6] ,node_dict['value'])
    get_all_du_slot_state()
    #更新DU的plmn列表
    update_du_cell_plmn_list()
    #更新CU的NCI列表
    get_cu_cell_nci_list()
    #获取CU/DU小区映射列表
    get_cudu_cell_map_list()


#根据gnbid,gnbidlen,cellid计算NCI
def calc_cu_nrcellid(cellid, cu_op_cfg):
    value = None
    if cu_op_cfg is not None:
        value = (int(cu_op_cfg["GnbId"]) << (36 - int(cu_op_cfg["GnbIdLen"]))) | cellid
    return value


#更新DU小区的PLMN列表
def update_du_cell_plmn_list():
    if g_du_cell_list:
        for du_cell_info in g_du_cell_list:
            slot_id = (du_cell_info["du_cell_inst"] - 1)/4 + 1
            for du_nci_info in du_cell_info["NCI"]:
                du_op_info = get_du_op_cfg_with_slot_and_opid(slot_id, int(du_nci_info["BindGnbOpid"]))
                if du_op_info is not None:
                    du_nci_info["plmnid"] = du_op_info["DuPlmnlist"]


#填充CU小区的NCI列表
def get_cu_cell_nci_list():
    if g_cu_cell_list:
        for cu_cell_info in g_cu_cell_list:
            cellid_list = cu_cell_info["CellId"].split(",")
            for i in range(0, 6):
                if (int(cu_cell_info["OperatorBinding"]) & (int(1) << i)) !=0 :
                    cu_op_info = get_cu_op_cfg_with_opid(i)
                    nrcellid = calc_cu_nrcellid(int(cellid_list[i]), cu_op_info)
                    cu_nci_info = {"op_id":i, "NrcellIdentity":nrcellid, "plmnid":cu_op_info["PlmnId"]}
                    cu_cell_info["NCI"].append(cu_nci_info)
                    #print("inst {0}, op {1}, nrcellid {2}".format(cu_cell_info["cu_cell_inst"], i, nrcellid))


#判断nci是否在DU小区内
def is_nci_in_du_cell_list(nci, plmnid, du_cell_info):
    if du_cell_info is not None:
        for du_nci in du_cell_info["NCI"]:
            if du_nci["plmnid"] is not None:
                if nci == int(du_nci["NrcellIdentity"]) and plmnid == int(du_nci["plmnid"]):
                    return True
            else:
                if nci == int(du_nci["NrcellIdentity"]) :
                    return True
    return False

#根据NCI判断CU小区和DU小区是否匹配
def does_cu_match_du(cu_cell_info, du_cell_info):
    if cu_cell_info is not None and du_cell_info is not None:
        match_num = 0
        for cu_nci in cu_cell_info["NCI"]:
            if is_nci_in_du_cell_list(int(cu_nci["NrcellIdentity"]), int(cu_nci["plmnid"]), du_cell_info) is True:
                match_num += 1
        if len(cu_cell_info["NCI"]) <= len(du_cell_info["NCI"]) and match_num == len(cu_cell_info["NCI"]) :
            return True
        elif len(cu_cell_info["NCI"]) > len(du_cell_info["NCI"]) and match_num == len(du_cell_info["NCI"]) :
            return True
        else:
            return False
    else:
        return False

#判断小区映射是否一对一
def is_one_for_one():
    tmp_cu_inst_list = []
    tmp_du_inst_list = []
    if len(g_cudu_cell_map_list) > 0:
        for cudu_map_info in g_cudu_cell_map_list:
            if cudu_map_info["cu_inst"] not in tmp_cu_inst_list:
                tmp_cu_inst_list.append(cudu_map_info["cu_inst"])
            if cudu_map_info["du_inst"] not in tmp_du_inst_list:
                tmp_du_inst_list.append(cudu_map_info["du_inst"])
        write_log_file("tmp_cu_inst_list : " + str(tmp_cu_inst_list) + "\n")
        write_log_file("tmp_du_inst_list : " + str(tmp_du_inst_list) + "\n")

        if len(tmp_cu_inst_list) == len(tmp_du_inst_list):
            return True

    return False

#获取CU/DU小区的映射表
def get_cudu_cell_map_list():
    for cu_cell_info in g_cu_cell_list:
        for du_cell_info in g_du_cell_list:
            slot_id = (du_cell_info["du_cell_inst"] - 1)/4 + 1
            if is_du_exist(slot_id) is True and does_cu_match_du(cu_cell_info, du_cell_info) is True :
                if cu_cell_info["cu_cell_inst"] == du_cell_info["du_cell_inst"]:
                    cudu_map_info = {"cu_inst":cu_cell_info["cu_cell_inst"], "du_inst":du_cell_info["du_cell_inst"], "need_tran":False}
                elif du_cell_info["du_cell_inst"] >= 17 and du_cell_info["du_cell_inst"] <= 20 and (cu_cell_info["cu_cell_inst"] == du_cell_info["du_cell_inst"] - 12):
                    cudu_map_info = {"cu_inst":cu_cell_info["cu_cell_inst"], "du_inst":du_cell_info["du_cell_inst"], "need_tran":False}
                else:
                    cudu_map_info = {"cu_inst":cu_cell_info["cu_cell_inst"], "du_inst":du_cell_info["du_cell_inst"], "need_tran":True}
                    cell_merge_info = {str(cu_cell_info["cu_cell_inst"]):du_cell_info["du_cell_inst"]}
                    g_cu_cell_merge_inst_list.append(cu_cell_info["cu_cell_inst"])
                    g_cell_merge_dict.update(cell_merge_info)
                g_cudu_cell_map_list.append(cudu_map_info)
    write_log_file("g_cu_cell_merge_inst_list : " + str(g_cu_cell_merge_inst_list) + "\n")
    #g_cudu_cell_map_list.sort(key = lambda a:a["du_inst"], reverse=True)
    if (len(g_cu_cell_merge_inst_list) > 0) and is_one_for_one() is True:
        global g_config_need_change
        g_config_need_change = True


#根据目标du实例号获取cu实例号
def get_target_inst_for_conflict_cu_inst(cu_inst):
    if len(g_cudu_cell_map_list) > 0:
        for cudu_map_info in g_cudu_cell_map_list:
            if (cudu_map_info["du_inst"] == cu_inst) and cudu_map_info["need_tran"] is True:
                return cudu_map_info["cu_inst"]

    return -1


#Device.Services.FAPService.{i}.CellConfig.{i}
#Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}
def merge_cu_cell_config(node_dict, new_node_list, public_node_list, private_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig." in node_dict['path']:
        if "Device.Services.FAPService." in node_dict['path'] and "InternetGateway" not in node_dict['path']:
            if any(node_str in node_dict['path'] for node_str in public_node_list) is True:
                split_list = node_dict['path'].split(".")
                if int(split_list[5]) in g_cu_cell_merge_inst_list:
                    write_log_file("old node [{0}]".format(node_dict['path']))
                    split_list[5] = str(-g_cell_merge_dict[split_list[5]])
                    node_dict['path'] = ''
                    for split in split_list[0:-1]:
                        node_dict['path'] += split + '.'
                    node_dict['path'] += split_list[-1]
                    new_node_list.append(node_dict)
                    ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            if any(node_str in node_dict['path'] for node_str in private_node_list) is True:
                split_list = node_dict['path'].split(".")
                if int(split_list[6]) in g_cu_cell_merge_inst_list:
                    write_log_file("old node [{0}]".format(node_dict['path']))
                    split_list[6] = str(-g_cell_merge_dict[split_list[6]])
                    node_dict['path'] = ''
                    for split in split_list[0:-1]:
                        node_dict['path'] += split + '.'
                    node_dict['path'] += split_list[-1]
                    new_node_list.append(node_dict)
                    ret = NODE_CHANGE
    elif ".CUCellConfig." in node_dict['path']:
        split_list = node_dict['path'].split(".")
        cu_cell_config_inst = tran_cu_cell_inst(int(split_list[5]))
        if cu_cell_config_inst in g_cu_cell_merge_inst_list:
            write_log_file("old node [{0}]".format(node_dict['path']))
            split_list[5] = str(-g_cell_merge_dict[str(cu_cell_config_inst)])
            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            ret = NODE_CHANGE
        elif cu_cell_config_inst in g_conflict_cu_cell_inst:
            target_inst = get_target_inst_for_conflict_cu_inst(cu_cell_config_inst)
            if target_inst == -1:
                write_log_file("invalid node [{0}]".format(node_dict['path']))
                node_dict['valid'] = False
            else:
                write_log_file("old node [{0}]".format(node_dict['path']))
                split_list[5] = str(-target_inst)
                node_dict['path'] = ''
                for split in split_list[0:-1]:
                    node_dict['path'] += split + '.'
                node_dict['path'] += split_list[-1]
                new_node_list.append(node_dict)
                ret = NODE_CHANGE

    return ret


def convert_cu_cell_inst_to_positive(node_dict, new_node_list, public_node_list, private_node_list):
    ret = NODE_NOT_MATCH
    if ".CellConfig." in node_dict['path']:
        if "Device.Services.FAPService." in node_dict['path'] and "InternetGateway" not in node_dict['path']:
            if any(node_str in node_dict['path'] for node_str in public_node_list) is True:
                split_list = node_dict['path'].split(".")
                if int(split_list[5]) < 0:
                    split_list[5] = str(-int(split_list[5]))
                    node_dict['path'] = ''
                    for split in split_list[0:-1]:
                        node_dict['path'] += split + '.'
                    node_dict['path'] += split_list[-1]
                    new_node_list.append(node_dict)
                    write_log_file("new node [{0}]".format(node_dict['path']))
                    ret = NODE_CHANGE
        elif "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService." in node_dict['path']:
            if any(node_str in node_dict['path'] for node_str in private_node_list) is True:
                split_list = node_dict['path'].split(".")
                if int(split_list[6]) < 0:
                    split_list[6] = str(-int(split_list[6]))
                    node_dict['path'] = ''
                    for split in split_list[0:-1]:
                        node_dict['path'] += split + '.'
                    node_dict['path'] += split_list[-1]
                    new_node_list.append(node_dict)
                    write_log_file("new node [{0}]".format(node_dict['path']))
                    ret = NODE_CHANGE
    elif ".CUCellConfig." in node_dict['path']:
        split_list = node_dict['path'].split(".")
        if int(split_list[5]) < 0:
            if (-int(split_list[5])) >= 17 and (-int(split_list[5])) <= 20:
                split_list[5] = str(-int(split_list[5]) - 12)
            else:
                split_list[5] = str(-int(split_list[5]))

            node_dict['path'] = ''
            for split in split_list[0:-1]:
                node_dict['path'] += split + '.'
            node_dict['path'] += split_list[-1]
            new_node_list.append(node_dict)
            write_log_file("new node [{0}]".format(node_dict['path']))
            ret = NODE_CHANGE

    return ret


if __name__ == "__main__":
    
    if len(sys.argv) != 3:
        print("arg num invalid")
        for arg in sys.argv:
            print(arg)
        exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    if not os.access(input_file, os.F_OK):
        print(input_file, "not exist!")
        exit(1)

    # 假设新旧节点的层级相同，仅节点名不同
    xml_tree = ET.ElementTree(file = input_file)
    root_ele = xml_tree.getroot()

    node = str()
    node_list = list()
    foreach_xml(root_ele, node, node_list)
    new_root = ET.Element(ROOT_TAG_NAME)
    get_base_info_from_node_list(node_list)
    write_log_file("g_gnbcu_op_info_list : " + str(g_gnbcu_op_info_list) + "\n")
    write_log_file("g_gnbdu_op_info_dict : " + str(g_gnbdu_op_info_dict) + "\n")
    write_log_file("g_cu_cell_list : " + str(g_cu_cell_list) + "\n")
    write_log_file("g_du_cell_list : " + str(g_du_cell_list) + "\n")
    write_log_file("g_du_slot_state : " + str(g_du_slot_state) + "\n")
    write_log_file("g_cudu_cell_map_list : " + str(g_cudu_cell_map_list) + "\n")
    write_log_file("g_cell_merge_dict : " + str(g_cell_merge_dict) + "\n")
    #print(g_config_need_change) 
    public_node_list = [".NR.RAN.RadioBearParam.", ".NR.RAN.PDCP.", ".NR.RAN.SysInfoCtrlParam.IdleModeRATMobile.", 
                        ".NR.VoNR.", ".NR.RAN.Mobility.", ".NR.Capabilities.MaxUEsServed", ".NR.RAN.RRCTimers.",
                        ".NR.Capabilities.UeInactiveTimer", ".NR.RAN.Mobility.ConnMode.NR.MeasureCtrl.Smeasure"]

    private_node_list = [".NR.QoS.", ".NR.RAN.RACRBC.", ".NR.RAN.NS.", ".NR.RAN.Mobility.", ".NR.RAN.OpConfig.", ".NR.RAN.LB.", 
                         ".NR.Capabilities.", ".NR.RAN.CuCellAlgoswitch.", ".NR.RAN.RAC."]

    write_log_file("start" + "\n")
    if g_config_need_change is True:
        write_log_file("merge_cu_cell_config" + "\n")
        #获取多余的CU小区
        get_surplus_cu_cell_list(node_list)
        write_log_file("g_conflict_cu_cell_inst : " + str(g_conflict_cu_cell_inst) + "\n")

        temp_node_list = list()
        #配置规整:按映射关系改变实例号.若映射关系为{1:9}则将1改为-9.
        for node_dict in node_list:
            if merge_cu_cell_config(node_dict, temp_node_list, public_node_list, private_node_list) is NODE_NOT_MATCH:
                temp_node_list.append(node_dict)

        write_log_file("convert_cu_cell_inst_to_positive" + "\n")
        #将负的实例号转为正数
        new_node_list = list()
        for node_dict in temp_node_list:
            if convert_cu_cell_inst_to_positive(node_dict, new_node_list, public_node_list, private_node_list) is NODE_NOT_MATCH:
                new_node_list.append(node_dict)

        write_log_file("build_new_xml" + "\n")
        #new_node_list.sort()
        xpath_dict = {}
        for node_dict in new_node_list:
            if node_dict['valid'] is True:
                new_list = node_dict['path'].strip().strip(".").split(".")
                #print(node_dict['path'], node_dict['value'])
        
                i = 0
                inst_list = []
                #build_new_xml(new_root, i, new_list, inst_list, node_dict['value'])
                #build_new_xml_with_xpath_dict(new_root, i, new_list, inst_list, node_dict['value'], xpath_dict)
                build_new_xml_with_xpath_node_dict(new_root, i, new_list, inst_list, node_dict['value'], xpath_dict)
            else:
                write_log_file("exclude node [{0}]".format(node_dict['path']))
        
        write_log_file("pretty_xml" + "\n")
        pretty_xml(new_root)
        ele_tree = ET.ElementTree(new_root)
        ele_tree.write(output_file, encoding="utf-8", xml_declaration=True)
    write_log_file("end" + "\n")