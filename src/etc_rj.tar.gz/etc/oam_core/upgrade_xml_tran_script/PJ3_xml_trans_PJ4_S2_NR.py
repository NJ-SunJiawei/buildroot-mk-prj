#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import sys
import os
import time
import re

ROOT_TAG_NAME = "Config"

LOG_PATH = "/run_isolate/local_log/du"

NODE_NOT_MATCH = 0
NODE_CHANGE = 1
NODE_NOT_CHANGE = 2
NODE_DISCARD = 3

def pretty_xml(element, indent="  ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    node=" "
    if element != None:  # 判断element是否有子元素   
        if len(element.getchildren()) == 0:
            node += str(element.tag)
            pass 
        elif (element.text is None) or element.text.isspace():  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
        # else:
        #     element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * (level + 1)
        else:  # 此处两行如果把注释去掉，Element的text也会另起一行
            element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * level

    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def foreach_xml(element, node, node_list):
    if element != None:
        # 有子元素无属性
        if len(element.getchildren()) and len(element.attrib) == 0:
            if str(element.tag) != ROOT_TAG_NAME:
                node += element.tag + '.'
        # 有属性
        elif len(element.attrib) != 0:
            node += element.tag + '.' + element.attrib['instance_id']
            #无子元素说明结束
            if len(element.getchildren()) == 0:
                node_list.append({'path': node, 'value': None})
                pass
            else:
                node += '.'
        #无子元素
        else:
            node += element.tag
            node_list.append({'path': node, 'value': element.text})
            node = ""
            pass
    # 将element转成list
    temp = list(element)
    for subelement in temp:
        # 对子元素进行递归操作
        foreach_xml(subelement, node, node_list)

def gen_xpath(node_list, inst_list):
    i = 0
    path = ""
    for node in node_list:
        if node.isdigit():
            path += '[@instance_id="%s"]/' % inst_list[i]
            i += 1
        else:
            path += node + "/"
    return path.strip("/")

def build_new_xml(root_ele, i, new_list, inst_list, value):
    if i >= len(new_list):
        return

    if i + 1 != len(new_list) and new_list[i + 1].isdigit():
        inst_list.append(new_list[i + 1])
        new_xp = gen_xpath(new_list[:i + 2], inst_list)
        if root_ele.find(new_xp) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i], {"instance_id":new_list[i + 1]})
        i += 2
        build_new_xml(root_ele, i, new_list, inst_list, value)
        inst_list.pop()
        i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            if len(new_list[:i]):
                ET.SubElement(cu_ele, new_list[i])
            else:
                ET.SubElement(root_ele, new_list[i])
        if i + 1 == len(new_list):
            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = value
        i += 1
        build_new_xml(root_ele, i, new_list, inst_list, value)
        i -= 1

def recur_mkele(root_ele, old_list, i, new_list, inst_list):
    if i >= len(new_list):
        return
    if i + 1 != len(new_list) and new_list[i + 1] == "{i}":
        old_xp = gen_xpath(old_list[:i + 1], inst_list)

        for ele in root_ele.findall(old_xp):
            inst_list.append(ele.attrib["instance_id"])
            new_xp = gen_xpath(new_list[:i + 2], inst_list)
            if root_ele.find(new_xp) == None:
                cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
                ET.SubElement(cu_ele, new_list[i], {"instance_id":ele.attrib["instance_id"]})
            i += 2
            recur_mkele(root_ele, old_list, i, new_list, inst_list)
            inst_list.pop()
            i -= 2
    else:
        if root_ele.find(gen_xpath(new_list[:i + 1], inst_list)) == None:
            cu_ele = root_ele.find(gen_xpath(new_list[:i], inst_list))
            ET.SubElement(cu_ele, new_list[i])
        if i + 1 == len(new_list):
            old_xp = gen_xpath(old_list[:i + 1], inst_list)
            leaf_val = root_ele.find(old_xp).text

            new_xp = gen_xpath(new_list[:i + 1], inst_list)
            cu_ele = root_ele.find(new_xp)
            cu_ele.text = leaf_val
        i += 1
        recur_mkele(root_ele, old_list, i, new_list, inst_list)
        i -= 1

def write_log_file(str):
    if not os.path.exists(LOG_PATH):
        os.system("mkdir -p {0}".format(LOG_PATH))
    file = open("{0}/PJ3_xml_trans_PJ4_S2_NR.log".format(LOG_PATH), 'a')
    file.write("{0} : {1}\n".format(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), str))
    file.close()
    
#这个函数每个节点进来一次
#<NetworkSliceRes instance_id="1">  -> OperatorResInfo  
#<NsResResourceId>1</NsResResourceId>  -> OpResourceId
#<ResUsgObject>1</ResUsgObject>  ->无论什么值，都映射为1
#  <DlRbMaxRatio>100</DlRbMaxRatio>  -> DlRbAvgRatio 同时DlRbMaxRatio改为100
#  <DlRbMinRatio>0</DlRbMinRatio>  不变
#  <UlRbMaxRatio>100</UlRbMaxRatio>  -> UlRbAvgRatio 同时UlRbMaxRatio改为100
#  <UlRbMinRatio>0</UlRbMinRatio>  不变
#</NetworkSliceRes>
#DlRbStartPos/UlRbStartPos 设置为0
#before: Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.{i}.NetworkSlicePara.NetworkSliceRes.{i}.
#current:Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.{i}.OperatorResPara.OperatorResInfo.{i}.
#Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.1.NetworkSlicePara.NetworkSliceRes.1.NsResResourceId
#Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.1.NetworkSlicePara.NetworkSliceRes.1.ResUsgObject
#Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.1.NetworkSlicePara.NetworkSliceRes.1.DlRbMaxRatio
#Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.1.NetworkSlicePara.NetworkSliceRes.1.DlRbMinRatio
#Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.1.NetworkSlicePara.NetworkSliceRes.1.UlRbMaxRatio
#Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.1.NetworkSlicePara.NetworkSliceRes.1.UlRbMinRatio

g_rb_start_pos_flag = 0
#DlRbStartPos/UlRbStartPos 设置为0
def PJ4_S2_trans_rb_start_ratio(node_dict, new_node_list):
    global g_rb_start_pos_flag  # 使用global关键字声明全局变量
    
    if g_rb_start_pos_flag == 1:
        return
    
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceRes.[0-9]+.", node_dict['path']):
        new_path = node_dict['path'].replace("NsResResourceId", "OpResourceId", 1).replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo")
        node_name = node_dict['path'].split(".")[-1]
        # 新增节点 DlRbStartPos，赋值为0
        dl_rb_start_pos_path = node_dict['path'].replace(node_name, "DlRbStartPos", 1).replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo")
        new_node = {'path': dl_rb_start_pos_path, 'value': "0"}
        new_node_list.append(new_node)
        # 新增节点 UlRbStartPos，赋值为0
        ul_rb_start_pos_path = node_dict['path'].replace(node_name, "UlRbStartPos", 1).replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo")
        new_node = {'path': ul_rb_start_pos_path, 'value': "0"}
        new_node_list.append(new_node)
        g_rb_start_pos_flag = 1

def PJ4_S2_trans_Slice(node_dict, new_node_list, slice_grp_resid_node_list, slice_res_resid_node_list):
    ret = NODE_NOT_MATCH

    #<NsResResourceId>1</NsResResourceId>  -> OpResourceId
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceRes.[0-9]+.NsResResourceId", node_dict['path']):
        new_path = node_dict['path'].replace("NsResResourceId", "OpResourceId", 1).replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo")
        new_node = {'path': new_path, 'value': node_dict['value']}
        new_node_list.append(new_node)
        slice_res_resid_node_list.append(node_dict)
        ret = NODE_CHANGE
        PJ4_S2_trans_rb_start_ratio(node_dict, new_node_list)
        return ret
    #<ResUsgObject>1</ResUsgObject>  ->无论什么值，都映射为1
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceRes.[0-9]+.ResUsgObject", node_dict['path']):
        new_path = node_dict['path'].replace("NsResResourceId", "OpResourceId", 1).replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo")
        new_node = {'path': new_path, 'value': "1"}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
        PJ4_S2_trans_rb_start_ratio(node_dict, new_node_list)
        return ret
    # <DlRbMaxRatio>100</DlRbMaxRatio>  -> DlRbAvgRatio 同时DlRbMaxRatio改为100
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceRes.[0-9]+.DlRbMaxRatio", node_dict['path']):
        # 获取原始节点的值
        original_value = node_dict['value']

        # DlRbMaxRatio
        new_path = node_dict['path'].replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo", 1)
        new_node = {'path': new_path, 'value': "100"} 
        new_node_list.append(new_node)
        # 新增 DlRbAvgRatio 节点，并使用原始节点的值
        new_avg_ratio_path = node_dict['path'].replace("DlRbMaxRatio", "DlRbAvgRatio", 1).replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo")
        new_avg_ratio_node = {'path': new_avg_ratio_path, 'value': original_value}  # 使用原始节点的值
        new_node_list.append(new_avg_ratio_node)
        ret = NODE_CHANGE
        PJ4_S2_trans_rb_start_ratio(node_dict, new_node_list)
        return ret
    #  <DlRbMinRatio>0</DlRbMinRatio>  不变
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceRes.[0-9]+.DlRbMinRatio", node_dict['path']):
        new_path = node_dict['path'].replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo", 1)
        new_node = {'path': new_path, 'value': node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
        PJ4_S2_trans_rb_start_ratio(node_dict, new_node_list)
        return ret
    # <UlRbMaxRatio>100</UlRbMaxRatio>  -> UlRbAvgRatio 同时 UlRbMaxRatio 改为100
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceRes.[0-9]+.UlRbMaxRatio", node_dict['path']):
        # 获取原始节点的值
        original_value = node_dict['value']

        # UlRbMaxRatio
        new_path = node_dict['path'].replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo", 1)
        new_node = {'path': new_path, 'value': "100"} 
        new_node_list.append(new_node)
        # 新增 UlRbAvgRatio 节点，并使用原始节点的值
        new_avg_ratio_path = node_dict['path'].replace("UlRbMaxRatio", "UlRbAvgRatio", 1).replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo")
        new_avg_ratio_node = {'path': new_avg_ratio_path, 'value': original_value}  # 使用原始节点的值
        new_node_list.append(new_avg_ratio_node)
        ret = NODE_CHANGE
        PJ4_S2_trans_rb_start_ratio(node_dict, new_node_list)
        return ret
    # <UlRbMinRatio>0</UlRbMinRatio>  不变
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceRes.[0-9]+.UlRbMinRatio", node_dict['path']):
        new_path = node_dict['path'].replace("NetworkSlicePara.NetworkSliceRes", "OperatorResPara.OperatorResInfo", 1)
        new_node = {'path': new_path, 'value': node_dict['value']}
        new_node_list.append(new_node)
        ret = NODE_CHANGE
        PJ4_S2_trans_rb_start_ratio(node_dict, new_node_list)
        return ret
    # 判断是否有 NetworkSliceGrp.{i}.ResourceId后续处理，先返回NODE_DISCARD
    if re.match("Device.X_WWW-RUIJIE-COM-CN.gNBDUParams.MacProvsioningParams.SchedParms.[0-9]+.NetworkSlicePara.NetworkSliceGrp.[0-9]+.ResourceId", node_dict['path']):
        ret = NODE_DISCARD
        slice_grp_resid_node_list.append(node_dict)
        return ret
    return ret

def PJ4_S2_slice_process_node_list(slice_grp_resid_node_list, slice_res_resid_node_list):
    # 取出slice_res_resid_node_list中的'value'值构建set
    if len(slice_res_resid_node_list) == 0:
        print('slice_res_resid_node_list is null')
    else:
        slice_resid_set = set(node['value'] for node in slice_res_resid_node_list)

        # 判断slice_grp_resid_node_list里的字典value值是否在slice_res_resid_node_list中，如果不在则删除
        slice_grp_resid_node_list[:] = [node for node in slice_grp_resid_node_list if node['value'] in slice_resid_set]

    # 判断slice_grp_resid_node_list中的值是否有重复，如果有重复则清空整个list
    seen_values = set()
    for node in slice_grp_resid_node_list:
        if node['value'] in seen_values:
            slice_grp_resid_node_list[:] = []
            break
        seen_values.add(node['value'])

    return slice_grp_resid_node_list

if __name__ == "__main__":
    
    if len(sys.argv) != 3:
        print("arg num invalid")
        for arg in sys.argv:
            print(arg)
        exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    if not os.access(input_file, os.F_OK):
        print(input_file, "not exist!")
        write_log_file("input_file: " + input_file + " is not exist!")
        exit(1)

    # 假设新旧节点的层级相同，仅节点名不同
    #xml_tree = ET.ElementTree(file = input_file)
    xml_tree = ET.parse(input_file, parser=ET.XMLParser(encoding='utf-8'))
    root_ele = xml_tree.getroot()

    node = str()
    node_list = list()
    foreach_xml(root_ele, node, node_list)
    new_root = ET.Element(ROOT_TAG_NAME)

    build_new_xml_flag = 0

    new_node_list = list()
    slice_grp_resid_node_list = list()
    slice_res_resid_node_list = list()
    for node_dict in node_list:
        ret = PJ4_S2_trans_Slice(node_dict, new_node_list, slice_grp_resid_node_list, slice_res_resid_node_list)
        if ret == NODE_NOT_MATCH:
            new_node_list.append(node_dict)
        else:
            build_new_xml_flag = 1
    
    #1.判断 slice_grp_resid_node_list(ResourceId) 当中的字典中的value值是否slice_res_resid_node_list 存在，如果slice_res_resid_node_list 不存在，那么删除这个节点
    #2.判断slice_grp_resid_node_list 是否有重复，如果有重复，全部删除
    new_slice_grp_resid_node_list = PJ4_S2_slice_process_node_list(slice_grp_resid_node_list, slice_res_resid_node_list)
    #将筛选后的node加入new_node_list
    if new_slice_grp_resid_node_list:
        new_node_list.extend(new_slice_grp_resid_node_list)
    
    for node_dict in new_node_list:
        new_list = node_dict['path'].strip().strip(".").split(".")
        i = 0
        inst_list = []
        build_new_xml(new_root, i, new_list, inst_list, node_dict['value'])
    if build_new_xml_flag == 1:
        pretty_xml(new_root)
        ele_tree = ET.ElementTree(new_root)
        ele_tree.write(output_file, encoding="utf-8", xml_declaration=True)
    else:
        print("no change")



