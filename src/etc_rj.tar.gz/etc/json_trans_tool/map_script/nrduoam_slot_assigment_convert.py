#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
4_1_DDDSU :
    5 3 1 0 5 3 1 
8_2_DDDDDDDSUU :
    6 7 2 0 6 7 2
7_3_DDDSUDDSUU :
    5 3 1 1 5 2 2
2_3_DSUUU :
    5 1 3 0 5 1 3
'''

cli_cwmp_dict = {
            '4_1_DDDSU'         :'5 3 1 0',
            '8_2_DDDDDDDSUU'    :'6 7 2 0',
            '7_3_DDDSUDDSUU'    :'5 3 1 1 5 2 2',
            '2_3_DSUUU'         :'5 1 3 0'}
ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    if argv_len <= 9:
        print("argv_len:"+str(argv_len))
        sys.exit(-1)
    pattern1_d1_ui_transmission_periodicity = int(sys.argv[3])
    pattern1_nr_of_downlink_slots           = int(sys.argv[4])
    pattern1_nr_of_uplink_slots             = int(sys.argv[5])
    
    pattern2_enable                         = int(sys.argv[6])
    pattern2_dl_ul_transmission_periodicity = int(sys.argv[7])
    pattern2_nr_of_downlink_slots           = int(sys.argv[8])
    pattern2_nr_of_uplink_slots             = int(sys.argv[9])
    
    if pattern2_enable == 1:
        cwmp_value = '{0} {1} {2} {3} {4} {5} {6}'.format(pattern1_d1_ui_transmission_periodicity,
                                                        pattern1_nr_of_downlink_slots,
                                                        pattern1_nr_of_uplink_slots,
                                                        pattern2_enable,
                                                        pattern2_dl_ul_transmission_periodicity,
                                                        pattern2_nr_of_downlink_slots,
                                                        pattern2_nr_of_uplink_slots)
    else:
        cwmp_value = '{0} {1} {2} {3}'.format(pattern1_d1_ui_transmission_periodicity,
                                                        pattern1_nr_of_downlink_slots,
                                                        pattern1_nr_of_uplink_slots,
                                                        pattern2_enable)
    if cwmp_value not in list(cli_cwmp_dict.values()):
        sys.exit(-1)
    for key, value in cli_cwmp_dict.items():
        if value == cwmp_value:
            print(key)
elif sys.argv[1] == "1":
    slot_assignment = sys.argv[3]
    if slot_assignment not in cli_cwmp_dict:
        sys.exit(-1)
    cwmp_value = cli_cwmp_dict[slot_assignment].split(' ')
    pattern1_d1_ui_transmission_periodicity = cwmp_value[0]
    pattern1_nr_of_downlink_slots           = cwmp_value[1]
    pattern1_nr_of_uplink_slots             = cwmp_value[2]
    
    pattern2_enable                         = int(cwmp_value[3])
    if pattern2_enable == 1:
        pattern2_dl_ul_transmission_periodicity = cwmp_value[4]
        pattern2_nr_of_downlink_slots           = cwmp_value[5]
        pattern2_nr_of_uplink_slots             = cwmp_value[6]
    else:
        pattern2_dl_ul_transmission_periodicity = cwmp_value[0]
        pattern2_nr_of_downlink_slots           = cwmp_value[1]
        pattern2_nr_of_uplink_slots             = cwmp_value[2]
    print(pattern1_d1_ui_transmission_periodicity)
    print(pattern1_nr_of_downlink_slots)
    print(pattern1_nr_of_uplink_slots)
    print(pattern2_enable)
    print(pattern2_dl_ul_transmission_periodicity)
    print(pattern2_nr_of_downlink_slots)
    print(pattern2_nr_of_uplink_slots)
else:
    ret = -1

sys.exit(ret)
