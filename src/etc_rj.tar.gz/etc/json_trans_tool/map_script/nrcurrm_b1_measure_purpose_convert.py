#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
nrcell-b1-measurectl.measure-purpose
nrcell-b1-measurectl.operator-id
'''

b1_dict = {'Inter-rat':11}

ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    inst_id = int(sys.argv[3])
    op_id = (inst_id - b1_dict['Inter-rat'] - 1) % 6
    offset = (inst_id - b1_dict['Inter-rat'] - 1) / 6
    measure_inst = offset + b1_dict['Inter-rat']
    if measure_inst in b1_dict.values():
        for key, value in b1_dict.items():
            if value == measure_inst:
                print(key)
                print(op_id)
    else:
        ret = -1
elif sys.argv[1] == "1":
    if argv_len <= 4:
        sys.exit(-1)
    measure_purpose = sys.argv[3]
    op_id = int(sys.argv[4])
    if measure_purpose in b1_dict:
        offset = b1_dict[measure_purpose] - b1_dict['Inter-rat']
        inst_id = b1_dict['Inter-rat'] + 1 + op_id + offset*6
        print(inst_id)
        print(inst_id)
    else:
        ret = -1
else:
    ret = -1

sys.exit(ret)
