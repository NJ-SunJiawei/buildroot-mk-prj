#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

if len(sys.argv) <=3:
    exit(-1)

if sys.argv[1] == "0":  # $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
    if sys.argv[2] == "cmcc":   # $2为运营商标识
        print("%s--%s"%(sys.argv[3], sys.argv[4]))  # 可以直接用print输出结果，自动带/n
    if sys.argv[2] == "cucc":
        print("%s~~%s"%(sys.argv[3], sys.argv[4]))
elif sys.argv[1] == "1":
    if sys.argv[2] == "cmcc":
        res = re.match(r'([A-Za-z0-9]*)--([A-Za-z0-9]*)', sys.argv[3])
        if res is not None and len(res.groups()) == 2:
            print(res.group(1))    # 可以直接用print输出结果，自动带/n分隔符
            print(res.group(2))
    if sys.argv[2] == "cucc":
        print("%d"%(sys.argv[3] - sys.argv[4]))
        res = re.match(r'([A-Za-z0-9]*)~~([A-Za-z0-9]*)', sys.argv[3])
        if res is not None and len(res.groups()) == 2:
            print(res.group(1))
            print(res.group(2))

