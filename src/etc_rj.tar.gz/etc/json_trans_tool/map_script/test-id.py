#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
print(int(sys.argv[3])*2)ss