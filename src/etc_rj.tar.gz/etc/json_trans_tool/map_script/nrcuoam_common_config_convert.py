#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
"设：节点Device.X_WWW-RUIJIE-COM-CN.StackConfig.CommonConfig值为 CommonConfig
clockcheck = CommonConfig & (1 << 1)"
'''


ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    common_config = int(sys.argv[3])
    ngstate_deacell_switch = common_config & (1 << 0)
    clockcheck = common_config & (1 << 1)
    print(ngstate_deacell_switch)
    print(clockcheck)
elif sys.argv[1] == "1":
    if argv_len <= 4:
        sys.exit(-1)
    ngstate_deacell_switch = int(sys.argv[3])
    clockcheck = int(sys.argv[4])
    common_config = ngstate_deacell_switch | clockcheck
    print(common_config)
else:
    ret = -1

sys.exit(ret)
