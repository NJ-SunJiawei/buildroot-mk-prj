#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

if sys.argv[1] == "0":
    print(1)
    print(2)
else:
    print(3)
    print(4)