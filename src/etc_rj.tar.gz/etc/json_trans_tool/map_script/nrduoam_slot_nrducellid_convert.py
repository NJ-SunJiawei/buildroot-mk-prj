#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
nrducell-id = (CellConfig.{i}-1) % 4
slot =((CellConfig.{i}-1) % 24) /4 +1  取整

CellConfig.{i} =(slot -1)*4+nrducell-id+1
'''


ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    nrducell_inst = int(sys.argv[3])
    slot = int(((nrducell_inst - 1) % 24) / 4) + 1
    nrducell_id = (nrducell_inst - 1) % 4
    print(slot)
    print(nrducell_id)
elif sys.argv[1] == "1":
    if argv_len <= 4:
        sys.exit(-1)
    slot = int(sys.argv[3])
    nrducell_id = int(sys.argv[4])
    nrducell_inst = (slot - 1) * 4 + nrducell_id + 1
    print(nrducell_inst)
    print(nrducell_inst)
    print(nrducell_inst)
else:
    ret = -1

sys.exit(ret)
