#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    nrcell_inst = int(sys.argv[3])
    nrcellid = 0
    if nrcell_inst >= 17 and nrcell_inst <= 20:
        nrcellid = nrcell_inst - 13
    else:
        nrcellid = (nrcell_inst - 1) % 24
    print(nrcellid)
elif sys.argv[1] == "1":
    nrcellid = int(sys.argv[3])
    nrcell_inst = 0
    cu_cellconfig_inst = 0
    if nrcellid >= 4 and nrcellid <= 7:
        nrcell_inst = nrcellid + 13
    else:
        nrcell_inst = nrcellid + 1
    cu_cellconfig_inst = nrcellid + 1
    print(cu_cellconfig_inst)
    print(nrcell_inst)
    print(nrcell_inst)
else:
    ret = -1

sys.exit(ret)
