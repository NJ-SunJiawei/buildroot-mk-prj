#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

if len(sys.argv) <= 3:
    exit(-1)

op_name = sys.argv[2]


'''
ltecell-a1-measurectrl.measure-purpose值为 inter 时
cwmp第二个实例号i固定为1
ltecell-a1-measurectrl.measure-purpose值为 irat-nr 时
cwmp第二个实例号i固定为4
'''

a1_dict = {'inter':1, 'irat-nr':4}

ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    meas_inst = int(sys.argv[3])
    if meas_inst in a1_dict.values():
        for key, value in a1_dict.items():
            if value == meas_inst:
                print(key)
    else:
        ret = -1
elif sys.argv[1] == "1":
    meas_purpose = sys.argv[3]
    if meas_purpose in a1_dict:
        print(a1_dict[sys.argv[3]])
    else:
        ret = -1
else:
    ret = -1

sys.exit(ret)
