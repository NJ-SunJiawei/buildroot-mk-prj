#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
nrcell-a1-measurectl.measure-purpose
nrcell-a1-measurectl.operator-id
'''

a1_dict = {'Inter-freq':11, 'Inter-rat':12}

ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    inst_id = int(sys.argv[3])
    op_id = (inst_id - a1_dict['Inter-rat'] - 1) % 6
    offset = (inst_id - a1_dict['Inter-rat'] - 1) / 6
    measure_inst = offset + a1_dict['Inter-freq']
    if measure_inst in a1_dict.values():
        for key, value in a1_dict.items():
            if value == measure_inst:
                print(key)
                print(op_id)
    else:
        ret = -1
elif sys.argv[1] == "1":
    if argv_len <= 4:
        sys.exit(-1)
    measure_purpose = sys.argv[3]
    op_id = int(sys.argv[4])
    if measure_purpose in a1_dict:
        offset = a1_dict[measure_purpose] - a1_dict['Inter-freq']
        inst_id = a1_dict['Inter-rat'] + 1 + op_id + offset*6
        print(inst_id)
        print(inst_id)
    else:
        ret = -1
else:
    ret = -1

sys.exit(ret)
