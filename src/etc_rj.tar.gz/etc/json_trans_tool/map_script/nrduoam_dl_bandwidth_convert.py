#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 2:
    sys.exit(-1)

op_name = sys.argv[2]

'''
bandwidth convert to rb size
CELL_BW_100M -> DLBandwidth = 100 CarrierBandwidth = 273
'''

#正向：./test.py 0 cmcc Username Password
#期望输出：Username--Password
#逆向：./test.py 1 cucc Username~~Password
#期望输出：Username\nPassword
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
# $2为运营商标识
# 可以直接用print输出结果，自动带/n

ret = 0
if sys.argv[1] == "0":
    if argv_len <= 3:
        sys.exit(-1)
    dlbandwidth = int(sys.argv[3])#100/80/60...
    print("CELL_BW_{0}M".format(dlbandwidth))
elif sys.argv[1] == "1":
    rb_size = 0
    tmp_bandwidth = 0
    dlbandwidth = sys.argv[3]
    nums = re.findall('\d+', dlbandwidth)#CELL_BW_100M...
    if len(nums) != 1:
        sys.exit(-1)
    
    tmp_bandwidth = int(nums[0])
    if tmp_bandwidth == 100:
        rb_size = 273
    elif tmp_bandwidth == 90:
        rb_size = 245
    elif tmp_bandwidth == 80:
        rb_size = 217
    elif tmp_bandwidth == 70:
        rb_size = 189
    elif tmp_bandwidth == 60:
        rb_size = 162
    elif tmp_bandwidth == 50:
        rb_size = 133
    elif tmp_bandwidth == 40:
        rb_size = 106
    elif tmp_bandwidth == 30:
        rb_size = 78
    elif tmp_bandwidth == 25:
        rb_size = 65
    elif tmp_bandwidth == 20:
        rb_size = 51
    elif tmp_bandwidth == 15:
        rb_size = 38
    elif tmp_bandwidth == 10:
        rb_size = 24
    else:
        rb_size = 11
    print(nums[0])
    print(rb_size)
else:
    ret = -1

sys.exit(ret)
