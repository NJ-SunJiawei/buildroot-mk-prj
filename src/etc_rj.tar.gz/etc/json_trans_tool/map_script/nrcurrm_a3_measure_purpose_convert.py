#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
nrcell-a3-measurectl.measure-purpose
nrcell-a3-measurectl.operator-id
'''

a3_dict = {'Intra-freq':11, 'Inter-freq':12}

ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    inst_id = int(sys.argv[3])
    op_id = (inst_id - a3_dict['Inter-freq'] - 1) % 6
    offset = (inst_id - a3_dict['Inter-freq'] - 1) / 6
    measure_inst = offset + a3_dict['Intra-freq']
    if measure_inst in a3_dict.values():
        for key, value in a3_dict.items():
            if value == measure_inst:
                print(key)
                print(op_id)
    else:
        ret = -1
elif sys.argv[1] == "1":
    if argv_len <= 4:
        sys.exit(-1)
    measure_purpose = sys.argv[3]
    op_id = int(sys.argv[4])
    if measure_purpose in a3_dict:
        offset = a3_dict[measure_purpose] - a3_dict['Intra-freq']
        inst_id = a3_dict['Inter-freq'] + 1 + op_id + offset*6
        print(inst_id)
        print(inst_id)
    else:
        ret = -1
else:
    ret = -1

sys.exit(ret)
