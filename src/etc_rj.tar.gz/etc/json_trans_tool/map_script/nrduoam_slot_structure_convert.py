#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
TDD:一个S表示一个slot，一个slot 有14个symbols

SS1  10个的下行符号 2个gap 2个上行符号

dl_gp_ul__dl_gp_ul  这种是双周期的表示方法

-----------------------------------------------------------------------------------------------------------------------------
SS1(10:2:2),SS2(6:4:4),SS3(9:3:2),SS4(8:4:2),customize(format:dl_gp_ul or dl_gp_ul__dl_gp_ul)
传递：
Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.TddULDLConfigurationCommon.pattern1.NrofDownlinkSymbols
Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.TddULDLConfigurationCommon.pattern1.NrofUplinkSymbols
Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.TddULDLConfigurationCommon.pattern2.NrofDownlinkSymbols
Device.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.TddULDLConfigurationCommon.pattern2.NrofUplinkSymbols"
Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.{i}.CellConfig.{i}.NR.RAN.PHY.TddULDLConfigurationCommon.Pattern2.Enable

if (Enable)
    dl_gp_ul__dl_gp_ul   ("%d_%d_%d__%d_%d_%d", 
                                    pattern1.NrofDownlinkSymbols,
                                    14-pattern1.NrofDownlinkSymbols-pattern1.NrofUplinkSymbols,
                                    pattern1.NrofUplinkSymbols,
                                    pattern2.NrofDownlinkSymbols,
                                    14-pattern2.NrofDownlinkSymbols-pattern2.NrofUplinkSymbols,
                                    pattern2.NrofUplinkSymbols);
else
    dl_gp_ul   ("%d_%d_%d", 
                  pattern1.NrofDownlinkSymbols,
                  14-pattern1.NrofDownlinkSymbols-pattern1.NrofUplinkSymbols,
                  pattern1.NrofUplinkSymbols
                  );
'''

symbol_num = 14

cli_cwmp_dict = {
            'SS1' : '10_2_2',
            'SS2' : '6_4_4',
            'SS3' : '9_3_2',
            'SS4' : '8_4_2'}

ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    if argv_len <= 6:
        sys.exit(-1)
    pattern1_nr_of_downlink_symbols = int(sys.argv[3])
    pattern1_nr_of_uplink_symbols   = int(sys.argv[4])
    pattern2_nr_of_downlink_symbols = int(sys.argv[5])
    pattern2_nr_of_uplink_symbols   = int(sys.argv[6])
    
    if pattern1_nr_of_downlink_symbols == pattern2_nr_of_downlink_symbols and \
            pattern1_nr_of_uplink_symbols == pattern2_nr_of_uplink_symbols:
        cwmp_value = '{0}_{1}_{2}'.format(pattern1_nr_of_downlink_symbols,
                                        symbol_num - pattern1_nr_of_downlink_symbols - pattern1_nr_of_uplink_symbols,
                                        pattern1_nr_of_uplink_symbols)
    else:
        cwmp_value = '{0}_{1}_{2}__{3}_{4}_{5}'.format(pattern1_nr_of_downlink_symbols,
                                        symbol_num - pattern1_nr_of_downlink_symbols - pattern1_nr_of_uplink_symbols,
                                        pattern1_nr_of_uplink_symbols,
                                        pattern2_nr_of_downlink_symbols,
                                        symbol_num - pattern2_nr_of_downlink_symbols - pattern2_nr_of_uplink_symbols,
                                        pattern2_nr_of_uplink_symbols)
    if cwmp_value in list(cli_cwmp_dict.values()):
        for key, value in cli_cwmp_dict.items():
            if value == cwmp_value:
                print(key)
    else:
        print(cwmp_value)
elif sys.argv[1] == "1":
    slot_structure = sys.argv[3]
    if slot_structure in cli_cwmp_dict:
        cwmp_value = cli_cwmp_dict[slot_structure].split('_')
        pattern1_nr_of_downlink_symbols = int(cwmp_value[0])
        pattern1_nr_of_uplink_symbols   = int(cwmp_value[2])
        pattern2_nr_of_downlink_symbols = int(cwmp_value[0])
        pattern2_nr_of_uplink_symbols   = int(cwmp_value[2])
    else:
        cwmp_value = slot_structure.split('_')
        pattern1_nr_of_downlink_symbols = int(cwmp_value[0])
        pattern1_nr_of_uplink_symbols   = int(cwmp_value[2])
        pattern2_nr_of_downlink_symbols = int(cwmp_value[4])
        pattern2_nr_of_uplink_symbols   = int(cwmp_value[6])
    print(pattern1_nr_of_downlink_symbols)
    print(pattern1_nr_of_uplink_symbols)
    print(pattern2_nr_of_downlink_symbols)
    print(pattern2_nr_of_uplink_symbols)
else:
    ret = -1

sys.exit(ret)
