#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re

argv_len = len(sys.argv)

if argv_len <= 3:
    sys.exit(-1)

op_name = sys.argv[2]

'''
1T2R
当前实现
NumOfRxAntenna  2
NumOfTxAntenna  1

4T4R
NumOfRxAntenna  4
NumOfTxAntenna  4

拼接 %dT%R
'''


ret = 0
# $1为正逆向标识，0为正向，即cwmp节点-》CLI参数
if sys.argv[1] == "0":
    if argv_len <= 4:
        sys.exit(-1)
    num_of_rx_antenna = int(sys.argv[3])
    num_of_tx_antenna = int(sys.argv[4])
    print("{0}T{1}R".format(num_of_tx_antenna, num_of_rx_antenna))
elif sys.argv[1] == "1":
    txrx_mode = sys.argv[3]
    nums = re.findall('\d+', txrx_mode)
    if len(nums) != 2:
        sys.exit(-1)
    print(nums[1])
    print(nums[0])
else:
    ret = -1

sys.exit(ret)
