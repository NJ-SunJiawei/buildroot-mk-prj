#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
import argparse
import json
import io

# 
if __name__ == "__main__":

    print("test dev-name")
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--operator', type=str, help='operator tag', required=True)
    parser.add_argument('--input', type=str, help='input config file(json or xml)', required=True)
    parser.add_argument('--out', type=str, help='output config file(json or xml)', required=True)
    args = parser.parse_args()

    if args.input.endswith(".json"):
        with io.open(args.input, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
        
        #这段回头要加回来，这是增量转换，xml文件需要存在
        #tree = ET.parse(args.out)
        #g_root_ele = tree.getroot()

        for each in g_json_dict:
            print(each)

        # 创建根节点
        root = ET.Element('root')

        # 遍历JSON数据，将其转换为XML格式
        for key, value in g_json_dict.items():
            child = ET.Element(key)
            child.text = str(value)
            root.append(child)

        # 创建XML文件
        xml_tree = ET.ElementTree(root)
        xml_tree.write('devtest.xml', encoding="utf-8", xml_declaration=True)

        #json2xml()
        #pretty_xml(g_root_ele)
        #tree.write(args.out, encoding="utf-8", xml_declaration=True)
    """ elif args.input.endswith(".xml"):
        with io.open(args.out, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
        xml_tree = ET.ElementTree(file = args.input)
        g_root_ele = xml_tree.getroot()
        xml2json()
        json_data = json.dumps(g_json_dict, indent=2)
        with io.open(args.out, "w", encoding="utf-8") as f:
            f.write(json_data) 

    # 读取JSON文件
    with io.open('input.json', encoding="utf-8") as json_file:
        data = json.load(json_file)

    # 创建根节点
    root = ET.Element('root')

    # 遍历JSON数据，将其转换为XML格式
    for key, value in data.items():
        child = ET.Element(key)
        child.text = str(value)
        root.append(child)

    # 创建XML文件
    xml_tree = ET.ElementTree(root)
    xml_tree.write('output.xml') """