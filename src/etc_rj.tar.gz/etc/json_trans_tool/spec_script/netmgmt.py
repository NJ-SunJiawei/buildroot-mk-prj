#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
import argparse
import json
import io

############### 通用接口 ###############

# 用于美化xml文件，增强可读性，入参indent决定父子tag的缩进
def pretty_xml(element, indent="   ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    if element != None:  # 判断element是否有子元素
        if ((element.text is None) or element.text.isspace()) and list(element):  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def mask_to_decimal(mask):
    if '.' in mask:  # 如果mask已经是点分十进制，直接返回
        return mask
    else:
        mask_bits = int(mask)
        mask = (1 << 32) - (1 << (32 - mask_bits))
        return '{}.{}.{}.{}'.format(
            (mask >> 24) & 0xFF,
            (mask >> 16) & 0xFF,
            (mask >> 8) & 0xFF,
            mask & 0xFF,
        )

def mask_to_cidr(mask):
    if '.' in mask:
        mask_octets = mask.split('.')
        binary_mask = ''.join([bin(int(octet))[2:].zfill(8) for octet in mask_octets])
        cidr_mask = binary_mask.count('1')
        return str(cidr_mask)
    else:
        return mask

def create_ele(path, inst_dict, value = "0"):
    global g_root_ele

    if isinstance(value, int):
        print(value)
    ele_p = g_root_ele
    path_list = path.strip(". ").split(".")
    for i in range(len(path_list)):
        node_name = path_list[i]
        if node_name == "{i}" or node_name == "1":
            continue
        if i + 1 < len(path_list) and path_list[i + 1] == "{i}":
            if inst_dict.get(node_name):
                targ_ele = ele_p.find("{node}{attr}".format(node = node_name, attr = '[@instance_id="%s"]'%inst_dict[node_name]))
                if targ_ele is not None:
                    ele_p = targ_ele
                else:
                    ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":inst_dict[node_name]})
            else:
                if ele_p.find(node_name) is not None:
                    instance_id = max([int(elem.get("instance_id", 0)) for elem in ele_p.findall(node_name)]) + 1
                else:
                    instance_id = 1
                ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":str(instance_id)})

        elif i + 1 < len(path_list) and path_list[i + 1] == "1":
            targ_ele = ele_p.find('{node}[@instance_id="1"]'.format(node = node_name,))
            if targ_ele is not None:
                ele_p = targ_ele
            else:
                ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":"1"})
        else:
            targ_ele = ele_p.find(node_name)
            if targ_ele is not None:
                ele_p = targ_ele
            else:
                ele_p = ET.SubElement(ele_p, node_name)
        i = i + 1

    if path_list[-1] != "{i}" and path_list[-1] != "1":
        ele_p.text = value

def map_forward(value, map_table):
    return {key: val for key, val in [item.split('~') for item in map_table.split(',')]}[value]

def map_backward(value, map_table):
    return {val: key for key, val in [item.split('~') for item in map_table.split(',')]}[value]


#基于输入的xml的根element以及实例号字典, 查找path所指节点的实例号列表或是节点值,返回是一个列表
def element_find(path, inst_dict):
    global g_root_ele

    dm_list = path.strip(".").split(".")
    ele = g_root_ele
    for i, dm_name in enumerate(dm_list):
        if dm_list[i] == "{i}" or dm_list[i] == "1":
            continue
        spec_inst = ""
        if len(dm_list) > i + 1:
            if dm_list[i + 1] == "{i}":
                inst = inst_dict[dm_name]
                spec_inst = "[@instance_id='{inst}']".format(inst = inst)
            elif dm_list[i + 1] == "1":
                spec_inst = "[@instance_id='1']"
        ele_list = ele.findall("{dm_name}{spec_inst}".format(dm_name = dm_name, spec_inst = spec_inst))
        if not ele_list:
            return []
        ele = ele_list[0]

    if ele_list[0].attrib.has_key("instance_id"):
        return [item.attrib["instance_id"] for item in ele_list]
    else:
        return [ele.text]

def map_transf(json_dict, map_table, inst_dict):
    for map_tup in map_table:
        value = element_find(map_tup[0], inst_dict)
        if value:
            if len(map_tup) == 3:
                value[0] = map_backward(value[0], map_tup[2])
            json_dict.update({map_tup[1]:value[0]})
        
############### 通用接口end ###############

def json2xml():
    # 接口节点预创建
    create_ele("Device.Ethernet.Interface.{i}.Name", {"Interface":"1"}, "ETH")
    create_ele("Device.Ethernet.Interface.{i}.Name", {"Interface":"2"}, "NG")
    create_ele("Device.Ethernet.Interface.{i}.Name", {"Interface":"3"}, "SFP+")
    create_ele("Device.Ethernet.Interface.{i}.Enable", {"Interface":"1"}, "1")
    create_ele("Device.Ethernet.Interface.{i}.Enable", {"Interface":"2"}, "1")
    create_ele("Device.Ethernet.Interface.{i}.Enable", {"Interface":"3"}, "1")
    create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.Name", {"WANDevice":"1"}, "ETH")
    create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.Name", {"WANDevice":"2"}, "NG")
    create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.Name", {"WANDevice":"3"}, "SFP+")
    create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.Enable", {"WANDevice":"1"}, "1")
    create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.Enable", {"WANDevice":"2"}, "1")
    create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.Enable", {"WANDevice":"3"}, "1")

    vlan_dict = {item["name"]: [item["parent-interface"], str(1 + i)] for i, item in enumerate(g_json_dict.get("vlan-interface") or [])}
    intf_dict = {"ETH":"1", "NG":"2", "SFP+":"3"}
    intf_dict.update({item["interface"]: str(4 + i) for i, item in enumerate(g_json_dict.get("interface") or []) if item["interface"] not in vlan_dict.keys() + intf_dict.keys()})
    vlan_dict = {k: [intf_dict[vs[0]], vs[1]] for k, vs in vlan_dict.items()}

    for item in g_json_dict.get("interface") or []:
        if item["interface"] in vlan_dict.keys():
            intf_inst = vlan_dict[item["interface"]][0]
            vlan_inst = vlan_dict[item["interface"]][1]
            inst_dict = {"Interface":intf_inst, "WANDevice":intf_inst, "VlanInterface":vlan_inst}
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Enable", inst_dict, "1")
            if item.get("admin-status"):
                create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Enable", inst_dict, map_forward(item["admin-status"], "down~0,up~1"))
        else:
            inst_dict = {"Interface":intf_dict[item["interface"]], "WANDevice":intf_dict[item["interface"]]}
            create_ele("Device.Ethernet.Interface.{i}.Name", inst_dict, item["interface"])
            create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.Name", inst_dict, item["interface"])
            create_ele("Device.Ethernet.Interface.{i}.Enable", inst_dict, "1")
            create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.Enable", inst_dict, "1")

            if item.get("ip-mtu"):
                create_ele("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.MTU", inst_dict, item["ip-mtu"])
            if item.get("admin-status"):
                create_ele("Device.Ethernet.Interface.{i}.Enable", inst_dict, map_forward(item["admin-status"], "down~0,up~1"))
                create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.Enable", inst_dict, map_forward(item["admin-status"], "down~0,up~1"))
            if item.get("description"):
                create_ele("Device.Ethernet.Interface.{i}.UserLabel", inst_dict, item["description"])
                create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.UserLabel", inst_dict, item["description"])
            if item.get("speed"):
                create_ele("Device.Ethernet.Interface.{i}.MaxBitRate", inst_dict, map_forward(item["speed"], "auto~Auto,10M~10,100M~100,1000M~1000,10000M~10000,25000M~25000"))
                create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.MaxBitRate", inst_dict, map_forward(item["speed"], "auto~Auto,10M~10,100M~100,1000M~1000,10000M~10000,25000M~25000"))
            if item.get("duplex"):
                create_ele("Device.Ethernet.Interface.{i}.DuplexMode", inst_dict, map_forward(item["duplex"], "auto~Auto,half~Half,full~Full"))
                create_ele("InternetGatewayDevice.WANDevice.{i}.WANEthernetInterfaceConfig.DuplexMode", inst_dict, map_forward(item["duplex"], "auto~Auto,half~Half,full~Full"))
            if item.get("in-rate-limit"):
                create_ele("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.InRateLimit", inst_dict, item["in-rate-limit"])
            if item.get("out-rate-limit"):
                create_ele("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.OutRateLimit", inst_dict, item["out-rate-limit"])

    for item in g_json_dict.get("vlan-interface") or []:
        inst_dict = {"Interface":vlan_dict[item["name"]][0], "VlanInterface":vlan_dict[item["name"]][1]}

        create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Name", inst_dict, item["name"])
        create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Id", inst_dict, item["id"])
        create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Enable", inst_dict, "1")
    
    inst = 1
    for item in g_json_dict.get("ipv4-address") or []:
        if item["interface"] in intf_dict.keys():
            inst_dict = {
                "Interface":intf_dict[item["interface"]], 
                "IPv4Address":str(inst),
                "WANDevice":intf_dict[item["interface"]], 
                "WANIPConnection":str(inst)}

            create_ele("Device.Ethernet.Interface.{i}.IPv4Address.{i}.IPAddress", inst_dict, item["ipv4"])
            create_ele("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.ExternalIPAddress", inst_dict, item["ipv4"])
            create_ele("Device.Ethernet.Interface.{i}.IPv4Address.{i}.SubnetMask", inst_dict, mask_to_decimal(item["mask"]))
            create_ele("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.SubnetMask", inst_dict, mask_to_decimal(item["mask"]))
            create_ele("Device.Ethernet.Interface.{i}.IPv4Address.{i}.AddressingType", inst_dict, "Static")
            create_ele("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.AddressingType", inst_dict, "Static")
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.IPv4Address.{i}.PortType",
                    inst_dict, item["nr-port-type"])

        elif item["interface"] in vlan_dict.keys():
            inst_dict = {
                "Interface":vlan_dict[item["interface"]][0], 
                "VlanInterface":vlan_dict[item["interface"]][1], 
                "IPv4Address":str(inst),
                "WANDevice":vlan_dict[item["interface"]][0],}
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.IPAddress", inst_dict, item["ipv4"])
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.SubnetMask", inst_dict, mask_to_decimal(item["mask"]))
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.AddressingType", inst_dict, "Static")
            # vlan没有4G addressing type?
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv4Address.{i}.PortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.PortType",
                    inst_dict, item["nr-port-type"])
        inst += 1
            
    inst = 1
    for item in g_json_dict.get("ipv6-address") or []:
        if item["interface"] in intf_dict.keys():
            inst_dict = {
                "Interface":intf_dict[item["interface"]], 
                "IPv6Address":str(inst),
                "WANDevice":intf_dict[item["interface"]], 
                "WANIPConnection":str(inst)}

            create_ele("Device.Ethernet.Interface.{i}.IPv6Address.{i}.IPAddress", inst_dict, item["ipv6"])
            create_ele("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PrefixLength", inst_dict, item["prefix-len"])
            create_ele("Device.Ethernet.Interface.{i}.IPv6Address.{i}.Origin", inst_dict, "Static")
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6Address.{i}.PortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PortType",
                    inst_dict, item["nr-port-type"])
        elif item["interface"] in vlan_dict.keys():
            inst_dict = {
                "Interface":vlan_dict[item["interface"]][0], 
                "VlanInterface":vlan_dict[item["interface"]][1], 
                "IPv6Address":str(inst),
                "WANDevice":vlan_dict[item["interface"]][0],}
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.IPAddress", inst_dict, item["ipv6"])
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PrefixLength", inst_dict, item["prefix-len"])
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.Origin", inst_dict, "Static")
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv6Address.{i}.PortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PortType",
                    inst_dict, item["nr-port-type"])
        inst += 1
                
    inst = 1
    for item in g_json_dict.get("ipv4-dhcp-client") or []:
        if item["interface"] in intf_dict.keys():
            inst_dict = {
                "Interface":intf_dict[item["interface"]], 
                "IPv4Address":str(inst),
                "WANDevice":intf_dict[item["interface"]], 
                "WANIPConnection":str(inst)}
            create_ele("Device.Ethernet.Interface.{i}.IPv4Address.{i}.AddressingType", inst_dict, "DHCP")
            create_ele("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.AddressingType", inst_dict, "DHCP")
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.IPv4Address.{i}.PortType",
                    inst_dict, item["nr-port-type"])
        elif item["interface"] in vlan_dict.keys():
            inst_dict = {
                "Interface":vlan_dict[item["interface"]][0], 
                "VlanInterface":vlan_dict[item["interface"]][1], 
                "IPv4Address":str(inst),
                "WANDevice":vlan_dict[item["interface"]][0],}
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.AddressingType", inst_dict, "DHCP")
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv4Address.{i}.PortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.PortType",
                    inst_dict, item["nr-port-type"])
        inst += 1

    if g_json_dict.get("ipv6-dhcp-client"):
        inst = 1
        for item in g_json_dict["ipv6-dhcp-client"]:
            if item["interface"] in intf_dict.keys():
                inst_dict = {
                    "Interface":intf_dict[item["interface"]], 
                    "IPv6Address":str(inst),
                    "WANDevice":intf_dict[item["interface"]], 
                    "WANIPConnection":str(inst)}
                create_ele("Device.Ethernet.Interface.{i}.IPv6Address.{i}.Origin", inst_dict, "DHCPv6")
                if item.get("lte-port-type"):
                    map_str = "other~0,S1~1,S1C~2,S1U~3,X2~4,X2C~5,X2U~6,S1C/X2C~7,S1U/X2U~8,S1/X2~9"
                    create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6Address.{i}.PortType", 
                        inst_dict, item["lte-port-type"])
                if item.get("nr-port-type"):
                    map_str = "other~0,Ng~1,NgC~2,NgU~3,Xn~4,XnC~5,XnU~6,NgC/XnC~7,NgU/XnU~8,Ng/Xn~9,OAM~11"
                    create_ele("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PortType",
                        inst_dict, item["nr-port-type"])
            elif item["interface"] in vlan_dict.keys():
                inst_dict = {
                    "Interface":vlan_dict[item["interface"]][0], 
                    "VlanInterface":vlan_dict[item["interface"]][1], 
                    "IPv6Address":str(inst),
                    "WANDevice":vlan_dict[item["interface"]][0],}
                create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.Origin", inst_dict, "DHCPv6")
                if item.get("lte-port-type"):
                    map_str = "other~0,S1~1,S1C~2,S1U~3,X2~4,X2C~5,X2U~6,S1C/X2C~7,S1U/X2U~8,S1/X2~9"
                    create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv6Address.{i}.PortType", 
                        inst_dict, item["lte-port-type"])
                if item.get("nr-port-type"):
                    map_str = "other~0,Ng~1,NgC~2,NgU~3,Xn~4,XnC~5,XnU~6,NgC/XnC~7,NgU/XnU~8,Ng/Xn~9,OAM~11"
                    create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PortType",
                        inst_dict, item["nr-port-type"])
            inst += 1

    inst = 1
    for item in g_json_dict.get("ipv6-address-autoconfig") or []:
        if item["interface"] in intf_dict.keys():
            inst_dict = {
                "Interface":intf_dict[item["interface"]], 
                "WANDevice":intf_dict[item["interface"]], }

            create_ele("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6AutoConfig", inst_dict, map_forward(item["service"], "disable~0,enable~1"))
            if item.get("accept-ra-default-route"):
                create_ele("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", inst_dict, map_forward(item["accept-ra-default-route"], "disable~0,enable~1"))
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AutoConfPortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AutoConfPortType",
                    inst_dict, item["nr-port-type"])
        elif item["interface"] in vlan_dict.keys():
            inst_dict = {
                "Interface":vlan_dict[item["interface"]][0], 
                "VlanInterface":vlan_dict[item["interface"]][1], 
                "WANDevice":vlan_dict[item["interface"]][0],}
            create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6AutoConfig", inst_dict, map_forward(item["service"], "disable~0,enable~1"))
            if item.get("accept-ra-default-route"):
                create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", inst_dict, map_forward(item["accept-ra-default-route"], "disable~0,enable~1"))
            if item.get("lte-port-type"):
                create_ele("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.AutoConfPortType", 
                    inst_dict, item["lte-port-type"])
            if item.get("nr-port-type"):
                create_ele("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AutoConfPortType",
                    inst_dict, item["nr-port-type"])
        inst += 1

    inst = 1
    for item in g_json_dict.get("ipv4-route") or []:
        inst_dict = {
            "IpRoute":str(inst)}

        create_ele("Device.Ethernet.IpRoute.{i}.DstIpNetwork", inst_dict, item["dst-ipv4"])
        create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.DstIpNetwork", inst_dict, item["dst-ipv4"])
        create_ele("Device.Ethernet.IpRoute.{i}.PrefixLength", inst_dict, mask_to_cidr(item["mask"]))
        create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.PrefixLength", inst_dict, mask_to_cidr(item["mask"]))
        if item.get("next-hop"):
            create_ele("Device.Ethernet.IpRoute.{i}.GatewayIpAddress", inst_dict, item["next-hop"])
            create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.GatewayIpAddress", inst_dict, item["next-hop"])
        if item.get("interface"):
            create_ele("Device.Ethernet.IpRoute.{i}.InterfaceName", inst_dict, item["interface"])
            create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.InterfaceName", inst_dict, item["interface"])
        inst += 1
    # V4/V6 路由实例节点相同，实例号连续，这里inst不能从1开始， 比如v4 实例号1~3， v6实例号就要从4开始
    for item in g_json_dict.get("ipv6-route") or []:
        inst_dict = {
            "IpRoute":str(inst)}

        create_ele("Device.Ethernet.IpRoute.{i}.DstIpNetwork", inst_dict, item["dst-ipv6"])
        create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.DstIpNetwork", inst_dict, item["dst-ipv6"])
        create_ele("Device.Ethernet.IpRoute.{i}.PrefixLength", inst_dict, mask_to_cidr(item["prefix-len"]))
        create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.PrefixLength", inst_dict, mask_to_cidr(item["prefix-len"]))
        if item.get("next-hop"):
            create_ele("Device.Ethernet.IpRoute.{i}.GatewayIpAddress", inst_dict, item["next-hop"])
            create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.GatewayIpAddress", inst_dict, item["next-hop"])
        if item.get("interface"):
            create_ele("Device.Ethernet.IpRoute.{i}.InterfaceName", inst_dict, item["interface"])
            create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.InterfaceName", inst_dict, item["interface"])
        inst += 1

    inst = 1
    for item in g_json_dict.get("ipv4-route-blackhole") or []:
        inst_dict = {
            "IPv4Address":str(inst)}

        create_ele("Device.X_WWW-RUIJIE-COM-CN.NetMgmt.BlackHoleRoute.IPv4Address.{i}.IPAddress", inst_dict, item["dst-ipv4"])
        create_ele("Device.X_WWW-RUIJIE-COM-CN.NetMgmt.BlackHoleRoute.IPv4Address.{i}.SubnetMask", inst_dict, mask_to_decimal(item["mask"]))
        inst += 1

    # 补充工具无法转换的路由配置IpVer节点
    for ele in g_root_ele.findall("Device/Ethernet/IpRoute"):
        # 用地址里是否带.判断是ipv4还是ipv6
        ipver = "1" if "." in ele.find("DstIpNetwork").text else "2"
        create_ele("Device.Ethernet.IpRoute.{i}.IpVer",
            {"IpRoute":ele.attrib["instance_id"]}, ipver)
    for ele in g_root_ele.findall("InternetGatewayDevice/X_WWW-RUIJIE-COM-CN/NetMgmt/IpRoute"):
        # 用地址里是否带.判断是ipv4还是ipv6
        ipver = "1" if "." in ele.find("DstIpNetwork").text else "2"
        create_ele("InternetGatewayDevice.X_WWW-RUIJIE-COM-CN.NetMgmt.IpRoute.{i}.IpVer",
            {"IpRoute":ele.attrib["instance_id"]}, ipver)


""" xml转json """
def xml2json():
    json_cfg_dict = {}
    json_cfg_dict["interface"] = []
    json_cfg_dict["vlan-interface"] = []
    json_cfg_dict["ipv4-dhcp-client"] = []
    json_cfg_dict["ipv4-address"] = []
    json_cfg_dict["ipv6-dhcp-client"] = []
    json_cfg_dict["ipv6-address"] = []
    json_cfg_dict["ipv6-address-autoconfig"] = []

    # 遍历所有Device.Ethernet.Interface.实例
    for intf_instance in element_find("Device.Ethernet.Interface.", {}):
        # 确定实例号, WANDevice是对应的4G多实例节点
        inst_dict = {"Interface":intf_instance, "WANDevice":intf_instance}
        intf_json = {}

        # 建立interface mo的参数映射表, 元素格式(节点名, 参数名, [值映射关系]), 其中值映射关系是可选项
        map_table = [
            ("Device.Ethernet.Interface.{i}.Name", "interface"),
            ("Device.Ethernet.Interface.{i}.Enable", "admin-status", "down~0,up~1"),
            ("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.MTU", "ip-mtu"),
            ("Device.Ethernet.Interface.{i}.UserLabel", "description"),
            ("Device.Ethernet.Interface.{i}.MaxBitRate", "speed", "auto~Auto,10M~10,100M~100,1000M~1000,10000M~10000,25000M~25000"),
            ("Device.Ethernet.Interface.{i}.DuplexMode", "duplex", "auto~Auto,half~Half,full~Full"),
            ("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.InRateLimit", "in-rate-limit"),
            ("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.OutRateLimit", "out-rate-limit"),
        ]
        # 根据interface mo的参数映射表来映射参数配置
        map_transf(intf_json, map_table, inst_dict)
        # 装载入临时配置全集字典
        json_cfg_dict["interface"].append(intf_json)
        
        # 因为ipv4 多实例节点在interface多实例节点下, 需要复用这个父节点的实例号信息和索引参数信息, 所以这个节点的遍历需要放在父实例处理中
        for ipv4_instance in element_find("Device.Ethernet.Interface.{i}.IPv4Address.", inst_dict):
            # 这里用update更新本级多实例的实例号, WANIPConnection是对应的4G多实例节点
            inst_dict.update({"IPv4Address":ipv4_instance, "WANIPConnection":ipv4_instance})
            value = element_find("Device.Ethernet.Interface.{i}.IPv4Address.{i}.AddressingType", inst_dict)
            if value[0] == "DHCP":
                dhcp_json = {
                    "interface":intf_json["interface"],
                    "service":"enable"
                }
                map_table = [
                    ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(dhcp_json, map_table, inst_dict)
                json_cfg_dict["ipv4-dhcp-client"].append(dhcp_json)
            elif value[0] == "Static":
                static_ip_json = {
                    "interface":intf_json["interface"],
                }
                map_table = [
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.IPAddress", "ipv4"),
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.SubnetMask", "mask"),
                    ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(static_ip_json, map_table, inst_dict)
                json_cfg_dict["ipv4-address"].append(static_ip_json)
        for ip_instance in element_find("Device.Ethernet.Interface.{i}.IPv6Address.", inst_dict):
            inst_dict.update({"IPv6Address":ipv4_instance, "WANIPConnection":ipv4_instance})
            value = element_find("Device.Ethernet.Interface.{i}.IPv6Address.{i}.Origin", inst_dict)
            if value[0] == "DHCP":
                dhcp_json = {
                    "interface":intf_json["interface"],
                    "service":"enable"
                }
                map_table = [
                    ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(dhcp_json, map_table, inst_dict)
                json_cfg_dict["ipv6-dhcp-client"].append(dhcp_json)
            elif value[0] == "Static":
                static_ip_json = {
                    "interface":intf_json["interface"],
                }
                map_table = [
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.IPAddress", "ipv6"),
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PrefixLength", "prefix-len"),
                    ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6Address.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(static_ip_json, map_table, inst_dict)
                json_cfg_dict["ipv6-address"].append(static_ip_json)

        v6_auto = element_find("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6AutoConfig", inst_dict)
        if v6_auto:
            auto_dict = {"service":map_backward(v6_auto[0], "disable~0,enable~1"), "interface":intf_json["interface"]}
            map_table = [
                ("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "accept-ra-default-route", "disable~0,enable~1"),
                ("InternetGatewayDevice.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AutoConfPortType", "lte-port-type"),
                ("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "nr-port-type"),
            ]
            map_transf(auto_dict, map_table, inst_dict)
            json_cfg_dict["ipv6-address-autoconfig"].append(auto_dict)

        for vlan_instance in element_find("Device.Ethernet.Interface.{i}.VlanInterface.", inst_dict):
            inst_dict.update({"VlanInterface":vlan_instance})
            vlan_intf_dict = {}
            map_table = [
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Enable", "admin-status", "down~0,up~1"),
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Name", "name")
            ]
            map_transf(vlan_intf_dict, map_table, inst_dict)
            json_cfg_dict["interface"].append(vlan_intf_dict)

            vlan_dict = {"parent-interface":intf_json["interface"],}
            map_table = [
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Name", "name"), 
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Id", "id")
            ]
            map_transf(vlan_dict, map_table, inst_dict)
            json_cfg_dict["vlan-interface"].append(vlan_dict)

            for ip_instance in element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.", inst_dict):
                inst_dict.update({"IPv4Address":ip_instance})
                value = element_find("Device.Ethernet.Interface.{i}.IPv4Address.{i}.VlanInterface.{i}.AddressingType", inst_dict)
                if value[0] == "DHCP":
                    dhcp_json = {
                        "interface":vlan_intf_dict["interface"],
                        "service":"enable"
                    }
                    map_table = [
                        ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv4Address.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}..IPv4Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(dhcp_json, map_table, inst_dict)
                    json_cfg_dict["ipv4-dhcp-client"].append(dhcp_json)
                elif value[0] == "Static":
                    static_ip_json = {
                        "interface":vlan_intf_dict["interface"],
                    }
                    map_table = [
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.IPAddress", "ipv4"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.SubnetMask", "mask"),
                        ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv4Address.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(static_ip_json, map_table, inst_dict)
                    json_cfg_dict["ipv4-address"].append(static_ip_json)
            
            for ip_instance in element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.", inst_dict):
                inst_dict.update({"IPv6Address":ipv4_instance, "WANIPConnection":ipv4_instance})
                value = element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.Origin", inst_dict)
                if value[0] == "DHCP":
                    dhcp_json = {
                        "interface":vlan_intf_dict["interface"],
                        "service":"enable"
                    }
                    map_table = [
                        ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(dhcp_json, map_table, inst_dict)
                    json_cfg_dict["ipv6-dhcp-client"].append(dhcp_json)
                elif value[0] == "Static":
                    static_ip_json = {
                        "interface":vlan_intf_dict["interface"],
                    }
                    map_table = [
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.IPAddress", "ipv6"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PrefixLength", "prefix-len"),
                        ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv6Address.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(static_ip_json, map_table, inst_dict)
                    json_cfg_dict["ipv6-address"].append(static_ip_json)
            
            v6_auto = element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6AutoConfig", inst_dict)
            if v6_auto:
                auto_dict = {"service":map_backward(v6_auto[0], "disable~0,enable~1"), "interface":vlan_dict["interface"]}
                map_table = [
                    ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "accept-ra-default-route", "disable~0,enable~1"),
                    ("InternetGatewayDevice.WANDevice.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AutoConfPortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "nr-port-type"),
                ]
                map_transf(auto_dict, map_table, inst_dict)
                json_cfg_dict["ipv6-address-autoconfig"].append(auto_dict)
    
    json_cfg_dict = {key:val for key, val in json_cfg_dict.items() if val}
    #写入json配置文件
    g_json_dict.update(json_cfg_dict)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--operator', type=str, help='operator tag', required=True)
    parser.add_argument('--input', type=str, help='input config file(json or xml)', required=True)
    parser.add_argument('--out', type=str, help='output config file(json or xml)', required=True)
    args = parser.parse_args()

    if args.input.endswith(".json"):
        with io.open(args.input, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
        
        tree = ET.parse(args.out)
        g_root_ele = tree.getroot()
        json2xml()
        pretty_xml(g_root_ele)
        tree.write(args.out, encoding="utf-8", xml_declaration=True)
    elif args.input.endswith(".xml"):
        with io.open(args.out, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
        xml_tree = ET.ElementTree(file = args.input)
        g_root_ele = xml_tree.getroot()
        xml2json()
        json_data = json.dumps(g_json_dict, indent=2)
        with io.open(args.out, "w", encoding="utf-8") as f:
            f.write(json_data)
        
