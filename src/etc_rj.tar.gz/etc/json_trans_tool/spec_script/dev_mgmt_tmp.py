#!/usr/bin/env python
# -*- coding: utf-8 -*-


import xml.etree.ElementTree as ET
import argparse
import json
import io

# 用于美化xml文件，增强可读性，入参indent决定父子tag的缩进
def pretty_xml(element, indent="   ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    if element != None:  # 判断element是否有子元素
        if ((element.text is None) or element.text.isspace()) and list(element):  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作


def create_ele(path, inst_dict, value = "0"):
    global g_root_ele

    if isinstance(value, int):
        print(value)
    ele_p = g_root_ele
    path_list = path.strip(". ").split(".")
    print(path_list)
    for i in range(len(path_list)):
        node_name = path_list[i]
        if node_name == "{i}" or node_name == "1":
            continue
        if i + 1 < len(path_list) and path_list[i + 1] == "{i}":
            if inst_dict.get(node_name):
                targ_ele = ele_p.find("{node}{attr}".format(node = node_name, attr = '[@instance_id="%s"]'%inst_dict[node_name]))
                if targ_ele is not None:
                    ele_p = targ_ele
                else:
                    ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":inst_dict[node_name]})
            else:
                if ele_p.find(node_name) is not None:
                    instance_id = max([int(elem.get("instance_id", 0)) for elem in ele_p.findall(node_name)]) + 1
                else:
                    instance_id = 1
                ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":str(instance_id)})

        elif i + 1 < len(path_list) and path_list[i + 1] == "1":
            targ_ele = ele_p.find('{node}[@instance_id="1"]'.format(node = node_name,))
            if targ_ele is not None:
                ele_p = targ_ele
            else:
                ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":"1"})
        else:
            targ_ele = ele_p.find(node_name)
            if targ_ele is not None:
                ele_p = targ_ele
            else:
                ele_p = ET.SubElement(ele_p, node_name)
        i = i + 1

    if path_list[-1] != "{i}" and path_list[-1] != "1":
        ele_p.text = value

def map_forward(value, map_table):
    return {key: val for key, val in [item.split('~') for item in map_table.split(',')]}[value]

def map_backward(value, map_table):
    return {val: key for key, val in [item.split('~') for item in map_table.split(',')]}[value]


#基于输入的xml的根element以及实例号字典, 查找path所指节点的实例号列表或是节点值,返回是一个列表
def element_find(path, inst_dict):
    global g_root_ele

    dm_list = path.strip(".").split(".")
    ele = g_root_ele
    for i, dm_name in enumerate(dm_list):
        if dm_list[i] == "{i}" or dm_list[i] == "1":
            continue
        spec_inst = ""
        if len(dm_list) > i + 1:
            if dm_list[i + 1] == "{i}":
                #inst_dict 必须得有
                inst = inst_dict[dm_name]
                spec_inst = "[@instance_id='{inst}']".format(inst = inst)
            elif dm_list[i + 1] == "1":
                spec_inst = "[@instance_id='1']"
        ele_list = ele.findall("{dm_name}{spec_inst}".format(dm_name = dm_name, spec_inst = spec_inst))
        if not ele_list:
            return []
        ele = ele_list[0]

    if ele_list[0].attrib.has_key("instance_id"):
        return [item.attrib["instance_id"] for item in ele_list]
    else:
        return [ele.text]

def map_transf(json_dict, map_table, inst_dict):
    for map_tup in map_table:
        value = element_find(map_tup[0], inst_dict)
        if value:
            if len(map_tup) == 3:
                value[0] = map_backward(value[0], map_tup[2])
            json_dict.update({map_tup[1]:value[0]})

#计算槽位号和实例号id
def slot_and_instance_proc(match_dev_info_dict, dev_type, parent_dev_id):

    if dev_type == "HUB":
        binary_num = "{:0>32b}".format(int(match_dev_info_dict.attrib["ID"]))
        print(binary_num)
        slot = "{}".format(int(binary_num[8:16], 2))
        print(int(binary_num[8:16], 2))
        eu_id = "{}".format(int(binary_num[16:], 2))
        print("slot:" , slot, ", eu_id", eu_id)
        return {"Slot" : slot, "EU": eu_id}
    elif dev_type == "RRU":
        parent_binary_num = "{:0>32b}".format(int(parent_dev_id))
        print(parent_binary_num)
        slot = "{}".format(int(parent_binary_num[8:16], 2))
        eu_id = "{}".format(int(parent_binary_num[16:], 2))

        binary_num = "{:0>32b}".format(int(match_dev_info_dict.attrib["ID"]))
        print(binary_num)
        rru_id = "{}".format(int(binary_num[16:], 2))
        print("slot:" , slot, ", eu_id:", eu_id, "rru_id", rru_id)
        return {"Slot" : slot, "EU" : eu_id, "RU" : rru_id}

#遍历xml文件
def traverseXml(element):
    print (len(element))
    if len(element) > 0:
        for child in element:
            print (child.tag, "----", child.attrib)
            traverseXml(child)

#根据解析出的 SN 匹配设备类型
def Sn2DeviceType(in_sn):
    global g_dev_info_root_ele

    print(in_sn)

    if len(g_dev_info_root_ele) > 0:
        for child in g_dev_info_root_ele:
            #print (child.tag, "----", child.attrib)
            if (child.attrib["serial-number"] == in_sn):
                print(child.attrib["product"])
                return child

#SN 判断什么设备 CU EU RU
# def xxx() :

# instance 
# def yyy() :

def json2xml():

    for item in g_json_dict.get("device-name") or []:
        print("******")
        print(item)
        #遍历出来的SN填进去
        match_dev_info_dict = Sn2DeviceType(item.get("sn"))
        if match_dev_info_dict.attrib["product"] == "CU" :
            create_ele("Device.DeviceInfo.MU.1.UserLabel", [], item.get("name"))
            create_ele("Device.DeviceInfo.MU.1.SyncSn", [], item.get("sn"))
        if match_dev_info_dict.attrib["product"] == "DU" :
            continue
        if match_dev_info_dict.attrib["product"] == "HUB" :
            ele_dict = slot_and_instance_proc(match_dev_info_dict, "HUB", "")
            create_ele("Device.DeviceInfo.MU.1.Slot.{i}.EU.{i}.UserLabel", ele_dict, item.get("name"))
            create_ele("Device.DeviceInfo.MU.1.Slot.{i}.EU.{i}.SyncSn", ele_dict, item.get("sn"))
        if match_dev_info_dict.attrib["product"] == "RRU" :
            ele_dict = slot_and_instance_proc(match_dev_info_dict, "RRU", match_dev_info_dict.find('parent').attrib["ID"])
            create_ele("Device.DeviceInfo.MU.1.Slot.{i}.EU.{i}.RU.{i}.UserLabel", ele_dict, item.get("name"))
            create_ele("Device.DeviceInfo.MU.1.Slot.{i}.EU.{i}.RU.{i}.SyncSn", ele_dict, item.get("sn"))

        print(match_dev_info_dict.attrib)
        
        print("******")
    #SN 是DU要直接跳过
    # 最外层写个遍历，遍历 到每个 device name 下的 SN 
    #for item in g_json_dict.get("sn") or []:
    # 1 读出使用 SN,然后使用SN判断设备类型

    # 2 判断类型后，使用SN计算出设备的SLOT，以及实例号

    # 3 创建对应的告警实例节点 
    #create_ele("Device.DeviceInfo.MU.1.", {})
    # dd = {
    #     "cu":"Device.DeviceInfo.MU.{i}"
    # }
    # m = {}
    # m.update(yyy(sn))


""" xml转json """
def xml2json():
    #mo层面 
    json_cfg_dict = {}
    json_cfg_dict["device-name"] = []

    json_cfg_dict["interface"] = []

    # 遍历所有 Device.DeviceInfo.MU.1. ,其实 mu_instance 只能是1，因为MU实例号只有1 
    for mu_instance in element_find("Device.DeviceInfo.MU.1.", {}):
        # 确定实例号, WANDevice是对应的4G多实例节点
        inst_dict = {"name":mu_instance, "sn":mu_instance}
        intf_json = {}

        # 建立interface mo的参数映射表, 元素格式(节点名, 参数名, [值映射关系]), 其中值映射关系是可选项
        map_table = [
            ("Device.DeviceInfo.MU.1.UserLabel", "name"),
            ("Device.DeviceInfo.MU.1.SyncSn", "sn"),
        ]
        # 根据interface mo的参数映射表来映射参数配置
        map_transf(intf_json, map_table, inst_dict)
        # 装载入临时配置全集字典
        json_cfg_dict["device-name"].append(intf_json)
        
        # 因为ipv4 多实例节点在interface多实例节点下, 需要复用这个父节点的实例号信息和索引参数信息, 所以这个节点的遍历需要放在父实例处理中
        for ipv4_instance in element_find("Device.Ethernet.Interface.{i}.IPv4Address.", inst_dict):
            # 这里用update更新本级多实例的实例号, WANIPConnection是对应的4G多实例节点
            inst_dict.update({"IPv4Address":ipv4_instance, "WANIPConnection":ipv4_instance})
            value = element_find("Device.Ethernet.Interface.{i}.IPv4Address.{i}.AddressingType", inst_dict)
            if value[0] == "DHCP":
                dhcp_json = {
                    "interface":intf_json["interface"],
                    "service":"enable"
                }
                map_table = [
                    ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(dhcp_json, map_table, inst_dict)
                json_cfg_dict["ipv4-dhcp-client"].append(dhcp_json)
            elif value[0] == "Static":
                static_ip_json = {
                    "interface":intf_json["interface"],
                }
                map_table = [
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.IPAddress", "ipv4"),
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.SubnetMask", "mask"),
                    ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv4Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(static_ip_json, map_table, inst_dict)
                json_cfg_dict["ipv4-address"].append(static_ip_json)
        for ip_instance in element_find("Device.Ethernet.Interface.{i}.IPv6Address.", inst_dict):
            inst_dict.update({"IPv6Address":ipv4_instance, "WANIPConnection":ipv4_instance})
            value = element_find("Device.Ethernet.Interface.{i}.IPv6Address.{i}.Origin", inst_dict)
            if value[0] == "DHCP":
                dhcp_json = {
                    "interface":intf_json["interface"],
                    "service":"enable"
                }
                map_table = [
                    ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(dhcp_json, map_table, inst_dict)
                json_cfg_dict["ipv6-dhcp-client"].append(dhcp_json)
            elif value[0] == "Static":
                static_ip_json = {
                    "interface":intf_json["interface"],
                }
                map_table = [
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.IPAddress", "ipv6"),
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PrefixLength", "prefix-len"),
                    ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6Address.{i}.PortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                ]
                map_transf(static_ip_json, map_table, inst_dict)
                json_cfg_dict["ipv6-address"].append(static_ip_json)

        v6_auto = element_find("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6AutoConfig", inst_dict)
        if v6_auto:
            auto_dict = {"service":map_backward(v6_auto[0], "disable~0,enable~1"), "interface":intf_json["interface"]}
            map_table = [
                ("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "accept-ra-default-route", "disable~0,enable~1"),
                ("InternetGatewayDevice.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AutoConfPortType", "lte-port-type"),
                ("Device.Ethernet.Interface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "nr-port-type"),
            ]
            map_transf(auto_dict, map_table, inst_dict)
            json_cfg_dict["ipv6-address-autoconfig"].append(auto_dict)

        for vlan_instance in element_find("Device.Ethernet.Interface.{i}.VlanInterface.", inst_dict):
            inst_dict.update({"VlanInterface":vlan_instance})
            vlan_intf_dict = {}
            map_table = [
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Enable", "admin-status", "down~0,up~1"),
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Name", "name")
            ]
            map_transf(vlan_intf_dict, map_table, inst_dict)
            json_cfg_dict["interface"].append(vlan_intf_dict)

            vlan_dict = {"parent-interface":intf_json["interface"],}
            map_table = [
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Name", "name"), 
                ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.Id", "id")
            ]
            map_transf(vlan_dict, map_table, inst_dict)
            json_cfg_dict["vlan-interface"].append(vlan_dict)

            for ip_instance in element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.", inst_dict):
                inst_dict.update({"IPv4Address":ip_instance})
                value = element_find("Device.Ethernet.Interface.{i}.IPv4Address.{i}.VlanInterface.{i}.AddressingType", inst_dict)
                if value[0] == "DHCP":
                    dhcp_json = {
                        "interface":vlan_intf_dict["interface"],
                        "service":"enable"
                    }
                    map_table = [
                        ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv4Address.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}..IPv4Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(dhcp_json, map_table, inst_dict)
                    json_cfg_dict["ipv4-dhcp-client"].append(dhcp_json)
                elif value[0] == "Static":
                    static_ip_json = {
                        "interface":vlan_intf_dict["interface"],
                    }
                    map_table = [
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.IPAddress", "ipv4"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.SubnetMask", "mask"),
                        ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv4Address.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv4Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(static_ip_json, map_table, inst_dict)
                    json_cfg_dict["ipv4-address"].append(static_ip_json)
            
            for ip_instance in element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.", inst_dict):
                inst_dict.update({"IPv6Address":ipv4_instance, "WANIPConnection":ipv4_instance})
                value = element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.Origin", inst_dict)
                if value[0] == "DHCP":
                    dhcp_json = {
                        "interface":vlan_intf_dict["interface"],
                        "service":"enable"
                    }
                    map_table = [
                        ("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.1.WANIPConnection.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(dhcp_json, map_table, inst_dict)
                    json_cfg_dict["ipv6-dhcp-client"].append(dhcp_json)
                elif value[0] == "Static":
                    static_ip_json = {
                        "interface":vlan_intf_dict["interface"],
                    }
                    map_table = [
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.IPAddress", "ipv6"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PrefixLength", "prefix-len"),
                        ("InternetGatewayDevice.WANDevice.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.VlanInterface.{i}.IPv6Address.{i}.PortType", "lte-port-type"),
                        ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.IPv6Address.{i}.PortType", "nr-port-type")
                    ]
                    map_transf(static_ip_json, map_table, inst_dict)
                    json_cfg_dict["ipv6-address"].append(static_ip_json)
            
            v6_auto = element_find("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.IPv6AutoConfig", inst_dict)
            if v6_auto:
                auto_dict = {"service":map_backward(v6_auto[0], "disable~0,enable~1"), "interface":vlan_dict["interface"]}
                map_table = [
                    ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "accept-ra-default-route", "disable~0,enable~1"),
                    ("InternetGatewayDevice.WANDevice.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AutoConfPortType", "lte-port-type"),
                    ("Device.Ethernet.Interface.{i}.VlanInterface.{i}.X_WWW-RUIJIE-COM-CN.NetMgmt.AcceptRaDefrt", "nr-port-type"),
                ]
                map_transf(auto_dict, map_table, inst_dict)
                json_cfg_dict["ipv6-address-autoconfig"].append(auto_dict)
    
    json_cfg_dict = {key:val for key, val in json_cfg_dict.items() if val}
    #写入json配置文件
    g_json_dict.update(json_cfg_dict)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--operator', type=str, help='operator tag', required=True)
    parser.add_argument('--input', type=str, help='input config file(json or xml)', required=True)
    parser.add_argument('--out', type=str, help='output config file(json or xml)', required=True)
    args = parser.parse_args()

    # 这里回头要写成设备上实际路径
    dev_info_xml_tree = ET.ElementTree(file = "dev_info.xml")
    g_dev_info_root_ele = dev_info_xml_tree.getroot()

    if args.input.endswith(".json"):
        with io.open(args.input, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
            #print(g_json_dict)
        tree = ET.parse(args.out)
        g_root_ele = tree.getroot()
        json2xml()
        pretty_xml(g_root_ele)
        tree.write(args.out, encoding="utf-8", xml_declaration=True)
    elif args.input.endswith(".xml"):
        with io.open(args.out, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
        xml_tree = ET.ElementTree(file = args.input)
        g_root_ele = xml_tree.getroot()
        xml2json()
        json_data = json.dumps(g_json_dict, indent=2)
        with io.open(args.out, "w", encoding="utf-8") as f:
            f.write(json_data)
        
