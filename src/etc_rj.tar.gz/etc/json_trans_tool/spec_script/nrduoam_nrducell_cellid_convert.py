#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import argparse
import json
import io

# 用于美化xml文件，增强可读性，入参indent决定父子tag的缩进
def pretty_xml(element, indent="   ", newline="\n", level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
    if element != None:  # 判断element是否有子元素
        if ((element.text is None) or element.text.isspace()) and list(element):  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作

def mask_to_decimal(mask):
    if '.' in mask:  # 如果mask已经是点分十进制，直接返回
        return mask
    else:
        mask_bits = int(mask)
        mask = (1 << 32) - (1 << (32 - mask_bits))
        return '{}.{}.{}.{}'.format(
            (mask >> 24) & 0xFF,
            (mask >> 16) & 0xFF,
            (mask >> 8) & 0xFF,
            mask & 0xFF,
        )

def mask_to_cidr(mask):
    if '.' in mask:
        mask_octets = mask.split('.')
        binary_mask = ''.join([bin(int(octet))[2:].zfill(8) for octet in mask_octets])
        cidr_mask = binary_mask.count('1')
        return str(cidr_mask)
    else:
        return mask
#path:Device.Services.FAPService.1.CUCellConfig.{i}.CellId
#inst_dict:{"CUCellConfig": str(cu_cell_config_inst)}
#value:"\"{0}\"".format(cell_ids_str)
def create_ele(path, inst_dict, value = "0"):
    if isinstance(value, int):
        print(value)
    ele_p = g_root_ele
    path_list = path.strip(". ").split(".")
    for i in range(len(path_list)):
        node_name = path_list[i]
        if node_name == "{i}" or node_name == "1":
            continue
        if i + 1 < len(path_list) and path_list[i + 1] == "{i}":
            if inst_dict.get(node_name):
                targ_ele = ele_p.find("{node}{attr}".format(node = node_name, attr = '[@instance_id="%s"]'%inst_dict[node_name]))
                if targ_ele is not None:
                    ele_p = targ_ele
                else:
                    ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":inst_dict[node_name]})
            else:
                if ele_p.find(node_name) is not None:
                    instance_id = max([int(elem.get("instance_id", 0)) for elem in ele_p.findall(node_name)]) + 1
                else:
                    instance_id = 1
                ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":str(instance_id)})

        elif i + 1 < len(path_list) and path_list[i + 1] == "1":
            targ_ele = ele_p.find('{node}[@instance_id="1"]'.format(node = node_name,))
            if targ_ele is not None:
                ele_p = targ_ele
            else:
                ele_p = ET.SubElement(ele_p, node_name, attrib={"instance_id":"1"})
        else:
            targ_ele = ele_p.find(node_name)
            if targ_ele is not None:
                ele_p = targ_ele
            else:
                ele_p = ET.SubElement(ele_p, node_name)
        i = i + 1

    if path_list[-1] != "{i}" and path_list[-1] != "1":
        ele_p.text = value

def map_forward(value, map_table):
    return {key: val for key, val in [item.split('~') for item in map_table.split(',')]}[value]

def map_backward(value, map_table):
    return {val: key for key, val in [item.split('~') for item in map_table.split(',')]}[value]

def check_keys_exist(keys, dictionary):
    for key in keys:
        if key not in dictionary.keys():
            return False
    return True

def json2xml():
    cell_dict = g_json_dict.get("nrducell")
    if not cell_dict:
        return
    gnb_op_dict = g_json_dict.get("gnbdu-operator")
    if not gnb_op_dict:
        return
    for cell in cell_dict:
        if check_keys_exist(["dl-narfcn", "operator-id", "cellid", "slot", "nrducellid"], cell) is False:
            print("nrducell keys {0}".format(cell.keys()))
            continue
        bind_oper_id = int(cell["operator-id"])
        cellid = int(cell["cellid"])
        cell_slot = int(cell["slot"])
        cell_inst = int(cell["nrducellid"]) + 1 + (cell_slot - 1)*4
        for gnb_op in gnb_op_dict:
            if check_keys_exist(["operator-id", "gnbid", "gnbid-len", "slot", "plmnlist"], gnb_op) is False:
                print("gnbdu-operator keys {0}".format(gnb_op.keys()))
                continue
            operator_idx = int(gnb_op["operator-id"])
            operator_slot = int(gnb_op["slot"])
            if operator_idx == bind_oper_id and cell_slot == operator_slot:
                gnbid = int(gnb_op["gnbid"])
                gnbidlen = int(gnb_op["gnbid-len"])
                nci=cellid + gnbid * 2 ** (36 - gnbidlen)
                tac = int(cell["tac"])
                ranac = int(cell["ranac"])
                plmnlist = gnb_op["plmnlist"].strip(". ").split(".")
                create_ele("Device.Services.FAPService.1.CellConfig.{i}.NR.CN.TA.1.NrcellIdentity", {"CellConfig": str(cell_inst)}, str(nci))
                create_ele("Device.X_WWW-RUIJIE-COM-CN.Services.FAPService.1.CellConfig.{i}.NR.NGC.TA.1.BindGnbOpid", {"CellConfig": str(cell_inst)}, str(bind_oper_id))
                create_ele("Device.Services.FAPService.1.CellConfig.{i}.NR.CN.TA.1.TAC", {"CellConfig": str(cell_inst)}, str(tac))
                create_ele("Device.Services.FAPService.1.CellConfig.{i}.NR.CN.TA.1.Ranac", {"CellConfig": str(cell_inst)}, str(ranac))
                plmn_inst=0
                for plmnidx in plmnlist:
                    plmn_inst=plmn_inst+1
                    create_ele("Device.Services.FAPService.1.CellConfig.{i}.NR.CN.TA.1.PLMNList.{i}.PLMNID", {"CellConfig": str(cell_inst), "PLMNList": str(plmn_inst)}, plmnidx)

#基于输入的xml的根element以及实例号字典, 查找path所指节点的实例号列表或是节点值,返回是一个列表
def element_find(path, inst_dict):
    global g_root_ele

    dm_list = path.strip(".").split(".")
    ele = g_root_ele
    for i, dm_name in enumerate(dm_list):
        if dm_list[i] == "{i}" or dm_list[i] == "1":
            continue
        spec_inst = ""
        if len(dm_list) > i + 1:
            if dm_list[i + 1] == "{i}":
                inst = inst_dict[dm_name]
                spec_inst = "[@instance_id='{inst}']".format(inst = inst)
            elif dm_list[i + 1] == "1":
                spec_inst = "[@instance_id='1']"
        ele_list = ele.findall("{dm_name}{spec_inst}".format(dm_name = dm_name, spec_inst = spec_inst))
        if not ele_list:
            return []
        ele = ele_list[0]
    if "instance_id" in ele_list[0].attrib.keys():
        return [item.attrib["instance_id"] for item in ele_list]
    else:
        return [ele.text]

""" xml转json """
def xml2json():
    json_cfg_dict = {}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--operator', type=str, help='operator tag', required=True)
    parser.add_argument('--input', type=str, help='input config file(json or xml)', required=True)
    parser.add_argument('--out', type=str, help='output config file(json or xml)', required=True)
    args = parser.parse_args()

    if args.input.endswith(".json"):
        with io.open(args.input, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
        
        tree = ET.parse(args.out)
        g_root_ele = tree.getroot()
        json2xml()
        pretty_xml(g_root_ele)
        tree.write(args.out, encoding="utf-8", xml_declaration=True)
    elif args.input.endswith(".xml"):
        with io.open(args.out, 'r', encoding="utf-8") as f:
            json_data = f.read()
            g_json_dict = json.loads(json_data)
        xml_tree = ET.ElementTree(file = args.input)
        g_root_ele = xml_tree.getroot()
        xml2json()
        json_data = json.dumps(g_json_dict, indent=2)

