#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import xlrd
import argparse
import json
import re
import subprocess
import io
import os
import pdb

# 使用定制脚本做转换的MO
SPC_SCRP_CFG = [
    "interface","ipv4-address","ipv4-dhcp-client","ipv6-address","ipv6-dhcp-client", 
    "ipv6-address-autoconfig","vlan-interface", "nrcell-op", "device-name", "ipv4-route",
    "ipv6-route", "ipv4-route-blackhole"
]

SPE_MAP_CFG = ["nrducell.cellid", "nrducell.tac", "nrducell.ranac", "nrducell-op.cellid", 
    "nrducell-op.five-gs-tac", "nrducell-op.ranac", "nrducell-op.operator-id", "nrcell.cellid"
]

# 全定制脚本(工具转换后调用)
SPEC_SCRIPT = ["netmgmt.py", "nrcuoam_cu_cell_config_convert.py", "nrduoam_nrducell_cellid_convert.py", "nrduoam_cell_mocn_convert.py"]

# sheet页对应名称
MO_RELATION_SHEET = u"命令关系"
CFG_SHEETS = [u"平台", u"NRDU", u"LTE", u"PHY", u"FRM", u"NRCU"]
SCRIPT_SHEET = u"脚本参数"

# 起始行
MO_BEG_ROW = 2
PARAM_BEG_ROW = 2
SCRIPT_BEG_ROW = 2

# MO页面的属性对应列
MODULE_NAME = 0
MO_NAME = 1
MO_SUP_MO = 2
MO_DM = 6
MO_STARTUP = 7

# 参数页面的属性对应列
PARAM_MO = 3
PARAM_NAME = 4
PARAM_IS_KEY = 5
PARAM_DM = 15
PARAM_VALUE_MAP = 16
PARAM_SPEC_MAP = 17
CUCC_PARAM_DM = 18
CUCC_PARAM_VALUE_MAP = 19
CUCC_PARAM_SPEC_MAP = 20

JSON_INST_ID = "instance_id"
NA_TAG = "NA"

# 脚本参数sheet的属性对应列
SCRIPT_NAME = 1
SCRIPT_PARAMS = 2
SCRIPT_DM = 3
errlog_fd = open("/etc/json_trans_tool/map_script/cli_debug.log", "w")

# 测试是否符合XML的tag命名规则
def is_valid_tag(tag):
    pattern = r'^[a-zA-Z_][a-zA-Z0-9._-]*$'
    return re.match(pattern, tag) is not None

def err_print(string):
    print>>errlog_fd, (string)

class CfgNode:
    def __init__(self):
        self.is_multi = False   # 是否是多实例MO
        self.sub_cfg_dict = {}  # 子配置字典, 元素示例:{cfg_name:cfg_node, }
        self.dyn_dm_map = []    # 动态映射关系, 元素示例:[key_param_node, {key_val1:dm_node1, key_val2:dm_node2, ...}]
        self.dm_node_list = []  # 映射数据模型列表, 元素示例:[dm_node1, dm_node2, ]
        self.is_key = False     # 是否是key参数
        self.disable = False    # 是否在配置转换中被忽略(使用定制脚本的配置节点一般需要用这个属性, 让工具忽略转换)

    # 添加所映射的数据模型
    def add_map_dm_node(self, dm_node):
        self.dm_node_list.append(dm_node)

    # 获取当前的数据模型所动态映射的mo索引参数对象的键值对
    def get_dyn_key(self, dm_node):
        if not self.dyn_dm_map:
            return {}

        for key_val, dm in self.dyn_dm_map[1].items():
            if dm == dm_node:
                cur_key = {self.dyn_dm_map[0]:key_val, }
                return cur_key
        return None
    
    # 获取当前的JSON配置下所动态映射的数据模型对象
    def get_dyn_dm(self, cfg_dict):
        if not self.dyn_dm_map:
            return self.dm_node_list[0]
        key_param = self.dyn_dm_map[0]
        return self.dyn_dm_map[1][cfg_dict[key_param]]

class ParamNode(CfgNode):
    def __init__(self, attr_list, mo, param_value_map, param_spec_map):
        CfgNode.__init__(self)
        self.name = attr_list[PARAM_NAME].strip()
        self.sup_mo = mo    #参数对应的mo
        self.is_key = (self.__correct_key_attr() if attr_list[PARAM_IS_KEY].strip() == "yes" else False)
        self.sup_mo.add_sub_cfg(self)
        self.is_assemble = False    #是否是聚集映射mo参数对象
        self.__enable_enum_map(attr_list[param_value_map])
        self.__enable_special_map(attr_list[param_spec_map])
        self.__cfg_valid_check(attr_list)
        for map_name in SPE_MAP_CFG:
            map_mo = map_name.strip().split(".")[0]
            map_param = map_name.strip().split(".")[1]
            if mo.name == map_mo and map_param == self.name:
                self.disable = True
                break
        if not self.disable:
            self.disable = mo.disable

    # 修正key属性, 因为存在父子关系的mo不能拥有相同名称的key, 若子mo与父mo的某个key名相同则修正为非key
    def __correct_key_attr(self):
        
        mo_p = self.sup_mo
        while (mo_p is not None):
            for param in mo_p.sub_cfg_dict.values():
                if param.is_key == True and param.name == self.name:
                    return False
            mo_p = mo_p.sup_mo
        return True

    # 内部预配置校验
    def __cfg_valid_check(self, attr_list):
        # 校验索引标识是否合理
        if attr_list[PARAM_IS_KEY].strip() == attr_list[PARAM_NAME].strip() \
                and not self.sup_mo.sup_mo:
            err_print("MO[{}] 参数[{}] 索引标识不合理[{}], 该MO不存在父MO,".format(
                self.sup_mo.name, self.name, attr_list[PARAM_IS_KEY].strip()))
    
    # 获取当前上下文情况下, 该参数所映射的数据模型(主要为了处理动态映射的情况)
    def get_map_path(self, sup_dm_node = None):
        # 如果存在动态映射, 比较动态映射的数据模型中哪一个数据模型与入参父数据模型相吻合, 则返回对应的数据模型
        if self.dyn_dm_map:
            if sup_dm_node is None:
                return ""
            for dm in self.dyn_dm_map[1].values():
                if dm.sup_dm_node == sup_dm_node:
                    return dm.get_path()
        # 如果没有动态映射, 则对比映射数据模型列表, 同样比较父节点是否匹配, 并返回匹配的数据模型
        if len(self.dm_node_list) > 1 and sup_dm_node is not None:
            for dm in self.dm_node_list:
                if dm.sup_dm_node == sup_dm_node:
                    return dm.get_path()
        else:
            # (规避)无匹配的映射项目, 返回第一个映射数据模型
            return self.dm_node_list[0].get_path()

    # 生成双向的枚举映射函数
    def __enable_enum_map(self, val_map_disc):
        self.enum_xml2json_map = lambda x:x
        self.enum_json2xml_map = lambda x:x
        if not val_map_disc.strip() or val_map_disc.strip() == NA_TAG:
            return

        # 分别尝试构建正反枚举映射字典
        try:
            # 匹配类似 [enable~1,disable~0], 或者[ALL~"rsrp,rsrq,sinr",RSRQandSINR~"rsrq,sinr"]这种value中带了逗号关键字的, 用双引号括起来当作一个整体
            matches = re.findall(r'([\w-]+)~"((?:[^"]|\\")*)"|([\w-]+)~([^,"]+)', val_map_disc.strip())
            json2xml_map_dict = {}
            for match in matches:
                key = match[0] if match[0] else match[2]
                value = match[1] if match[1] else match[3]
                json2xml_map_dict[key] = value
        except:
            err_print("MO[{}] 参数[{}] 非法的值映射声明格式 [{}]".format(self.sup_mo.name, self.name, val_map_disc.encode('utf-8'), ))
            return
        xml2json_map_dict = {cwmp_val:cli_val for cli_val, cwmp_val in json2xml_map_dict.items()}
        
        # 定义参数的枚举映射方法
        def enum_xml2json_map(val):
            try:
                map_val = xml2json_map_dict[val]
            except KeyError:
                map_val = val
            return map_val
        def enum_json2xml_map(val):
            try:
                map_val = json2xml_map_dict[val]
            except KeyError:
                map_val = val
            return map_val

        self.enum_xml2json_map = enum_xml2json_map
        self.enum_json2xml_map = enum_json2xml_map
        
    # 用于生成参数对象的特殊映射方法
    def __enable_special_map(self, spec_param_map):
        self.special_xml2json_map = None
        self.special_json2xml_map = None
        self.assemble_xml2json_map = None
        self.assemble_json2xml_map = None

        if not spec_param_map.strip() or spec_param_map.strip() == NA_TAG:
            return

        #相等映射, 可以支持-[] ± offset的数字函数关系
        if spec_param_map.startswith("equal:"):
            try:
                """ 正则表达式匹配-[] ± offset格式的字符串, 并将结果用一个元组表示, 该元组固定4个元素, 分别是: """
                """ 前面的负号, 节点名, 运算符(＋或者-), 偏移量. 这四个元素只有节点名是一定会存在的, 其他元素不一定有"""
                match_list = re.findall(r'^(-?)(?:\[(.*?)\])?\s*?([+-]?)\s*?(\d*)$', spec_param_map[len("equal:"):])[0]
            except:
                err_print("MO[{}] 参数[{}] 非法的特殊映射声明格式 [{}]".format(self.sup_mo.name, self.name, spec_param_map))
                return
            sign = "-" if match_list[0] == "-" else ""
            dm_map_path = match_list[1].strip(".")
            if match_list[2] == "+":
                opr = "+"
                inv_opr = "+" if sign else "-"
            else:
                opr = "-"
                inv_opr = "-" if sign else "+"
            offset = match_list[3] or "0"

            def special_xml2json_map(dm_ele, inst_dict, sup_dm_node):
                find_path = dm_map_path
                if dm_map_path == "{i}":    # 等于本级多实例节点的实例号,例如eqaul:[{i}] + 1
                    find_path = sup_dm_node.get_path()
                # elif "." not in dm_map_path:    #等于本级mo下的节点
                #     find_path = sup_dm_node.sub_dm_node[dm_map_path].get_path()

                # 获取xml文件中对应节点的值或者实例号
                ele_val = element_find_val(dm_ele, inst_dict, find_path) or 1
                ele_val = ele_val or 1  # 错误规避, 默认赋值1
                # 利用equal公式算出目标值
                calc_val = str(eval("{sign}{ele_val}{opr}{offset}".format(sign = sign, ele_val = ele_val, opr = opr, offset = offset)))
                # 因为是转成json, 需要将计算后的结果做一个枚举映射
                val = self.enum_xml2json_map(calc_val)
                return {self:val}

            def special_json2xml_map(cfg_dict, key_dict):
                if dm_map_path == "{i}":    # 等于本级多实例节点的实例号,例如eqaul:[{i}] + 1
                    node = self.sup_mo.get_dyn_dm(dict(cfg_dict, **key_dict))
                else:
                    node = g_root_dm.find(dm_map_path)
                try:
                    # 从json转xml值, 需要先将枚举名转成枚举值, 再做后续计算
                    val = self.enum_json2xml_map(cfg_dict[self.name])
                    calc_val = str(eval("{sign}{key_val}{opr}{offset}".format(sign = sign, key_val = val, opr = inv_opr, offset = offset)))
                    return {node:calc_val}
                except:
                    return {node:""}

            self.special_xml2json_map = special_xml2json_map
            self.special_json2xml_map = special_json2xml_map
            if self.is_key:
                self.sup_mo.add_spec_key_map(self)
            else:
                self.sup_mo.add_spec_map(self)

        elif spec_param_map.startswith("script:"):
            map_list = spec_param_map[len("script:"):].split()
            script_name = map_list[0]
            dm_list = map_list[1:]
            param_list = [self.name, ]
            if g_script_dict.get(script_name):
                # 这里的用自适应的方式确定脚本的输入输出节点参数, 如果脚本sheet中没有写, 就按照特殊参数映射列中的来
                param_list = g_script_dict[script_name][0] or param_list
                dm_list = g_script_dict[script_name][1] or dm_list
            def special_xml2json_map(dm_ele, inst_dict, sup_dm_node):
                # popen执行的脚本入参
                script_exec = ['/etc/json_trans_tool/map_script/%s'%script_name, "0", g_operator_tag]
                for dm in dm_list:
                    find_path = dm
                    if dm == "{i}":    # 等于本级多实例节点的实例号,例如eqaul:[{i}] + 1
                        find_path = sup_dm_node.get_path()
                    ele_val = element_find_val(dm_ele, inst_dict, find_path)
                    ele_val = ele_val or 1  # 错误规避, 默认赋值1
                    script_exec.append(ele_val)
                try:
                    result = subprocess.Popen(script_exec, stdout=subprocess.PIPE)
                    if int(result.wait()):  # 等待脚本执行结果, 并判断是否为非0, 非0则不转换
                        return {}
                except:
                    err_print('/etc/json_trans_tool/map_script/{} 文件不存在'.format(script_name))
                    return {}
                # 输出以换行分隔, 所以需要用split by 换行, 用[:-1]切片是因为分隔后最后一个元素是一个空串, 需要去除
                return {self.sup_mo.sub_cfg_dict[item]:value for item, value in zip(param_list, result.stdout.read().strip().split('\n')[:-1])}

            def special_json2xml_map(cfg_dict, key_dict):
                dm_node_list = [g_root_dm.find(dm_path) for dm_path in dm_list]
                try:
                    item = ""
                    script_exec = ["/etc/json_trans_tool/map_script/%s"%script_name, "1", g_operator_tag] + [cfg_dict[item] for item in param_list]
                    result = subprocess.Popen(script_exec, stdout=subprocess.PIPE)
                    if int(result.wait()):
                        return {}
                except OSError as e:
                    err_print('映射脚本{} Error:{}'.format(script_name, e))
                    return {}
                except KeyError:
                    err_print("配置MO[{}] 参数[{}] 不存在于JSON文件中".format(self.sup_mo.name, item))
                    return {}

                resp_list = result.stdout.read().split("\n")[:-1]
                if len(resp_list) != len(dm_node_list):
                    return {}
                return {dm_node:val for dm_node, val in zip(dm_node_list, resp_list)}

            self.special_xml2json_map = special_xml2json_map
            self.special_json2xml_map = special_json2xml_map
            if self.is_key:
                self.sup_mo.add_spec_key_map(self)
            else:
                self.sup_mo.add_spec_map(self)

        # 聚集映射在xml转json时,将返回一个键值对, 其中键是mo类对象, 值是一个符合json配置文件格式的mo实例列表
        elif spec_param_map.startswith("assemble:"):
            map_list = spec_param_map[len("assemble:"):].split()
            separator = map_list[0].strip("[]")
            path = map_list[1]
            self.is_assemble = True

            def assemble_xml2json_map(dm_ele, inst_dict):
                assemble_val = element_find_val(dm_ele, inst_dict, path)
                return {self.sup_mo:[{self.name:item} for item in assemble_val.split(separator)]}

            def assemble_json2xml_map(cfg_dict):
                node = g_root_dm.find(path)
                cfg_list = cfg_dict[self.sup_mo.name]
                val_list = [item[self.name] for item in cfg_list if item.get(self.name)]
                if not val_list:
                    return {}
                # 这里用用户指定的分隔符拼接参数
                dm_val = '{}'.format(separator).join([item for item in val_list])
                return {node:dm_val}

            self.assemble_xml2json_map = assemble_xml2json_map
            self.assemble_json2xml_map = assemble_json2xml_map
            self.sup_mo.set_assemble_map(self)
        else:
            return


class MoNode(CfgNode):
    def __init__(self, attr_list, mo_dict):
        CfgNode.__init__(self)
        self.sub_cfg_dict = {}
        self.spec_map_nodes = []
        self.spec_key_map_nodes = []
        self.assemble_map_nodes = []
        self.name = attr_list[MO_NAME].strip()
        self.sup_mo = None
        sup_mo = attr_list[MO_SUP_MO].strip()
        if sup_mo and sup_mo != NA_TAG:
            if mo_dict.get(sup_mo) is None:
                err_print("MO[{}] 声明的父MO[{}] 未被定义在命令关系页中或被定义在此命令后面".format(self.name, sup_mo))
                return None
            self.sup_mo = mo_dict[sup_mo]
            self.sup_mo.add_sub_cfg(self)
        self.is_startup_mo = attr_list[MO_STARTUP].strip() == "Y"

        if self.name in SPC_SCRP_CFG:
            self.disable = True
    
    # 添加子配置(包括子mo或参数)
    def add_sub_cfg(self, cfg_node):
        if cfg_node.name in self.sub_cfg_dict:
            raise Exception("MO[{}] 的参数[{}] 被重复声明在参数维护表格中".format(self.name, cfg_node.name))
        self.sub_cfg_dict[cfg_node.name] = cfg_node
        if isinstance(cfg_node, ParamNode) and cfg_node.is_key:
            self.is_multi = True

    # 添加该mo特殊映射的索引参数
    def add_spec_key_map(self, cfg_node):
        self.spec_key_map_nodes.append(cfg_node)

    # 添加该mo特殊映射的参数
    def add_spec_map(self, cfg_node):
        self.spec_map_nodes.append(cfg_node)

    # 设置该mo的聚集映射参数
    def set_assemble_map(self, cfg_node):
        self.assemble_map_nodes.append(cfg_node)
    
    # 以mo结构配置字典作为输入, 获取当前上下文下, 该mo所映射的实例号字典
    def get_inst_dict(self, cfg_dict, key_dict):
        
        inst_dict = {}
        for node in self.spec_key_map_nodes:
            inst_dict.update({dm_node.name:val for dm_node, val in node.special_json2xml_map(cfg_dict, key_dict).items()})
        return inst_dict

    # 以根xml配置树作为输入, 获取当前上下文下, 该mo的索引参数
    def get_key_dict(self, dm_ele, inst_dict, dm_node):
        key_dict = {self.name:{}}
        dyn_key_dict = self.get_dyn_key(dm_node)
        if dyn_key_dict == None:
            return
        key_dict[self.name].update(dyn_key_dict)
        for node in [node for node in self.sub_cfg_dict.values() if node.is_key]:
            # 遍历所有索引参数, 如果有特殊映射则用特殊映射转换出key参数, 否则尝试枚举映射得出key参数
            if node in self.spec_key_map_nodes:
                value_dict = node.special_xml2json_map(dm_ele, inst_dict, dm_node)
                key_dict[self.name].update({node.name:val for node, val in value_dict.items()})
            elif node.dm_node_list:
                xml_value = element_find_val(dm_ele, inst_dict, node.get_map_path())
                value = node.enum_xml2json_map(xml_value)
                key_dict[self.name].update({node.name:value})
        return key_dict

class DmNode:
    def __init__(self, name, is_multi, cfg_node, sup_dm_node, is_leaf = False, is_sing_multi = False):
        self.sub_dm = {}
        self.name = name
        self.is_multi = is_multi            # 是否多实例节点标识(在这里固定单实例不算多实例)
        self.is_sing_multi = is_sing_multi  # 是否固定多实例, 只存在实例1
        self.is_leaf = is_leaf              # 修改后的叶子结点判断
        self.sup_dm_node = sup_dm_node      # 父节点
        self.cfg_node_list = []             # 映射的配置类对象
        self.sing_multi = []
        if cfg_node:
            if isinstance(cfg_node, ParamNode) and not self.is_leaf:
                return
            self.cfg_node_list.append(cfg_node)
            cfg_node.add_map_dm_node(self)
            self.is_leaf = isinstance(cfg_node, ParamNode)
    
    def add_map_cfg_node(self, cfg_node):
        if isinstance(cfg_node, ParamNode) and not self.is_leaf:
            return
        self.cfg_node_list.append(cfg_node)
        cfg_node.add_map_dm_node(self)

    def find(self, dm_path):
        dm_list = dm_path.replace(".{i}", " ").replace(".1", " ").replace(".", " ").split()
        node_p = self
        for dm in dm_list:
            try:
                node_p = node_p.sub_dm[dm]
            except KeyError:
                err_print("非法的节点声明:[{}]".format(dm_path))
                return None
        return node_p

    def get_path(self):
        node_p = self
        path = ""
        while (node_p.sup_dm_node != None):
            if node_p.is_multi:
                name = "{name}.{{i}}".format(name = node_p.name)
            elif node_p.is_sing_multi:
                name = "{name}.1".format(name = node_p.name)
            else:
                name = node_p.name
            path = "{name}.{path}".format(name = name, path = path)
            node_p = node_p.sup_dm_node
        return path

    # 逐级添加数据模型节点
    def add_sub_dm(self, dm, cfg_node):
        if not dm :
            return None

        parts = dm.split(".", 1)

        if not is_valid_tag(parts[0]):
            err_print("非法的节点名:[{}]".format(parts[0]))
            return None

        if len(parts) > 1:
            # 继续遍历
            if parts[1].startswith("{i}"):
                # 当前节点为多实例节点
                if parts[1] == "{i}":
                    # 遍历到尾端节点
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], True, cfg_node, self, is_leaf=True)
                    else:
                        self.sub_dm[parts[0]].add_map_cfg_node(cfg_node)
                else:
                    # 继续遍历
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], True, None, self)

                    self.sub_dm[parts[0]].add_sub_dm(parts[1][len("{i}."):], cfg_node)
            elif parts[1].startswith("1"):
                # 当前节点为固定1实例节点
                if parts[1] == "1":
                    # 遍历到尾端节点
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], False, cfg_node, self, is_leaf=True, is_sing_multi = True)
                    else:
                        self.sub_dm[parts[0]].add_map_cfg_node(cfg_node)
                    if not isinstance(cfg_node, ParamNode):
                        self.sub_dm[parts[0]].sing_multi.append(cfg_node.name)
                elif parts[1].startswith("1."):
                    # 继续遍历
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], False, None, self, is_sing_multi = True)
                    if not isinstance(cfg_node, ParamNode):
                        self.sub_dm[parts[0]].sing_multi.append(cfg_node.name)
                    self.sub_dm[parts[0]].add_sub_dm(parts[1][len("1."):], cfg_node)
                else:
                    # 考虑当前节点名以1开头, 继续遍历
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], False, None, self)

                    self.sub_dm[parts[0]].add_sub_dm(parts[1], cfg_node)
            else:
                # 继续遍历
                if not self.sub_dm.get(parts[0]):
                    self.sub_dm[parts[0]] = DmNode(parts[0], False, None, self)

                self.sub_dm[parts[0]].add_sub_dm(parts[1], cfg_node)
        else:
            # 遍历到数据模型末尾
            if not self.sub_dm.get(parts[0]):
                self.sub_dm[parts[0]] = DmNode(parts[0], False, cfg_node, self, is_leaf=True)
            else:
                self.sub_dm[parts[0]].add_map_cfg_node(cfg_node)

#mo_dict，startup_mo也是全局的
def parse_cfg_xls(xls_path, mo_dict, g_root_dm, g_script_dict, startup_mo):
    wb = xlrd.open_workbook(xls_path)

    # 获取所有脚本名-参数名-，sheet-脚本参数，DM表示数据模型
    #SCRIPT_PARAMS nrducell.nrducellid(可以有多个)
    script = wb.sheet_by_name(SCRIPT_SHEET)
    for row in range(SCRIPT_BEG_ROW, script.nrows):
        script_name = script.row_values(row)[SCRIPT_NAME].strip("script:").strip()
        params = [item.split(".")[-1] for item in script.row_values(row)[SCRIPT_PARAMS].strip().split()]
        dm_list = script.row_values(row)[SCRIPT_DM].strip().split()
        g_script_dict[script_name] = (params, dm_list)

    # MO_RELATION_SHEET sheet-命令关系
    mo_relation = wb.sheet_by_name(MO_RELATION_SHEET)
    for row in range(MO_BEG_ROW, mo_relation.nrows):
        if not mo_relation.row_values(row)[MO_NAME].strip() or mo_relation.row_values(row)[MO_NAME].strip() == NA_TAG:
            continue

        #MONode类初始化
        mo = MoNode(mo_relation.row_values(row), mo_dict)
        mo_dict[mo.name] = mo

        if mo.is_startup_mo and mo.name not in SPC_SCRP_CFG:
            startup_mo.update({mo.name:""})

        if not mo_relation.row_values(row)[MO_DM].strip() or mo_relation.row_values(row)[MO_DM].strip() == NA_TAG:
            continue
        # 注册映射数据模型
        for dm_map in mo_relation.row_values(row)[MO_DM].split():
            if ":" in dm_map:
                # 动态数据模型映射
                rel, dm = dm_map.split(":")
                rel_key, rel_val = rel.split("=")
                mo.dyn_dm_map = [rel_key, {}] if not mo.dyn_dm_map else mo.dyn_dm_map
                g_root_dm.add_sub_dm(dm.strip('.'), mo)
                mo.dyn_dm_map[1][rel_val] = g_root_dm.find(dm)
            else:
                g_root_dm.add_sub_dm(dm_map.strip('.'), mo)

    # 遍历各sheet页参数表
    for sheet in wb.sheets():
        if sheet.name not in CFG_SHEETS:
            continue

        for row in range(PARAM_BEG_ROW, sheet.nrows):
            param_dm = PARAM_DM
            param_value_map = PARAM_VALUE_MAP
            param_spec_map = PARAM_SPEC_MAP
            if g_operator_tag.upper() == "CUCC":
                if sheet.row_values(row)[CUCC_PARAM_DM].strip() != "SAME_CMCC" and sheet.row_values(row)[CUCC_PARAM_DM].strip() != "":
                    param_dm = CUCC_PARAM_DM
                else:
                    param_dm = PARAM_DM
                if sheet.row_values(row)[CUCC_PARAM_VALUE_MAP].strip() != "SAME_CMCC" and sheet.row_values(row)[CUCC_PARAM_VALUE_MAP].strip() != "":
                    param_value_map = CUCC_PARAM_VALUE_MAP
                else:
                    param_value_map = PARAM_VALUE_MAP
                if sheet.row_values(row)[CUCC_PARAM_SPEC_MAP].strip() != "SAME_CMCC" and sheet.row_values(row)[CUCC_PARAM_SPEC_MAP].strip() != "":
                    param_spec_map = CUCC_PARAM_SPEC_MAP
                else:
                    param_spec_map = PARAM_SPEC_MAP
            param_name = sheet.row_values(row)[PARAM_NAME].strip()
            param_mo_name = sheet.row_values(row)[PARAM_MO].strip()
            param_dm_map = sheet.row_values(row)[param_dm].strip()
            if not param_name or param_name == NA_TAG:
                continue
            if mo_dict.get(param_mo_name) is None:
                err_print("参数 [{}] 声明的MO[{}] 未被定义在命令关系页中或被定义在此命令后面".format(param_name, param_mo_name))
                continue
            try:
                param = ParamNode(sheet.row_values(row), mo_dict[param_mo_name], param_value_map, param_spec_map)
            except Exception as e:
                err_print(e)
                continue

            # 注册映射数据模型
            if not param_dm_map or param_dm_map == NA_TAG:
                continue
            for dm_map in param_dm_map.split():
                if ":" in dm_map:
                # 动态数据模型映射
                    rel, dm = dm_map.split(":")
                    rel_key, rel_val = rel.split("=")
                    param.dyn_dm_map = [rel_key, {}] if not param.dyn_dm_map else param.dyn_dm_map
                    
                    g_root_dm.add_sub_dm(dm, param)
                    param.dyn_dm_map[1][rel_val] = g_root_dm.find(dm)
                else:
                    g_root_dm.add_sub_dm(dm_map, param)

def json2CLI(mo_name, json_dict, key_assin):
    mo_obj = mo_dict[mo_name]
    oper_type = "add" if mo_obj.is_multi else "set"
    CLI_cmd_list = []
    CLI_cmd_head = "{} {} : {}".format(oper_type, mo_name, key_assin)
    param_assin = ""
    cur_key_assin = key_assin
    param_item = ""
    
    if isinstance(json_dict, list):
        for sub_dict in json_dict:
            param_assin = ""
            #表示MO的子实例个数
            mo_sub_inst_list = []
            # print(CLI_cmd_head)
            for key, value in sub_dict.items():
                #print("%s:%s, string:%s"%(key, value, sub_dict.items()))
                if not isinstance(value, dict) and not isinstance(value, list):
                    if value != "":
                        param_assin += " {}={}".format(key, value)
                        param_item = " {}={}".format(key, value)
                        if key not in mo_obj.sub_cfg_dict.keys():
                            err_print("mo_name:{0} key:{1} not in mo_obj.sub_cfg_dict:{2}".format(mo_name, key, mo_obj.sub_cfg_dict.keys()))
                        elif mo_obj.sub_cfg_dict[key].is_key:
                            if key not in cur_key_assin:
                                cur_key_assin += param_item
                                #print(param_assin)
                                #print(cur_key_assin)
                    else:
                        err_print("Empty string:%s, key:%s"%(CLI_cmd_head, key))
                else:
                    mo_sub_inst_list.append(key)
            CLI_cmd = CLI_cmd_head + param_assin
            CLI_cmd_list.append(CLI_cmd)
            # print("tmp_list:%s"%CLI_cmd_list)
            for mo in mo_sub_inst_list:
                items = dict(sub_dict.items())
                # print("mo:%s, mo_sub_inst_list:%s, items:%s, sub_dict:%s"%(mo, mo_sub_inst_list, items, sub_dict))
                #以nrducell -> nrducell-op为例：mo:nrducell-op 
                #item ---> {u'five-gs-tac': u'654', u'operator-id': u'1', u'ranac': u'234', u'cellid': u'3567'}
                for item in items[mo]:
                    # print("item:%s"%item)
                    CLI_cmd_list += json2CLI(mo, item, cur_key_assin)
    else:
        if isinstance(json_dict, dict):
            #表示MO的子实例个数
            mo_sub_inst_list = []
            for key, value in json_dict.items():
                #print("%s:%s, string:%s"%(key, value, json_dict.items()))
                if not isinstance(value, dict) and not isinstance(value, list):
                    if value != "":
                        param_assin += " {}={}".format(key, value)
                        param_item = " {}={}".format(key, value)
                        if key not in mo_obj.sub_cfg_dict.keys():
                            err_print("mo_name:{0} key:{1} not in mo_obj.sub_cfg_dict:{2}".format(mo_name, key, mo_obj.sub_cfg_dict.keys()))
                        elif mo_obj.sub_cfg_dict[key].is_key:
                            if key not in cur_key_assin:
                                cur_key_assin += param_item
                    else:
                        err_print("Empty string:%s, key:%s"%(CLI_cmd_head, key))
                else:
                    mo_sub_inst_list.append(key)
            CLI_cmd = CLI_cmd_head + param_assin
            CLI_cmd_list.append(CLI_cmd)
            # print(CLI_cmd_list)
            for mo in mo_sub_inst_list:
                CLI_cmd_list += json2CLI(mo, json_dict[mo], cur_key_assin)
        #else:
            #print("error start")
            #print(json_dict)
            #print("error end")

    #print("ret:%s"%CLI_cmd_list)
    
    return CLI_cmd_list

g_root_dm = DmNode("Config", False, None, None)
g_script_dict = {}
startup_mo = {}
mo_dict = {}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--xls', type=str, help='xls file', required=True)
    parser.add_argument('--operator', type=str, help='operator tag', required=True)
    parser.add_argument('--input', '-i', type=str, help='input config file(json or xml)', required=True)
    parser.add_argument('--out', '-o', type=str, help='output config file(json or xml)', required=True)
    args = parser.parse_args()

    g_operator_tag = args.operator
    if args.input.endswith(".json"):
        parse_cfg_xls(args.xls, mo_dict, g_root_dm, g_script_dict, startup_mo)

        with open(args.input, 'r') as f:
            json_data = f.read()
            base_json = json.loads(json_data)
        
        CLI_cmd_list = []
        #(u'ipv4-route', [{u'next-hop': u'172.27.113.1', u'dst-ipv4': u'0.0.0.0', u'mask': u'0'}]), 
        #(u'amfpool', [{u'amfip1': u'172.27.113.14', u'operator-id': u'4', u'amfid': u'15'}, 
        for mo_name, cfg in base_json.items():
            CLI_cmd_list += json2CLI(mo_name, cfg, "")
        with open(args.out, "w") as fd:
            for cli_list in CLI_cmd_list:
                if "gnbcu-operator :" in cli_list:
                    fd.write(cli_list)
                    fd.write("\n")
                if "gnbdu-operator :" in cli_list:
                    fd.write(cli_list)
                    fd.write("\n")
                if "add enb-operator :" in cli_list:
                    fd.write(cli_list)
                    fd.write("\n")
            for cli_list in CLI_cmd_list:
                if "add nrcell :" in cli_list:
                    fd.write(cli_list)
                    fd.write("\n")
            for cli_list in CLI_cmd_list:
                if "add nrducell :" in cli_list:
                    fd.write(cli_list)
                    fd.write("\n")
            for cli_list in CLI_cmd_list:
                if "add ltecell :" in cli_list:
                    fd.write(cli_list)
                    fd.write("\n")
            for cli_list in CLI_cmd_list:
                if "gnbdu-operator :" not in cli_list and "gnbcu-operator :" not in cli_list and "add enb-operator :" not in cli_list and "add nrcell :" not in cli_list and "add nrducell :" not in cli_list and "add ltecell :" not in cli_list:
                    fd.write(cli_list)
                    fd.write("\n")
        #with open(args.out, "w") as fd:
            #fd.write("\n".join(CLI_cmd_list))







