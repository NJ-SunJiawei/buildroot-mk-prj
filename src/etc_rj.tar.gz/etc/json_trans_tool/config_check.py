#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import xml.etree.ElementTree as ET
import json
import pdb
import argparse
import io
from config_trans import *

def recurse_xml(base_ele, check_ele, path):
    for ele in base_ele:
        if ele.attrib.has_key("instance_id"):
            xpath_tag = ele.tag + "[@instance_id='{}']".format(ele.attrib["instance_id"])
        else:
            xpath_tag = ele.tag
        tgt_ele = check_ele.find(xpath_tag)
        if tgt_ele is not None:
            if tgt_ele.text != ele.text:
                print("检查组值不相同[{}/{}]".format(path, xpath_tag))
            recurse_xml(ele, tgt_ele, "{}/{}".format(path, xpath_tag))
        else:
            print("检查组xml元素不存在[{}/{}]".format(path, xpath_tag))
            continue

def xml_check(base_file, check_file):
    base_tree = ET.ElementTree(file = base_file)
    base_root = base_tree.getroot()
    check_tree = ET.ElementTree(file = check_file)
    check_root = check_tree.getroot()

    recurse_xml(base_root, check_root, "")

def get_the_dict(mo_name, base_dict, check_list):
    for item in check_list:
        if all(item.get(x[0]) == x[1] for x in  [x for x in base_dict.items() if mo_dict[mo_name].sub_cfg_dict[x[0]].is_key]):
            return item
    return None
        

def recurse_json(base_json, check_json, json_path):
    for key, value in base_json.items():
        if not check_json.has_key(key):
            if not isinstance(value, dict) and not isinstance(value, list):
                mo_name = json_path.split(":")[-1]

                # 若数据模型映射列表无数据, 代表该参数没有映射到任何数据模型, 转换过程中丢失也正常
                if mo_dict[mo_name].sub_cfg_dict[key].dm_node_list:
                    print("检查组 [{}:{}] 配置不存在".format(json_path, key))
            else:
                print("检查组 [{}:{}] 配置不存在".format(json_path, key))
            continue
        if isinstance(value, dict):
            if not isinstance(check_json[key], dict):
                print("[{}:{}] 配置类型不匹配".format(json_path, key))
                continue
            recurse_json(value, check_json[key], "{}:{}".format(json_path, key))
        elif isinstance(value, list):
            if not isinstance(check_json[key], list):
                print("[{}:{}] 配置类型不匹配".format(json_path, key))
                continue
            # if key == "rru-lte-groupeqm":
            #     pdb.set_trace()
            for item in value:
                check_dict = get_the_dict(key, item, check_json[key])
                if not check_dict:
                    print("检查组list [{}:{}] 配置不存在".format(json_path, key))
                    continue
                recurse_json(item, check_dict, "{}:{}".format(json_path, key))
        else:
            if base_json[key] != check_json[key]:
                print("[{}:{}] 配置不匹配".format(json_path, key))


def json_check(base_file, check_file):
    with io.open(base_file, 'r', encoding="utf-8") as f:
        json_data = f.read()
        base_json = json.loads(json_data)
    with io.open(check_file, 'r', encoding="utf-8") as f:
        json_data = f.read()
        check_json = json.loads(json_data)
    recurse_json(base_json, check_json, "")


if __name__ == "__main__":
    errlog_fd = open("/etc/json_trans_tool/error.log", "w")
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--xls', '-x', type=str, help='xls file', required=True)
    parser.add_argument('--base', '-b', type=str, help='input config file(json or xml)')
    parser.add_argument('--check', '-c', type=str, help='output config file(json or xml)')
    parser.add_argument('--j2c', '-j', type=str, help='output config file(json or xml)')
    args = parser.parse_args()

    g_script_dict = {}
    mo_dict = {}
    g_root_dm = DmNode("Config", False, None, None)
    startup_mo = {}
    parse_cfg_xls(args.xls, mo_dict, g_root_dm, g_script_dict, startup_mo)

    if args.base.endswith(".xml"):
        xml_check(args.base, args.check)
    elif args.base.endswith(".json"):
        json_check(args.base, args.check)
    else:
        print("错误的文件名")
    