#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import csv
import argparse
import json
import re
import subprocess
import io
import os
import pdb
import sys
from collections import OrderedDict

# 使用定制脚本做转换的MO
SPC_SCRP_CFG = [
    "interface", "ipv4-address", "ipv4-dhcp-client", "ipv6-address", "ipv6-dhcp-client", 
    "ipv6-address-autoconfig", "vlan-interface", "nrcell-op", "device-name", "ipv4-route",
    "ipv6-route", "ipv4-route-blackhole"
]

SPE_MAP_CFG = ["nrducell.cellid", "nrducell.tac", "nrducell.ranac", "nrducell-op.cellid", 
    "nrducell-op.five-gs-tac", "nrducell-op.ranac", "nrducell-op.operator-id", "nrcell.cellid"
]

# 全定制脚本(工具转换后调用)
SPEC_SCRIPT = ["netmgmt.py", "nrcuoam_cu_cell_config_convert.py", "nrduoam_nrducell_cellid_convert.py", "nrduoam_cell_mocn_convert.py"]

# sheet页对应名称
MO_RELATION_SHEET = "命令关系"
CFG_SHEETS = ["平台", "NRDU", "LTE", "PHY", "FRM", "NRCU"]
SCRIPT_SHEET = "脚本参数"

# 起始行
MO_BEG_ROW = 2
PARAM_BEG_ROW = 2
SCRIPT_BEG_ROW = 2

# MO页面的属性对应列
MODULE_NAME = 0
MO_NAME = 1
MO_SUP_MO = 2
MO_DM = 6
MO_STARTUP = 7

# 参数页面的属性对应列
PARAM_MO = 3
PARAM_NAME = 4
PARAM_IS_KEY = 5
PARAM_DM = 15
PARAM_VALUE_MAP = 16
PARAM_SPEC_MAP = 17
CUCC_PARAM_DM = 18
CUCC_PARAM_VALUE_MAP = 19
CUCC_PARAM_SPEC_MAP = 20

JSON_INST_ID = "instance_id"
NA_TAG = "NA"

# 脚本参数sheet的属性对应列
SCRIPT_NAME = 1
SCRIPT_PARAMS = 2
SCRIPT_DM = 3
errlog_fd = open("/etc/json_trans_tool/map_script/error.log", "w")


# 测试是否符合XML的tag命名规则
def is_valid_tag(tag):
    pattern = r'^[a-zA-Z0-9_][a-zA-Z0-9._-]*'
    return re.match(pattern, tag) is not None


def err_print(string):
    print>>errlog_fd, (string)


# 用于美化xml文件, 增强可读性, 入参indent决定父子tag的缩进
def pretty_xml(element, indent="   ", newline="\n", level=0):  # elemnt为传进来的Elment类, 参数indent用于缩进, newline用于换行
    if element != None:  # 判断element是否有子元素
        if ((element.text is None) or element.text.isspace()) and list(element):  # 如果element的text没有内容
            element.text = newline + indent * (level + 1)
    temp = list(element)  # 将element转成list
    for subelement in temp:
        if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素, 说明下一个行是同级别元素的起始, 缩进应一致
            subelement.tail = newline + indent * (level + 1)
        else:  # 如果是list的最后一个元素,  说明下一行是母元素的结束, 缩进应该少一个    
            subelement.tail = newline + indent * level
        pretty_xml(subelement, level=level + 1)  # 对子元素进行递归操作


# 基于输入的xml的根element以及实例号字典, 查找path所指节点在xml中的实例号或值
def element_find_val(root_ele, inst_dict, path):
    dm_list = path.strip(".").split(".")
    ele = root_ele
    for i, dm_name in enumerate(dm_list):
        if dm_list[i] == "{i}" or dm_list[i] == "1":
            continue
        spec_inst = ""
        if len(dm_list) > i + 1:
            try:
                dm_node = g_root_dm.find(".".join(dm_list[:i+1]))
                if dm_list[i + 1] == "1" or dm_node.is_sing_multi:
                    spec_inst = "[@instance_id='1']"
                elif dm_list[i + 1] == "{i}":
                    inst = inst_dict[dm_name]
                    spec_inst = "[@instance_id='{inst}']".format(inst = inst)
            except KeyError:
                err_print("Error: {func} , i = {i}, dm_name = {dm_name}, inst_dict = {inst_dict}".format(
                    func = __name__, i = i, dm_name = dm_name, inst_dict = inst_dict))
        ele = ele.find("{dm_name}{spec_inst}".format(dm_name = dm_name, spec_inst = spec_inst))
        if ele is None:
            err_print("Error: {func}, ele not finded:i = {i}, dm_name = {dm_name}, inst_dict = {inst_dict}".format(
                func = __name__, i = i, dm_name = dm_name, inst_dict = inst_dict))
            return ""

    if dm_list[-1] == "{i}" or dm_list[-1] == "1":
        return ele.attrib["instance_id"]
    else:
        return ele.text


def find_root_mo(cfg_node):
    ret = cfg_node
    if cfg_node.sup_mo:
        ret = find_root_mo(cfg_node.sup_mo)
    else :
        ret = cfg_node
    return ret


class CfgNode:
    def __init__(self):
        self.is_multi = False   # 是否是多实例MO
        self.sub_cfg_dict = {}  # 子配置字典, 元素示例:{cfg_name:cfg_node, }
        self.dyn_dm_map = []    # 动态映射关系, 元素示例:[key_param_node, {key_val1:dm_node1, key_val2:dm_node2, ...}]
        self.dm_node_list = []  # 映射数据模型列表, 元素示例:[dm_node1, dm_node2, ]
        self.is_key = False     # 是否是key参数
        self.disable = False    # 是否在配置转换中被忽略(使用定制脚本的配置节点一般需要用这个属性, 让工具忽略转换)

    # 添加所映射的数据模型
    def add_map_dm_node(self, dm_node):
        self.dm_node_list.append(dm_node)

    # 获取当前的数据模型所动态映射的mo索引参数对象的键值对
    def get_dyn_key(self, dm_node):
        if not self.dyn_dm_map:
            return {}

        for key_val, dm in self.dyn_dm_map[1].items():
            if dm == dm_node:
                cur_key = {self.dyn_dm_map[0]:key_val, }
                return cur_key
        return None
    
    # 获取当前的JSON配置下所动态映射的数据模型对象
    def get_dyn_dm(self, cfg_dict):
        if not self.dyn_dm_map:
            return self.dm_node_list[0]
        key_param = self.dyn_dm_map[0]
        return self.dyn_dm_map[1][cfg_dict[key_param]]


class ParamNode(CfgNode):
    def __init__(self, attr_list, mo, param_value_map, param_spec_map):
        CfgNode.__init__(self)
        self.name = attr_list[PARAM_NAME].strip()
        self.sup_mo = mo    #参数对应的mo
        self.is_key = (self.__correct_key_attr() if attr_list[PARAM_IS_KEY].strip() == "yes" else False)
        self.sup_mo.add_sub_cfg(self)
        self.is_assemble = False    #是否是聚集映射mo参数对象
        self.__enable_enum_map(attr_list[param_value_map])
        self.__enable_special_map(attr_list[param_spec_map])
        self.__cfg_valid_check(attr_list)
        for map_name in SPE_MAP_CFG:
            map_mo = map_name.strip().split(".")[0]
            map_param = map_name.strip().split(".")[1]
            if mo.name == map_mo and map_param == self.name:
                self.disable = True
                break
        if not self.disable:
            self.disable = mo.disable

    # 修正key属性, 因为存在父子关系的mo不能拥有相同名称的key, 若子mo与父mo的某个key名相同则修正为非key
    def __correct_key_attr(self):
        
        mo_p = self.sup_mo
        while (mo_p is not None):
            for param in mo_p.sub_cfg_dict.values():
                if param.is_key == True and param.name == self.name:
                    return False
            mo_p = mo_p.sup_mo
        return True

    # 内部预配置校验
    def __cfg_valid_check(self, attr_list):
        # 校验索引标识是否合理
        if attr_list[PARAM_IS_KEY].strip() == attr_list[PARAM_NAME].strip() \
                and not self.sup_mo.sup_mo:
            err_print("MO[{}] 参数[{}] 索引标识不合理[{}], 该MO不存在父MO,".format(
                self.sup_mo.name, self.name, attr_list[PARAM_IS_KEY].strip()))
    
    # 获取当前上下文情况下, 该参数所映射的数据模型(主要为了处理动态映射的情况)
    def get_map_path(self, sup_dm_node = None):
        # 如果存在动态映射, 比较动态映射的数据模型中哪一个数据模型与入参父数据模型相吻合, 则返回对应的数据模型
        if self.dyn_dm_map:
            if sup_dm_node is None:
                return ""
            for dm in self.dyn_dm_map[1].values():
                if dm.sup_dm_node == sup_dm_node:
                    return dm.get_path()
        # 如果没有动态映射, 则对比映射数据模型列表, 同样比较父节点是否匹配, 并返回匹配的数据模型
        if len(self.dm_node_list) > 1 and sup_dm_node is not None:
            for dm in self.dm_node_list:
                if dm.sup_dm_node == sup_dm_node:
                    return dm.get_path()
        else:
            # (规避)无匹配的映射项目, 返回第一个映射数据模型
            return self.dm_node_list[0].get_path()

    # 生成双向的枚举映射函数
    def __enable_enum_map(self, val_map_disc):
        self.enum_xml2json_map = lambda x:x
        self.enum_json2xml_map = lambda x:x
        if not val_map_disc.strip() or val_map_disc.strip() == NA_TAG:
            return

        # 分别尝试构建正反枚举映射字典
        try:
            # 匹配类似 [enable~1,disable~0], 或者[ALL~"rsrp,rsrq,sinr",RSRQandSINR~"rsrq,sinr"]这种value中带了逗号关键字的, 用双引号括起来当作一个整体
            matches = re.findall(r'([\w-]+)~"((?:[^"]|\\")*)"|([\w-]+)~([^,"]+)', val_map_disc.strip())
            json2xml_map_dict = {}
            for match in matches:
                key = match[0] if match[0] else match[2]
                value = match[1] if match[1] else match[3]
                json2xml_map_dict[key] = value
        except:
            err_print("MO[{}] 参数[{}] 非法的值映射声明格式 [{}]".format(self.sup_mo.name, self.name, val_map_disc.encode('utf-8'), ))
            return
        xml2json_map_dict = {cwmp_val:cli_val for cli_val, cwmp_val in json2xml_map_dict.items()}
        
        # 定义参数的枚举映射方法
        def enum_xml2json_map(val):
            try:
                map_val = xml2json_map_dict[val]
            except KeyError:
                map_val = val
            return map_val
        def enum_json2xml_map(val):
            try:
                map_val = json2xml_map_dict[val]
            except KeyError:
                map_val = val
            return map_val

        self.enum_xml2json_map = enum_xml2json_map
        self.enum_json2xml_map = enum_json2xml_map
        
    # 用于生成参数对象的特殊映射方法
    def __enable_special_map(self, spec_param_map):
        self.special_xml2json_map = None
        self.special_json2xml_map = None
        self.assemble_xml2json_map = None
        self.assemble_json2xml_map = None

        if not spec_param_map.strip() or spec_param_map.strip() == NA_TAG:
            return

        #相等映射, 可以支持-[] ± offset的数字函数关系
        if spec_param_map.startswith("equal:"):
            try:
                """ 正则表达式匹配-[] ± offset格式的字符串, 并将结果用一个元组表示, 该元组固定4个元素, 分别是: """
                """ 前面的负号, 节点名, 运算符(＋或者-), 偏移量. 这四个元素只有节点名是一定会存在的, 其他元素不一定有"""
                match_list = re.findall(r'^(-?)(?:\[(.*?)\])?\s*?([+-]?)\s*?(\d*)$', spec_param_map[len("equal:"):])[0]
            except:
                err_print("MO[{}] 参数[{}] 非法的特殊映射声明格式 [{}]".format(self.sup_mo.name, self.name, spec_param_map))
                return
            sign = "-" if match_list[0] == "-" else ""
            dm_map_path = match_list[1].strip(".")
            if match_list[2] == "+":
                opr = "+"
                inv_opr = "+" if sign else "-"
            else:
                opr = "-"
                inv_opr = "-" if sign else "+"
            offset = match_list[3] or "0"

            def special_xml2json_map(dm_ele, inst_dict, sup_dm_node):
                find_path = dm_map_path
                if dm_map_path == "{i}":    # 等于本级多实例节点的实例号,例如eqaul:[{i}] + 1
                    find_path = sup_dm_node.get_path()
                # elif "." not in dm_map_path:    #等于本级mo下的节点
                #     find_path = sup_dm_node.sub_dm_node[dm_map_path].get_path()

                # 获取xml文件中对应节点的值或者实例号
                ele_val = element_find_val(dm_ele, inst_dict, find_path) or 1
                ele_val = ele_val or 1  # 错误规避, 默认赋值1
                # 利用equal公式算出目标值
                calc_val = str(eval("{sign}{ele_val}{opr}{offset}".format(sign = sign, ele_val = ele_val, opr = opr, offset = offset)))
                # 因为是转成json, 需要将计算后的结果做一个枚举映射
                val = self.enum_xml2json_map(calc_val)
                return {self:val}

            def special_json2xml_map(cfg_dict, key_dict):
                if dm_map_path == "{i}":    # 等于本级多实例节点的实例号,例如eqaul:[{i}] + 1
                    node = self.sup_mo.get_dyn_dm(dict(cfg_dict, **key_dict))
                else:
                    node = g_root_dm.find(dm_map_path)
                try:
                    # 从json转xml值, 需要先将枚举名转成枚举值, 再做后续计算
                    val = self.enum_json2xml_map(cfg_dict[self.name])
                    calc_val = str(eval("{sign}{key_val}{opr}{offset}".format(sign = sign, key_val = val, opr = inv_opr, offset = offset)))
                    return {node:calc_val}
                except:
                    return {node:""}

            self.special_xml2json_map = special_xml2json_map
            self.special_json2xml_map = special_json2xml_map
            if self.is_key:
                self.sup_mo.add_spec_key_map(self)
            else:
                self.sup_mo.add_spec_map(self)

        elif spec_param_map.startswith("script:"):
            map_list = spec_param_map[len("script:"):].split()
            script_name = map_list[0]
            dm_list = map_list[1:]
            param_list = [self.name, ]
            if g_script_dict.get(script_name):
                # 这里的用自适应的方式确定脚本的输入输出节点参数, 如果脚本sheet中没有写, 就按照特殊参数映射列中的来
                param_list = g_script_dict[script_name][0] or param_list
                dm_list = g_script_dict[script_name][1] or dm_list
            def special_xml2json_map(dm_ele, inst_dict, sup_dm_node):
                # popen执行的脚本入参
                script_exec = ['/etc/json_trans_tool/map_script/%s'%script_name, "0", g_operator_tag]
                for dm in dm_list:
                    find_path = dm
                    if dm == "{i}":    # 等于本级多实例节点的实例号,例如eqaul:[{i}] + 1
                        find_path = sup_dm_node.get_path()
                    ele_val = element_find_val(dm_ele, inst_dict, find_path)
                    ele_val = ele_val or 1  # 错误规避, 默认赋值1
                    script_exec.append(ele_val)
                try:
                    result = subprocess.Popen(script_exec, stdout=subprocess.PIPE)
                    if int(result.wait()):  # 等待脚本执行结果, 并判断是否为非0, 非0则不转换
                        return {}
                except:
                    err_print('/etc/json_trans_tool/map_script/{} 文件不存在'.format(script_name))
                    return {}
                # 输出以换行分隔, 所以需要用split by 换行, 用[:-1]切片是因为分隔后最后一个元素是一个空串, 需要去除
                return {self.sup_mo.sub_cfg_dict[item]:value for item, value in zip(param_list, result.stdout.read().strip().split('\n')[:-1])}

            def special_json2xml_map(cfg_dict, key_dict):
                dm_node_list = [g_root_dm.find(dm_path) for dm_path in dm_list]
                try:
                    item = ""
                    script_exec = ["/etc/json_trans_tool/map_script/%s"%script_name, "1", g_operator_tag] + [cfg_dict[item] for item in param_list]
                    result = subprocess.Popen(script_exec, stdout=subprocess.PIPE)
                    if int(result.wait()):
                        return {}
                except OSError as e:
                    err_print('映射脚本{} Error:{}'.format(script_name, e))
                    return {}
                except KeyError:
                    err_print("配置MO[{}] 参数[{}] 不存在于JSON文件中".format(self.sup_mo.name, item))
                    return {}

                resp_list = result.stdout.read().split("\n")[:-1]
                if len(resp_list) != len(dm_node_list):
                    return {}
                return {dm_node:val for dm_node, val in zip(dm_node_list, resp_list)}

            self.special_xml2json_map = special_xml2json_map
            self.special_json2xml_map = special_json2xml_map
            if self.is_key:
                self.sup_mo.add_spec_key_map(self)
            else:
                self.sup_mo.add_spec_map(self)

        # 聚集映射在xml转json时,将返回一个键值对, 其中键是mo类对象, 值是一个符合json配置文件格式的mo实例列表
        elif spec_param_map.startswith("assemble:"):
            map_list = spec_param_map[len("assemble:"):].split()
            separator = map_list[0].strip("[]")
            path = map_list[1]
            self.is_assemble = True

            def assemble_xml2json_map(dm_ele, inst_dict):
                assemble_val = element_find_val(dm_ele, inst_dict, path)
                return {self.sup_mo:[{self.name:item} for item in assemble_val.split(separator)]}

            def assemble_json2xml_map(cfg_dict):
                node = g_root_dm.find(path)
                cfg_list = cfg_dict[self.sup_mo.name]
                val_list = [item[self.name] for item in cfg_list if item.get(self.name)]
                if not val_list:
                    return {}
                # 这里用用户指定的分隔符拼接参数
                dm_val = '{}'.format(separator).join([item for item in val_list])
                return {node:dm_val}

            self.assemble_xml2json_map = assemble_xml2json_map
            self.assemble_json2xml_map = assemble_json2xml_map
            self.sup_mo.set_assemble_map(self)
        else:
            return


class MoNode(CfgNode):
    def __init__(self, attr_list, mo_dict):
        CfgNode.__init__(self)
        self.sub_cfg_dict = {}
        self.spec_map_nodes = []
        self.spec_key_map_nodes = []
        self.assemble_map_nodes = []
        self.name = attr_list[MO_NAME].strip()
        self.sup_mo = None
        sup_mo = attr_list[MO_SUP_MO].strip()
        if sup_mo and sup_mo != NA_TAG:
            if mo_dict.get(sup_mo) is None:
                err_print("MO[{}] 声明的父MO[{}] 未被定义在命令关系页中或被定义在此命令后面".format(self.name, sup_mo))
                return None
            self.sup_mo = mo_dict[sup_mo]
            self.sup_mo.add_sub_cfg(self)
        self.is_startup_mo = attr_list[MO_STARTUP].strip() == "Y"

        if self.name in SPC_SCRP_CFG:
            self.disable = True

    # 添加子配置(包括子mo或参数)
    def add_sub_cfg(self, cfg_node):
        if cfg_node.name in self.sub_cfg_dict:
            raise Exception("MO[{}] 的参数[{}] 被重复声明在参数维护表格中".format(self.name, cfg_node.name))
        self.sub_cfg_dict[cfg_node.name] = cfg_node
        if isinstance(cfg_node, ParamNode) and cfg_node.is_key:
            self.is_multi = True

    # 添加该mo特殊映射的索引参数
    def add_spec_key_map(self, cfg_node):
        self.spec_key_map_nodes.append(cfg_node)

    # 添加该mo特殊映射的参数
    def add_spec_map(self, cfg_node):
        self.spec_map_nodes.append(cfg_node)

    # 设置该mo的聚集映射参数
    def set_assemble_map(self, cfg_node):
        self.assemble_map_nodes.append(cfg_node)
    
    # 以mo结构配置字典作为输入, 获取当前上下文下, 该mo所映射的实例号字典
    def get_inst_dict(self, cfg_dict, key_dict):
        
        inst_dict = {}
        for node in self.spec_key_map_nodes:
            inst_dict.update({dm_node.name:val for dm_node, val in node.special_json2xml_map(cfg_dict, key_dict).items()})
        return inst_dict

    # 以根xml配置树作为输入, 获取当前上下文下, 该mo的索引参数
    def get_key_dict(self, dm_ele, inst_dict, dm_node):
        key_dict = {self.name:{}}
        dyn_key_dict = self.get_dyn_key(dm_node)
        if dyn_key_dict == None:
            return
        key_dict[self.name].update(dyn_key_dict)
        for node in [node for node in self.sub_cfg_dict.values() if node.is_key]:
            # 遍历所有索引参数, 如果有特殊映射则用特殊映射转换出key参数, 否则尝试枚举映射得出key参数
            if node in self.spec_key_map_nodes:
                value_dict = node.special_xml2json_map(dm_ele, inst_dict, dm_node)
                key_dict[self.name].update({node.name:val for node, val in value_dict.items()})
            elif node.dm_node_list:
                xml_value = element_find_val(dm_ele, inst_dict, node.get_map_path())
                value = node.enum_xml2json_map(xml_value)
                key_dict[self.name].update({node.name:value})
        return key_dict


class DmNode:
    def __init__(self, name, is_multi, cfg_node, sup_dm_node, is_leaf = False, is_sing_multi = False):
        self.sub_dm = {}
        self.name = name
        self.is_multi = is_multi            # 是否多实例节点标识(在这里固定单实例不算多实例)
        self.is_sing_multi = is_sing_multi  # 是否固定多实例, 只存在实例1
        self.is_leaf = is_leaf              # 修改后的叶子结点判断
        self.sup_dm_node = sup_dm_node      # 父节点
        self.cfg_node_list = []             # 映射的配置类对象
        self.sing_multi = []
        if cfg_node:
            if isinstance(cfg_node, ParamNode) and not self.is_leaf:
                return
            self.cfg_node_list.append(cfg_node)
            cfg_node.add_map_dm_node(self)
            self.is_leaf = isinstance(cfg_node, ParamNode)
    
    def add_map_cfg_node(self, cfg_node):
        if isinstance(cfg_node, ParamNode) and not self.is_leaf:
            return
        self.cfg_node_list.append(cfg_node)
        cfg_node.add_map_dm_node(self)

    def find(self, dm_path):
        dm_list = dm_path.replace(".{i}", " ").replace(".1", " ").replace(".", " ").split()
        node_p = self
        for dm in dm_list:
            try:
                node_p = node_p.sub_dm[dm]
            except KeyError:
                err_print("非法的节点声明:[{}]".format(dm_path))
                return None
        return node_p

    def get_path(self):
        node_p = self
        path = ""
        while (node_p.sup_dm_node != None):
            if node_p.is_multi:
                name = "{name}.{{i}}".format(name = node_p.name)
            elif node_p.is_sing_multi:
                name = "{name}.1".format(name = node_p.name)
            else:
                name = node_p.name
            path = "{name}.{path}".format(name = name, path = path)
            node_p = node_p.sup_dm_node
        return path

    # 逐级添加数据模型节点
    def add_sub_dm(self, dm, cfg_node):
        if not dm :
            return None

        parts = dm.split(".", 1)

        if not is_valid_tag(parts[0]):
            err_print("非法的节点名:[{}]".format(parts[0]))
            return None

        if len(parts) > 1:
            # 继续遍历
            if parts[1].startswith("{i}"):
                # 当前节点为多实例节点
                if parts[1] == "{i}":
                    # 遍历到尾端节点
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], True, cfg_node, self, is_leaf=True)
                    else:
                        self.sub_dm[parts[0]].is_multi = True
                        self.sub_dm[parts[0]].add_map_cfg_node(cfg_node)
                else:
                    # 继续遍历
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], True, None, self)
                    self.sub_dm[parts[0]].is_multi = True
                    self.sub_dm[parts[0]].add_sub_dm(parts[1][len("{i}."):], cfg_node)
            elif parts[1].startswith("1"):
                # 当前节点为固定1实例节点
                if parts[1] == "1":
                    # 遍历到尾端节点
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], False, cfg_node, self, is_leaf=True, is_sing_multi = True)
                    else:
                        self.sub_dm[parts[0]].add_map_cfg_node(cfg_node)
                    if not isinstance(cfg_node, ParamNode):
                        self.sub_dm[parts[0]].sing_multi.append(cfg_node.name)
                elif parts[1].startswith("1."):
                    # 继续遍历
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], False, None, self, is_sing_multi = True)
                    if not isinstance(cfg_node, ParamNode):
                        self.sub_dm[parts[0]].sing_multi.append(cfg_node.name)
                    self.sub_dm[parts[0]].add_sub_dm(parts[1][len("1."):], cfg_node)
                else:
                    # 考虑当前节点名以1开头, 继续遍历
                    if not self.sub_dm.get(parts[0]):
                        self.sub_dm[parts[0]] = DmNode(parts[0], False, None, self)

                    self.sub_dm[parts[0]].add_sub_dm(parts[1], cfg_node)
            else:
                # 继续遍历
                if not self.sub_dm.get(parts[0]):
                    self.sub_dm[parts[0]] = DmNode(parts[0], False, None, self)

                self.sub_dm[parts[0]].add_sub_dm(parts[1], cfg_node)
        else:
            # 遍历到数据模型末尾
            if not self.sub_dm.get(parts[0]):
                self.sub_dm[parts[0]] = DmNode(parts[0], False, cfg_node, self, is_leaf=True)
            else:
                self.sub_dm[parts[0]].add_map_cfg_node(cfg_node)


#mo_dict，startup_mo也是全局的
def parse_cfg_csv(csv_path, mo_dict, g_root_dm, g_script_dict, startup_mo):
    # 获取所有脚本名-参数名-，sheet-脚本参数，DM表示数据模型
    #SCRIPT_PARAMS nrducell.nrducellid(可以有多个)
    csv_file = io.open(csv_path + '/' + SCRIPT_SHEET + '.csv', 'rb')
    reader = csv.reader(csv_file)
    data_list = list(reader)
    for row in range(SCRIPT_BEG_ROW, len(data_list)):
        script_name = data_list[row][SCRIPT_NAME].strip("script:").strip()
        params = [item.split(".")[-1] for item in data_list[row][SCRIPT_PARAMS].strip().split()]
        dm_list = data_list[row][SCRIPT_DM].strip().split()
        g_script_dict[script_name] = (params, dm_list)

    # MO_RELATION_SHEET sheet-命令关系
    csv_file = io.open(csv_path + '/' + MO_RELATION_SHEET + '.csv', 'rb')
    reader = csv.reader(csv_file)
    data_list = list(reader)
    for row in range(MO_BEG_ROW, len(data_list)):
        if not data_list[row][MO_NAME].strip() or data_list[row][MO_NAME].strip() == NA_TAG:
            continue

        #MONode类初始化
        mo = MoNode(data_list[row], mo_dict)
        mo_dict[mo.name] = mo

        if mo.is_startup_mo and mo.name not in SPC_SCRP_CFG:
            startup_mo.update({mo.name:""})

        if not data_list[row][MO_DM].strip() or data_list[row][MO_DM].strip() == NA_TAG:
            continue
        # 注册映射数据模型
        for dm_map in data_list[row][MO_DM].split():
            if ":" in dm_map:
                # 动态数据模型映射
                rel, dm = dm_map.split(":")
                rel_key, rel_val = rel.split("=")
                mo.dyn_dm_map = [rel_key, {}] if not mo.dyn_dm_map else mo.dyn_dm_map
                g_root_dm.add_sub_dm(dm.strip('.'), mo)
                mo.dyn_dm_map[1][rel_val] = g_root_dm.find(dm)
            else:
                g_root_dm.add_sub_dm(dm_map.strip('.'), mo)

    # 遍历各sheet页参数表
    for filename in os.listdir(csv_path):
        if filename.strip().split('.')[0] not in CFG_SHEETS:
            continue
        csv_file = io.open(csv_path + '/' + filename, 'rb')
        reader = csv.reader(csv_file)
        data_list = list(reader)
        for row in range(PARAM_BEG_ROW, len(data_list)):
            param_dm = PARAM_DM
            param_value_map = PARAM_VALUE_MAP
            param_spec_map = PARAM_SPEC_MAP
            if g_operator_tag.upper() == "CUCC":
                if data_list[row][CUCC_PARAM_DM].strip() != "SAME_CMCC" and data_list[row][CUCC_PARAM_DM].strip() != "":
                    param_dm = CUCC_PARAM_DM
                else:
                    param_dm = PARAM_DM
                if data_list[row][CUCC_PARAM_VALUE_MAP].strip() != "SAME_CMCC" and data_list[row][CUCC_PARAM_VALUE_MAP].strip() != "":
                    param_value_map = CUCC_PARAM_VALUE_MAP
                else:
                    param_value_map = PARAM_VALUE_MAP
                if data_list[row][CUCC_PARAM_SPEC_MAP].strip() != "SAME_CMCC" and data_list[row][CUCC_PARAM_SPEC_MAP].strip() != "":
                    param_spec_map = CUCC_PARAM_SPEC_MAP
                else:
                    param_spec_map = PARAM_SPEC_MAP
            param_name = data_list[row][PARAM_NAME].strip()
            param_mo_name = data_list[row][PARAM_MO].strip()
            param_dm_map = data_list[row][param_dm].strip()
            if not param_name or param_name == NA_TAG:
                continue
            if mo_dict.get(param_mo_name) is None:
                err_print("参数 [{}] 声明的MO[{}] 未被定义在命令关系页中或被定义在此命令后面".format(param_name, param_mo_name))
                continue
            try:
                param = ParamNode(data_list[row], mo_dict[param_mo_name], param_value_map, param_spec_map)
            except Exception as e:
                err_print(e)
                continue

            # 注册映射数据模型
            if not param_dm_map or param_dm_map == NA_TAG:
                continue
            for dm_map in param_dm_map.split():
                if ":" in dm_map:
                # 动态数据模型映射
                    rel, dm = dm_map.split(":")
                    rel_key, rel_val = rel.split("=")
                    param.dyn_dm_map = [rel_key, {}] if not param.dyn_dm_map else param.dyn_dm_map
                    
                    g_root_dm.add_sub_dm(dm, param)
                    param.dyn_dm_map[1][rel_val] = g_root_dm.find(dm)
                else:
                    g_root_dm.add_sub_dm(dm_map, param)


def recurse_add_json_item(cfg_node, json_dict, key_dict):
    json_p = recurse_add_json_item(cfg_node.sup_mo, json_dict, key_dict) if cfg_node.sup_mo else json_dict
    if json_p.get(cfg_node.name):
        if cfg_node.is_multi:
            for item in json_p[cfg_node.name]:
                if key_dict.get(cfg_node.name) and all((item[x] == y for x,y in key_dict[cfg_node.name].items())):
                    return item
                
            mo_dict = {key:val for key, val in key_dict[cfg_node.name].items()}
            json_p[cfg_node.name].append(mo_dict)
            return mo_dict
        else:
            return json_p[cfg_node.name]
    else:
        if cfg_node.is_multi:
            if not cfg_node.name in key_dict:
                return {}
            mo_list = []
            mo_dict = {key:val for key, val in key_dict[cfg_node.name].items()}
            mo_list.append(mo_dict)
            json_p[cfg_node.name] = mo_list
            return mo_dict
        else:
            mo_dict = {}
            json_p[cfg_node.name] = mo_dict
            return mo_dict


def add_json_item(dm_node, json_dict, key_dict, inst_dict, item_val):
    for cfg_node in dm_node.cfg_node_list:
        if cfg_node.disable:
            continue

        if isinstance(cfg_node, MoNode):
            # recurse_add_json_item(cfg_node, json_dict, key_dict)
            pass
        else:
            if not cfg_node.is_key and cfg_node.special_xml2json_map:
                cfg_node_dict = cfg_node.special_xml2json_map(g_root_ele, inst_dict, dm_node)
            elif cfg_node.assemble_xml2json_map:
                cfg_node_dict = cfg_node.assemble_xml2json_map(g_root_ele, inst_dict)
            else:
                target_value = cfg_node.enum_xml2json_map(item_val)
                cfg_node_dict = {cfg_node:target_value}

            if cfg_node.is_assemble:
                target_mo = cfg_node.sup_mo.sup_mo
            else:
                target_mo = cfg_node.sup_mo

            mo_dict = recurse_add_json_item(target_mo, json_dict, key_dict)
            mo_dict.update({node.name:value for node, value in cfg_node_dict.items()})


def xml_recurse(sup_ele, sup_dm_node, key_dict, inst_dict, json_dict):
    for ele in sup_ele:
        if not sup_dm_node.sub_dm.get(ele.tag):
            err_print("数据模型[{sup_path}{cur_path}] 未被定义在参数描述表格表格中".format(
                sup_path = sup_dm_node.get_path(), cur_path = ele.tag))
            continue
        dm_node = sup_dm_node.sub_dm[ele.tag]
        cur_inst = {}
        cur_key = {}

        if dm_node.is_multi and ele.attrib.get("instance_id"):
            cur_inst = {dm_node.name:ele.attrib["instance_id"]}
        for cfg_node in  dm_node.cfg_node_list:
            if not isinstance(cfg_node, MoNode):
                continue
            cur_key.update(cfg_node.get_key_dict(g_root_ele, dict(inst_dict, **cur_inst), dm_node))

        # （临时）为了解决某些mo父子关系与数据模型父子关系不一致的配置, 在遍历到子数据模型时父mo的key上下文丢失问题
        key_dict.update(cur_key)

        add_json_item(dm_node, json_dict, key_dict, dict(inst_dict, **cur_inst), ele.text or "")
        xml_recurse(ele, dm_node, dict(key_dict, **cur_key), dict(inst_dict, **cur_inst), json_dict)


def xml2json(xml_path, json_path):
    global g_root_ele
    xml_tree = ET.ElementTree(file = xml_path)
    root_ele = xml_tree.getroot()
    json_dict = {}
    key_dict = {}
    inst_dict = {}
    g_root_ele = root_ele
    xml_recurse(root_ele, g_root_dm, key_dict, inst_dict, json_dict)

    json_data = json.dumps(json_dict, indent=2)
    with io.open(json_path, "w", encoding="utf-8") as f:
        f.write(json_data)


# 对nr节点的单实例特殊映射
def is_sing_FAPService(cfg_node, dm_node):
    if dm_node.name == "FAPService":
        dm_str = dm_node.name
        tmp_dm = dm_node
        while(tmp_dm.sup_dm_node.name != g_root_dm.name):
            tmp_dm = tmp_dm.sup_dm_node
            dm_str = tmp_dm.name + "." + dm_str
        if dm_str == "Device.Services.FAPService" or dm_str == "Device.X_WWW-RUIJIE-COM-CN.Services.FAPService":
            if cfg_node.name not in dm_node.sing_multi:
                dm_node.sing_multi.append(cfg_node.name)


""" recurse_add_xml_item函数用于递归生成对应的xml元素, 通过输入目标数据模型对象以及实例号上下文, 生成对应的xml元素树 """
""" dm_node     :内部数据模型对象 """
""" root_ele    :目标xml树根 """
""" inst_dict   :实例号上下文字典 """
def recurse_add_xml_item(dm_node, root_ele, inst_dict, cfg_node):
    if dm_node.sup_dm_node is None:
        return root_ele

    # 递归
    ele = recurse_add_xml_item(dm_node.sup_dm_node, root_ele, inst_dict, cfg_node) if dm_node.sup_dm_node else root_ele
    root_mo = find_root_mo(cfg_node)
    is_sing_FAPService(root_mo, dm_node)
    if root_mo.name in dm_node.sing_multi or cfg_node.name in dm_node.sing_multi or (cfg_node.sup_mo and cfg_node.sup_mo.name in dm_node.sing_multi):
        inst_attr = {"instance_id":"1"}
        inst_spec = "[@instance_id='1']"
    elif dm_node.is_multi:
        if inst_dict.get(dm_node.name):
            instance_id = inst_dict[dm_node.name]
        elif ele.find(dm_node.name) is not None:
            instance_id = str(max([int(elem.get("instance_id", 0)) for elem in ele.findall(dm_node.name)]) + 1)
            inst_dict.update({dm_node.name:instance_id})
        else:
            instance_id = "1"
            inst_dict.update({dm_node.name:instance_id})
        inst_attr = {"instance_id":instance_id}
        inst_spec = "[@instance_id='{inst}']".format(inst = instance_id)
    else:
        inst_attr = {}
        inst_spec = ""

    ele_xpath = "{node_name}{inst_spec}".format(node_name = dm_node.name, inst_spec = inst_spec)
    if ele.find(ele_xpath) is not None:
        return ele.find(ele_xpath)
    else:
        # if dm_node.name == "FAPService":
        #     pdb.set_trace()
        return ET.SubElement(ele, dm_node.name, attrib = inst_attr)
    
""" add_xml_item函数用于处理json元素转换到xml元素的一些前置准备, 例如处理特殊转换关系, 和值映射关系等等 """
""" cfg_node        :是需要转换的内部配置对象 """
""" sup_cfg_dict    :是cfg_node的上级配置字典, 可以说是当前mo数据的下属元素字典数据, 其中的元素与cfg_node所代表的元素是同级的 """
""" inst_dict       :是当前遍历层级的实例号上下文信息, 是一个以多实例节点做key, 其实例号做value的字典 """
""" key_dict        :是当前遍历层级的索引参数上下文信息, 是一个以索引参数名做key, 其索引参数值做value的字典"""
""" cfg_val         :该参数的json数据值: """
def add_xml_item(cfg_node, sup_cfg_dict, inst_dict, key_dict, cfg_val):
    dm_node_dict = {}
    if isinstance(cfg_node, ParamNode):
        if not cfg_node.is_key and cfg_node.special_json2xml_map:
            dm_node_dict = cfg_node.special_json2xml_map(sup_cfg_dict, key_dict)
        else:
            target_val = cfg_node.enum_json2xml_map(cfg_val)
            dm_node_dict = {node:target_val for node in cfg_node.dm_node_list}
    else:
        if cfg_node.assemble_map_nodes:
            for item in cfg_node.assemble_map_nodes:
                dm_node_dict.update(item.assemble_json2xml_map(sup_cfg_dict))
        else:
            dm_node_dict = {dm:cfg_val for dm in cfg_node.dm_node_list}

    if cfg_node.dyn_dm_map:
        key_param = cfg_node.dyn_dm_map[0]
        try:
            dm_node = cfg_node.get_dyn_dm(dict(sup_cfg_dict, **key_dict))
            val = dm_node_dict[dm_node]
            dm_node_dict = {dm_node:val, }
        except KeyError:
            err_print("MO[{}] 参数[{}] 映射失败:{}".format(cfg_node.sup_mo.name or "", cfg_node.name, key_param))
    for dm_node, val in dm_node_dict.items():
        if not dm_node.is_leaf:
            recurse_add_xml_item(dm_node, g_root_ele, inst_dict, cfg_node)
        else:
            ele = recurse_add_xml_item(dm_node.sup_dm_node, g_root_ele, inst_dict, cfg_node)
            leaf_ele = ET.SubElement(ele, dm_node.name)
            leaf_ele.text = val


""" json_recurse函数用于递归遍历输入的json文件并对应转换成xml元素, 遍历json的同时会同步遍历内部的配置对象树, 从树中元素获取转换规则与属性来指导转换 """
""" sup_cfg_tup     :是输入JSON的的相对上级配置的数据, 两个元素的元组, 其中的内容格式是(上级mo名, 上级mo下的元素字典)"""
""" cfg_node_dict   :是上级MoNode类对象的子元素字典 """
""" inst_dict       :是当前遍历层级的实例号上下文信息, 是一个以多实例节点做key, 其实例号做value的字典 """
""" key_dict        :是当前遍历层级的索引参数上下文信息, 是一个以索引参数名做key, 其索引参数值做value的字典"""
def json_recurse(sup_cfg_tup, cfg_node_dict, inst_dict, key_dict):

    sup_cfg_mo = sup_cfg_tup[0]
    sup_cfg_dict = sup_cfg_tup[1]

    if not isinstance(sup_cfg_dict, dict):
        return 
    
    # 因为父子mo不能有相同名字的key参数, 直接并列存储key
    cur_key_dict = {k:v for k, v in key_dict.items()}

    # 预先将参数配置前置, 以保证遍历mo时key参数列表可用
    param_list_tup = [(key,val) for key, val in sup_cfg_dict.items() if not isinstance(val, list) and not isinstance(val, dict)]
    mo_list_tup = [(key,val) for key, val in sup_cfg_dict.items() if isinstance(val, list) or isinstance(val, dict)]
    global startup_mo
    # 提前把下一次进递归处理的 mo 从总的待处理mo列表中摘除
    map(lambda x:startup_mo.pop(x[0]) if x[0] in startup_mo else "", mo_list_tup)
    for cfg_name, cfg_data in param_list_tup + mo_list_tup:
        if cfg_name == JSON_INST_ID:
            continue
        if not cfg_node_dict.get(cfg_name):
            if isinstance(cfg_data, list) or isinstance(cfg_data, dict):    # 由于JSON文件中的字符串是unicode类所以无法用str类来判断
                err_print("JSON配置MO[{cur_layer}] 没有在参数管理表格中被定义".format(cur_layer = cfg_name))
            elif not (cur_key_dict.get(cfg_name) or sup_cfg_dict.get(cfg_name)):
                err_print("JSON配置MO[{}] 参数[{}] 没有在参数管理表格中被定义".format(sup_cfg_mo, cfg_name))
            continue
        cfg_node = cfg_node_dict[cfg_name]
        if cfg_node.disable:
            continue

        if isinstance(cfg_data, list):
            if not cfg_node.is_multi:
                err_print("MO[{cur_layer}] 在参数描述表格中未定义key参数标识多实例但在JSON中为多实例".format(cur_layer = cfg_name))
                continue
            if cfg_node.assemble_map_nodes:
                add_xml_item(cfg_node, sup_cfg_dict, inst_dict, cur_key_dict, None)
                continue

            for mo_dict in cfg_data:
                # 将所映射的多实例节点实例都带上
                cur_inst_dict = {k:v for k, v in inst_dict.items()}
                if cfg_node.spec_key_map_nodes:
                    cur_inst_dict.update(cfg_node.get_inst_dict(mo_dict, cur_key_dict))

                if cfg_node.name == "hub": 
                    merged_dict = {}
                    merged_dict.update(mo_dict)
                    merged_dict.update(cur_key_dict)
                    add_xml_item(cfg_node, merged_dict, cur_inst_dict, cur_key_dict, None)
                    json_recurse((cfg_name, merged_dict), cfg_node.sub_cfg_dict, cur_inst_dict, cur_key_dict)
                elif cfg_node.name == "rru":
                    merged_dict = {}
                    merged_dict.update({"phcn":cur_key_dict["phcn"]})
                    merged_dict.update(mo_dict)
                    add_xml_item(cfg_node, merged_dict, cur_inst_dict, cur_key_dict, None)
                    json_recurse((cfg_name, merged_dict), cfg_node.sub_cfg_dict, cur_inst_dict, cur_key_dict)
                elif cfg_node.name == "rru-groupeqm": 
                    merged_dict = {}
                    merged_dict.update(mo_dict)
                    merged_dict.update(cur_key_dict)
                    add_xml_item(cfg_node, merged_dict, cur_inst_dict, cur_key_dict, None)
                    json_recurse((cfg_name, merged_dict), cfg_node.sub_cfg_dict, cur_inst_dict, cur_key_dict)
                elif cfg_node.name == "rru-lte-groupeqm": 
                    merged_dict = {}
                    merged_dict.update(mo_dict)
                    merged_dict.update(cur_key_dict)
                    add_xml_item(cfg_node, merged_dict, cur_inst_dict, cur_key_dict, None)
                    json_recurse((cfg_name, merged_dict), cfg_node.sub_cfg_dict, cur_inst_dict, cur_key_dict)
                else :
                    add_xml_item(cfg_node, mo_dict, cur_inst_dict, cur_key_dict, None)
                    json_recurse((cfg_name, mo_dict), cfg_node.sub_cfg_dict, cur_inst_dict, cur_key_dict)
        else:
            if cfg_node.is_multi:
                err_print("MO[{cur_layer}] 在参数描述表格中定义了key参数但在JSON中为单实例样式".format(cur_layer = cfg_name))
                continue
            if cfg_node.is_key:
                cur_key_dict.update({cfg_name:cfg_data})

            # FRM 节点特殊处理 HPN 值 比json -1
            if cfg_node.name == "hpn":
                int_value = int(cfg_data)
                cfg_data = str(int_value - 1)

            add_xml_item(cfg_node, sup_cfg_dict, inst_dict, cur_key_dict, cfg_data)
            json_recurse((cfg_node.name, cfg_data), cfg_node.sub_cfg_dict, inst_dict, cur_key_dict)


def json2xml(json_path, xml_path):
    global g_root_ele
    with io.open(json_path, 'r', encoding="utf-8") as f:
        json_data = f.read()
        json_dict = json.loads(json_data, object_pairs_hook=OrderedDict)
    g_root_ele = ET.Element("Config")
    json_recurse(("", json_dict), mo_dict, OrderedDict({}), OrderedDict({}))
    pretty_xml(g_root_ele)
    ele_tree = ET.ElementTree(g_root_ele)
    ele_tree.write(xml_path, encoding="utf-8", xml_declaration=True)

g_root_dm = DmNode("Config", False, None, None)
g_script_dict = {}
startup_mo = {}
mo_dict = {}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--xls', type=str, help='csv directory', required=True)
    parser.add_argument('--operator', type=str, help='operator tag', required=True)
    parser.add_argument('--input', '-i', type=str, help='input config file(json or xml)', required=True)
    parser.add_argument('--out', '-o', type=str, help='output config file(json or xml)', required=True)
    args = parser.parse_args()

    g_operator_tag = args.operator

    g_root_ele = None
    g_root_json = {}

    parse_cfg_csv(args.xls.split('.')[0], mo_dict, g_root_dm, g_script_dict, startup_mo)
    if args.input.endswith(".xml"): #正向
        xml2json(args.input, args.out)
    elif args.input.endswith(".json"):
        json2xml(args.input, args.out)
        # 在转换过程中遇到start_mo这个字典里的表项, 会将该表项删除, 所以剩下来的表项就是json文件中漏写的的开站mo
        for item in startup_mo.keys():
            err_print("开站配置MO[{}]没有写在全量JSON文件中".format(item))
    else:
        raise Exception("输入配置文件后缀应为json or xml")

    for item in SPEC_SCRIPT:
        script_path = "/etc/json_trans_tool/spec_script/{}".format(item)
        if os.path.exists(script_path):
            script_exec = [script_path, "--operator", g_operator_tag, "--input", args.input, "--out", args.out]
            # 启动定制脚本进程
            process = subprocess.Popen(script_exec, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            # 读取定制脚本的输出和错误信息
            output, error = process.communicate()
            # 判断定制脚本执行是否失败
            if process.returncode != 0:
                # 将输出和错误信息转换为字符串
                output = output.decode()
                error = error.decode()
                print("定制脚本{}执行失败！".format(item))
                print(error)
                print(output)
                err_print(error)
                sys.exit(1)
        else:
            err_print("Can not find script {}!".format(script_path))
            sys.exit(1)
