#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
import sys
import os
import argparse

ROOT_TAG_NAME = "Config"

def foreach_xml(element, node, node_list):
    if element != None:
        # 有子元素无属性
        if len(element.getchildren()) and len(element.attrib) == 0:
            if str(element.tag) != ROOT_TAG_NAME:
                node += element.tag + '.'
        # 有属性
        elif len(element.attrib) != 0:
            node += element.tag + '.' + element.attrib['instance_id']
            #无子元素说明结束
            if len(element.getchildren()) == 0:
                node_list.append({'path': node, 'value': None})
                pass
            else:
                node += '.'
        #无子元素
        else:
            node += element.tag
            node_list.append({'path': node, 'value': element.text})
            node = ""
            pass
    # 将element转成list
    temp = list(element)
    for subelement in temp:
        # 对子元素进行递归操作
        foreach_xml(subelement, node, node_list)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='config file transform')
    parser.add_argument('--input', '-i', type=str, help='input config file(json or xml)', required=True)
    parser.add_argument('--out', '-o', type=str, help='output config file(json or xml)', required=True)
    args = parser.parse_args()

    if args.input.endswith(".xml"):
        if os.path.exists(args.out):
            os.remove(args.out)
        xml_tree = ET.ElementTree(file = args.input)
        root_ele = xml_tree.getroot()

        node = str()
        node_list = list()
        foreach_xml(root_ele, node, node_list)
        new_root = ET.Element(ROOT_TAG_NAME)
        node_list.sort()
        with open(args.out, "w") as fd:
            for node_dict in node_list:
                #print(node_dict['path'], node_dict['value'])
                xpath_n_value = str(node_dict['path']) + "    value:" + str(node_dict['value']) + '\n'
                fd.write(str(xpath_n_value))
            
