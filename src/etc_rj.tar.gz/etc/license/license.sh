#!/bin/sh
########################################################################
# Description : LICENSE start shell script
#
# Authors     :
#
# Version     : 1.0
#
# Notes       :
#
########################################################################
case "${1}" in
    start)
        mkdir -p /run_isolate/public/webfile/license
        /usr/sbin/license.elf &
        ;;

    stop)
        pkill license.elf
        ;;

    restart)
        ${0} stop
        sleep 3
        ${0} start
        ;;

    *)
        echo "Usage: ${0} {start|stop|restart}"
        exit 1
        ;;
esac

